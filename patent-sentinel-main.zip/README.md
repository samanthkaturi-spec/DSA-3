# Patent Sentinel

Build a complete, production-quality, fully functional web application called:

PATENT PRIOR-ART & LITIGATION ANALYTICS ENGINE

The application is an AI-powered patent research and analytics platform designed to help users search patent documents, compare patent claims, identify semantically similar prior art, analyze patent citations, perform claim-feature coverage analysis, and identify a minimum set of relevant prior-art references.

IMPORTANT:
This must be a FUNCTIONAL APPLICATION, not a static UI prototype.

Every major button, search field, upload function, analysis function, filter, graph, table, and report-generation feature must work.

Do not use fake buttons, placeholder interactions, or dead navigation.

The system is a research/decision-support tool and must NOT claim that it provides definitive legal advice or automatically determines that a patent is legally invalid.

==================================================

TECHNOLOGY STACK
==================================================

Frontend:

React

TypeScript

Tailwind CSS

shadcn/ui

Lucide icons

Recharts for charts

A suitable graph visualization library such as React Flow, Cytoscape.js, or D3.js

Backend:

Supabase

PostgreSQL

Supabase Authentication

Supabase Storage

Supabase Edge Functions where appropriate

AI/NLP:
Design the architecture so semantic patent similarity can be implemented through an embedding API.
Use a configurable embedding provider rather than hardcoding one vendor.
The application must gracefully fall back to TF-IDF/keyword similarity if an embedding API is unavailable.

Search:

PostgreSQL full-text search

pgvector if available

Vector similarity search for semantic embeddings

Data processing:

Patent text extraction

Claim extraction

Text normalization

Keyword extraction

Claim feature extraction

Graph analysis:

Patent citation graph

Citation degree

Citation relationships

Network visualization

Optimization:

Implement a Greedy Set Cover algorithm for identifying a minimum/small prior-art reference set based on extracted claim features.

==================================================
2. VISUAL DESIGN

Create a premium legal-tech + AI dashboard.

Style:

Professional

Modern

Clean

Technical

Academic/research oriented

Suitable for a B.Tech AI & Data Science project demonstration

Color palette:

Deep navy / dark blue

White

Slate gray

Subtle cyan/blue accents

Use red/orange only for warnings or low-confidence indicators

Avoid:

Excessive gradients

Cartoon graphics

Generic stock images

Overly flashy animations

Fake AI effects

Use:

Cards

Data tables

Charts

Patent/document icons

Network graph visuals

Clear status indicators

Professional spacing

Responsive layouts

Create a consistent sidebar navigation.

Sidebar:

Dashboard
Patent Search
Patent Analyzer
Prior-Art Analysis
Claim Comparison
Citation Network
Prior-Art Optimizer
Reports
Settings

==================================================
3. AUTHENTICATION

Implement Supabase authentication.

Pages:

Login

Register

Forgot Password

Logout

After login, redirect to Dashboard.

Create a user profile table.

Do not expose private user data between accounts.

==================================================
4. DATABASE

Create a PostgreSQL/Supabase database schema.

Tables should include:

users/profile
patents
patent_claims
patent_citations
claim_features
similarity_results
prior_art_results
analyses
analysis_claims
analysis_references
reports

Patent fields should include:

id
patent_number
title
abstract
description
claims
inventors
assignee
filing_date
publication_date
priority_date
cpc_codes
ipc_codes
source
created_at

Patent claims:

id
patent_id
claim_number
claim_type
claim_text
is_independent
created_at

Citations:

id
citing_patent_id
cited_patent_id
citation_type
created_at

Similarity results:

id
analysis_id
target_claim_id
candidate_claim_id
semantic_score
keyword_score
classification_score
combined_score
created_at

==================================================
5. DASHBOARD

Create a professional analytics dashboard.

Show:

Total Patents
Total Claims
Total Analyses
Prior-Art References Found
Average Similarity Score
Citation Relationships

Charts:

Patent analysis activity

Similarity score distribution

Patent classification distribution

Citation activity

Recent analyses table:

Patent
Analysis Date
References Found
Top Similarity
Status
Action

Clicking an analysis must open its detailed analysis page.

==================================================
6. PATENT SEARCH

Create a powerful patent search page.

Search by:

Patent number

Title

Abstract

Claim text

Inventor

Assignee

CPC

IPC

Filters:

Publication date

Filing date

CPC classification

IPC classification

Assignee

Similarity threshold

Results should appear in a professional table/card layout.

Each result should display:

Patent number
Title
Assignee
Publication date
CPC/IPC
Short abstract
Number of claims
Citation count

Add:

View Patent
Analyze
Compare
Add to Prior Art

==================================================
7. PATENT ANALYZER

Create the main analysis interface.

Allow users to:

A. Enter a patent number

OR

B. Upload a patent document

OR

C. Paste patent text manually.

Supported upload formats:

PDF

TXT

DOCX if supported by the backend

When a document is uploaded:

Extract text.

Identify title.

Identify abstract.

Identify claims.

Separate independent and dependent claims.

Normalize text.

Store the extracted information.

Display:

Patent Information
Claims
Independent Claims
Dependent Claims
Classification
Citations

Provide an:

"Run Prior-Art Analysis"

button.

Show a real progress indicator:

Uploading
Extracting text
Extracting claims
Generating representations
Searching patent corpus
Calculating similarity
Analyzing citations
Calculating claim coverage
Generating results

Do not pretend that processing happened if it did not.

==================================================
8. NLP / CLAIM SIMILARITY ENGINE

Implement an actual similarity pipeline.

For every target claim:

Normalize text.

Generate keyword representation.

Generate semantic embedding when the embedding service is configured.

Search the patent corpus.

Calculate similarity.

Rank results.

Use cosine similarity for vector comparison.

Also calculate keyword similarity using TF-IDF or PostgreSQL full-text search.

Create a combined score:

Combined Score =
0.60 × Semantic Similarity
+
0.25 × Keyword Similarity
+
0.15 × Classification Similarity

Make these weights configurable in Settings.

If semantic embeddings are unavailable:

Combined Score =
0.70 × Keyword Similarity
+
0.30 × Classification Similarity

Clearly label which scoring mode is being used.

Never generate random similarity scores.

==================================================
9. PRIOR-ART ANALYSIS

Create a dedicated Prior-Art Analysis page.

For each target claim show:

Target Claim
Top Similar Prior Art
Semantic Similarity
Keyword Similarity
Classification Match
Combined Score
Publication Date
Priority Date
Citation Count

Sort by combined score.

Add filters:

Similarity > 50%
Similarity > 70%
Similarity > 80%
Similarity > 90%

Also allow custom thresholds.

Use visual similarity bars.

IMPORTANT:
Do not label a document "invalidating prior art" simply because it has a high similarity score.

Use wording such as:

"Potentially Relevant Prior Art"

"High Similarity Reference"

"Requires Legal Review"

==================================================
10. CLAIM COMPARISON

Create a side-by-side claim comparison interface.

Left:
Target Patent Claim

Right:
Selected Prior-Art Claim

Show:

Matching concepts

Similar phrases

Different concepts

Missing features

Highlight matching terms/concepts where possible.

Create a claim feature matrix:

Feature | Target Claim | Prior Art A | Prior Art B | Prior Art C

Use:

✓ Covered
~ Partially matched
✕ Not identified

Add a confidence indicator.

Make clear that automated matching is not a legal determination.

==================================================
11. CLAIM FEATURE EXTRACTION

Break independent claims into meaningful technical features.

For example:

Target Claim:
"A system comprising a camera, processor, neural network and communication module..."

Extract:

Feature 1:
Camera

Feature 2:
Processor

Feature 3:
Neural network

Feature 4:
Communication module

Store these features in the database.

Allow the user to manually edit/add/remove features.

This is important because users should be able to correct automated extraction.

==================================================
12. PRIOR-ART OPTIMIZER

Implement a real Greedy Set Cover algorithm.

Input:

Target claim features

Candidate prior-art patents

Feature coverage matrix

The algorithm should select a small collection of candidate references that collectively cover the maximum number of target features.

Example:

Target:
A B C D

Patent P1:
A B

Patent P2:
C

Patent P3:
D

The system should calculate:

Selected Set:
P1 + P2 + P3

If:

P4:
A B C

P5:
D

then:

P4 + P5

should be identified as a smaller covering set.

Display:

Target Features
Coverage Matrix
Selected References
Coverage Percentage
Number of References

Use the terminology:

"Minimum / Small Prior-Art Reference Set"

rather than automatically claiming "minimum invalidating set".

Allow users to inspect why each reference was selected.

==================================================
13. CITATION NETWORK

Create an interactive citation graph.

Nodes:
Patents

Edges:
Citations

Node size:
Citation count / centrality

Clicking a node should display:

Patent number
Title
Assignee
Publication date
Citation count
CPC
Related patents

Implement:

Degree centrality

In-degree

Out-degree

If feasible, implement PageRank.

Provide graph controls:

Zoom
Pan
Search
Filter
Reset
Expand Node

Also provide a citation table below the graph.

==================================================
14. PATENT TIMELINE

For each analysis show:

Priority Date
Filing Date
Publication Date
Related Prior Art Dates

Create a chronological timeline.

Highlight potentially relevant references that predate the target patent's relevant date.

Do NOT make automatic legal conclusions based solely on dates.

Display:

"Temporal relevance requires legal review."

==================================================
15. EXAMINER ASSIGNMENT MODULE

Create an examiner recommendation feature.

Create an examiner table containing:

Examiner ID
Name
Technical Domains
CPC/IPC Expertise
Current Workload
Experience

When analyzing a patent:

Compare:

Patent CPC/IPC
Technical domain
Examiner expertise
Current workload

Calculate a transparent assignment score.

Example:

Domain Match: 80%
Expertise: 90%
Workload Balance: 70%

Overall recommendation score:
82%

Display the underlying factors.

Do not automatically assign an actual government examiner.

Label this as:

"Prototype Examiner Assignment Recommendation"

==================================================
16. REPORT GENERATION

Create a Reports page.

Allow users to generate a professional analysis report containing:

Executive Summary
Target Patent
Claims Analyzed
Top Prior-Art References
Similarity Scores
Claim Feature Matrix
Citation Network Summary
Prior-Art Reference Set
Timeline
Examiner Recommendation
Limitations / Legal Disclaimer

Allow export to PDF if supported.

Also allow CSV export of similarity results.

==================================================
17. SETTINGS

Create settings for:

Similarity weights
Similarity threshold
Number of prior-art results
Embedding provider
API configuration
Search settings

Include:

Reset Settings

Save Settings

==================================================
18. ERROR HANDLING

Implement proper error handling.

Examples:

No patent found:
"Patent not found in the available corpus."

Upload failure:
"Unable to process this document. Please verify the file format."

No similar patents:
"No sufficiently similar references were identified."

Embedding API unavailable:
"Semantic search is currently unavailable. Keyword-based analysis is being used."

Database error:
"Unable to retrieve patent data. Please try again."

Never show raw stack traces to users.

==================================================
19. DEMO DATA

Create a clearly labelled DEMO DATA mode so the project can be demonstrated immediately.

Seed the database with realistic but clearly fictional/sample patent records.

Do NOT present fictional patents as real patents.

Add a visible label:

"DEMO DATA"

The user should be able to switch between:

Demo Dataset
and
Uploaded/Imported Dataset

==================================================
20. DATA IMPORT

Create an Import Patents page.

Allow CSV/JSON import.

Expected CSV fields:

patent_number
title
abstract
claims
inventors
assignee
filing_date
publication_date
priority_date
cpc_codes
ipc_codes

Validate uploaded data before inserting.

Show:

Total Rows
Valid Rows
Invalid Rows
Duplicates
Imported Rows

Provide error details for invalid records.

==================================================
21. SECURITY

Implement:

Supabase authentication

Row Level Security

Input validation

File validation

Secure API key handling

Environment variables

No API keys exposed in frontend code

Users must only access their own analysis records.

Patent corpus data can be public/shared if configured as such.

==================================================
22. RESPONSIVE DESIGN

The application must work on:

Desktop
Laptop
Tablet

Prioritize desktop because this is an analytics/research platform.

==================================================
23. LANDING PAGE

Create a professional landing page.

Hero:

"Patent Prior-Art & Litigation Analytics Engine"

Subtitle:

"AI-powered patent search, claim similarity, citation analytics and prior-art optimization."

Buttons:

"Start Analysis"
"Explore Demo"

Sections:

How It Works
Key Capabilities
AI & NLP
Citation Intelligence
Prior-Art Optimization
Analytics Dashboard

Add a legal disclaimer:

"This platform is intended for research and decision-support purposes only. It does not provide legal advice or determine patent validity."

==================================================
24. FINAL DEMO FLOW

The complete application must support this demonstration:

User registers/logs in.

User opens Dashboard.

User searches for a patent or selects DEMO DATA.

User opens Patent Analyzer.

System extracts claims.

User clicks Run Analysis.

System searches the patent corpus.

System calculates similarity.

System displays ranked potentially relevant prior art.

User selects a prior-art patent.

Claim Comparison displays matching/missing features.

Citation Network displays relationships.

Prior-Art Optimizer calculates a small reference set.

Examiner Assignment displays a prototype recommendation.

User generates an analysis report.

Every step must be functional.

==================================================
25. IMPORTANT IMPLEMENTATION RULES

DO NOT:

Build only static pages.

Use fake buttons.

Use random similarity percentages.

Claim legal certainty.

Hardcode analysis results into UI.

Hide errors.

Expose API keys.

Pretend external patent databases are connected when they are not.

DO:

Build reusable components.

Use real database queries.

Implement actual search.

Implement actual similarity calculations.

Implement actual claim-feature coverage.

Implement actual Greedy Set Cover.

Implement real citation graph generation.

Clearly distinguish DEMO DATA from real imported data.

Provide loading states.

Provide empty states.

Provide error states.

Make the UI responsive.

Keep the code modular and maintainable.

==================================================
FINAL REQUIREMENT

Before considering the project complete, verify that:

Authentication works.

Database tables work.

Patent search works.

Patent upload works.

Claim extraction works.

Similarity analysis works.

Prior-art ranking works.

Claim comparison works.

Feature coverage works.

Greedy Set Cover works.

Citation graph works.

Timeline works.

Examiner recommendation works.

Report generation works.

CSV import works.

Demo data works.

Navigation works.

No major button is non-functional.

No page contains placeholder text such as "Coming Soon".

No feature falsely claims legal certainty.

Build this as a serious AI + legal-tech research project suitable for a B.Tech Artificial Intelligence & Data Science final-year project demonstration.

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/65fa9103-cbdc-4d10-91f8-756429655bd8).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
