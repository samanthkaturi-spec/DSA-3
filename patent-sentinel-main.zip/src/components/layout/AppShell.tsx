import { useState, type ReactNode } from "react";
import { Link, useNavigate, useRouterState } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import {
  LayoutDashboard,
  Search,
  ScanSearch,
  Layers,
  Columns2,
  Network,
  Target,
  FileText,
  Settings,
  Upload,
  LogOut,
  Menu,
  Scale,
  FlaskConical,
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger, SheetTitle } from "@/components/ui/sheet";
import { useAuth } from "@/hooks/useAuth";
import { getSettings } from "@/lib/settings.functions";

const NAV = [
  { to: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { to: "/search", label: "Patent Search", icon: Search },
  { to: "/analyzer", label: "Patent Analyzer", icon: ScanSearch },
  { to: "/prior-art", label: "Prior-Art Analysis", icon: Layers },
  { to: "/compare", label: "Claim Comparison", icon: Columns2 },
  { to: "/citations", label: "Citation Network", icon: Network },
  { to: "/optimizer", label: "Prior-Art Optimizer", icon: Target },
  { to: "/reports", label: "Reports", icon: FileText },
  { to: "/import", label: "Import Patents", icon: Upload },
  { to: "/settings", label: "Settings", icon: Settings },
] as const;

export function useSettingsQuery() {
  const fn = useServerFn(getSettings);
  return useQuery({ queryKey: ["settings"], queryFn: () => fn(), staleTime: 60_000 });
}

function NavLinks({ onNavigate }: { onNavigate?: (() => void) | undefined }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  return (
    <nav className="flex flex-col gap-0.5">
      {NAV.map(({ to, label, icon: Icon }) => {
        const active = pathname === to || pathname.startsWith(to + "/");
        return (
          <Link
            key={to}
            to={to}
            onClick={onNavigate}
            className={cn(
              "flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium text-sidebar-foreground/80 transition-colors hover:bg-sidebar-accent hover:text-sidebar-accent-foreground",
              active &&
                "bg-sidebar-accent text-sidebar-accent-foreground shadow-inner ring-1 ring-sidebar-border",
            )}
          >
            <Icon className={cn("h-4 w-4", active && "text-sidebar-primary")} />
            {label}
          </Link>
        );
      })}
    </nav>
  );
}

function Brand() {
  return (
    <Link to="/dashboard" className="flex items-center gap-2.5 px-2">
      <span className="flex h-8 w-8 items-center justify-center rounded-md bg-sidebar-primary text-sidebar-primary-foreground">
        <Scale className="h-4 w-4" />
      </span>
      <span className="leading-tight">
        <span className="block font-display text-sm font-semibold text-sidebar-accent-foreground">
          PriorArt Engine
        </span>
        <span className="block text-[10px] uppercase tracking-wider text-sidebar-foreground/60">
          Litigation Analytics
        </span>
      </span>
    </Link>
  );
}

export function AppShell({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);

  async function signOut() {
    await qc.cancelQueries();
    qc.clear();
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  }

  const sidebarInner = (onNavigate?: (() => void) | undefined) => (
    <div className="flex h-full flex-col">
      <div className="px-2 py-5">
        <Brand />
      </div>
      <div className="flex-1 overflow-y-auto px-3">
        <NavLinks onNavigate={onNavigate} />
      </div>
      <div className="border-t border-sidebar-border p-3">
        <div className="mb-2 flex items-start gap-2 rounded-md bg-sidebar-accent/60 p-2 text-[11px] leading-snug text-sidebar-foreground/70">
          <FlaskConical className="mt-0.5 h-3.5 w-3.5 shrink-0 text-sidebar-primary" />
          Research & decision-support tool. Not legal advice.
        </div>
        <div className="flex items-center justify-between gap-2">
          <div className="min-w-0">
            <p className="truncate text-xs font-medium text-sidebar-accent-foreground">
              {user?.email ?? "Signed in"}
            </p>
            <p className="text-[10px] text-sidebar-foreground/60">Analyst account</p>
          </div>
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8 text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
            onClick={signOut}
            aria-label="Sign out"
          >
            <LogOut className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="flex min-h-screen bg-background">
      <aside className="hidden w-64 shrink-0 border-r border-sidebar-border bg-sidebar lg:block">
        <div className="sticky top-0 h-screen">{sidebarInner()}</div>
      </aside>
      <div className="flex min-w-0 flex-1 flex-col">
        <header className="sticky top-0 z-30 flex h-14 items-center justify-between gap-3 border-b border-border bg-background/90 px-4 backdrop-blur md:px-6 no-print">
          <div className="flex items-center gap-2">
            <Sheet open={open} onOpenChange={setOpen}>
              <SheetTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  className="lg:hidden"
                  aria-label="Open navigation"
                >
                  <Menu className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent
                side="left"
                className="w-72 border-sidebar-border bg-sidebar p-0 text-sidebar-foreground"
              >
                <SheetTitle className="sr-only">Navigation</SheetTitle>
                {sidebarInner(() => setOpen(false))}
              </SheetContent>
            </Sheet>
            <span className="hidden text-xs text-muted-foreground sm:inline">
              Patent research workspace
            </span>
          </div>
        </header>
        <main className="flex-1 px-4 py-6 md:px-6 lg:px-8">{children}</main>
      </div>
    </div>
  );
}
