import { useMemo, useState } from "react";
import { Link } from "@tanstack/react-router";
import { Columns2, Download, Eye, Link2 } from "lucide-react";
import type { AnalysisBundle } from "./useAnalysis";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group";
import {
  ScoreBar,
  RelevanceLabel,
  ScoringModeBadge,
  EmptyState,
  fmtDate,
  pct,
  DatasetBadge,
} from "@/components/common";
import { downloadCsv } from "@/lib/csv";

export function PriorArtPanel({ b, compact = false }: { b: AnalysisBundle; compact?: boolean }) {
  const summary = (b.analysis.summary ?? {}) as Record<string, unknown>;
  const defaultThreshold = Number(summary["threshold"] ?? 0.5);
  const [preset, setPreset] = useState<string>("custom");
  const [custom, setCustom] = useState<number>(Math.round(defaultThreshold * 100));
  const [claimFilter, setClaimFilter] = useState<string>("all");
  const threshold = preset === "custom" ? custom / 100 : Number(preset);

  const rows = useMemo(() => {
    // best similarity row per (target claim, candidate patent)
    const best = new Map<string, (typeof b.similarity)[number]>();
    for (const s of b.similarity) {
      if (claimFilter !== "all" && s.target_claim_id !== claimFilter) continue;
      const key = s.candidate_patent_id;
      const prev = best.get(key);
      if (!prev || Number(s.combined_score) > Number(prev.combined_score)) best.set(key, s);
    }
    const paByPatent = new Map(b.priorArt.map((p) => [p.patent_id, p]));
    return [...best.values()]
      .map((s) => ({ s, pa: paByPatent.get(s.candidate_patent_id) }))
      .filter((r) => r.pa) // only patents that made the ranked set
      .filter((r) => Number(r.s.combined_score) >= threshold)
      .sort((a, c) => Number(c.s.combined_score) - Number(a.s.combined_score));
  }, [b, claimFilter, threshold]);

  const targetById = new Map(b.targetClaims.map((t) => [t.id, t]));

  function exportCsv() {
    downloadCsv(
      `similarity-${b.patent.patent_number}.csv`,
      b.similarity.map((s) => ({
        target_claim: targetById.get(s.target_claim_id)?.claim_number ?? "",
        candidate_patent: s.candidate_patent?.patent_number ?? "",
        candidate_title: s.candidate_patent?.title ?? "",
        candidate_claim: s.candidate_claim?.claim_number ?? "",
        semantic_score: s.semantic_score ?? "",
        keyword_score: s.keyword_score,
        classification_score: s.classification_score,
        combined_score: s.combined_score,
        matched_terms: s.matched_terms.join(" "),
        publication_date: s.candidate_patent?.publication_date ?? "",
        priority_date: s.candidate_patent?.priority_date ?? "",
      })),
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
        <ScoringModeBadge mode={b.analysis.scoring_mode} notice={b.analysis.scoring_notice} />
        <div className="flex flex-wrap items-center gap-2">
          <ToggleGroup
            type="single"
            value={preset}
            onValueChange={(v) => v && setPreset(v)}
            variant="outline"
            size="sm"
          >
            <ToggleGroupItem value="0.5">&gt; 50%</ToggleGroupItem>
            <ToggleGroupItem value="0.7">&gt; 70%</ToggleGroupItem>
            <ToggleGroupItem value="0.8">&gt; 80%</ToggleGroupItem>
            <ToggleGroupItem value="0.9">&gt; 90%</ToggleGroupItem>
            <ToggleGroupItem value="custom">Custom</ToggleGroupItem>
          </ToggleGroup>
          {preset === "custom" && (
            <div className="flex items-center gap-1 text-xs">
              <Input
                type="number"
                min={0}
                max={100}
                className="h-8 w-16 text-xs"
                value={custom}
                onChange={(e) => setCustom(Math.max(0, Math.min(100, Number(e.target.value))))}
              />
              %
            </div>
          )}
          {!compact && (
            <Button size="sm" variant="outline" onClick={exportCsv}>
              <Download className="h-3.5 w-3.5" /> CSV
            </Button>
          )}
        </div>
      </div>

      {b.targetClaims.length > 1 && (
        <div className="flex flex-wrap items-center gap-1.5 text-xs">
          <span className="text-muted-foreground">Target claim:</span>
          <Button
            size="sm"
            variant={claimFilter === "all" ? "secondary" : "ghost"}
            className="h-7"
            onClick={() => setClaimFilter("all")}
          >
            All
          </Button>
          {b.targetClaims.map((t) => (
            <Button
              key={t.id}
              size="sm"
              variant={claimFilter === t.id ? "secondary" : "ghost"}
              className="h-7 font-mono"
              onClick={() => setClaimFilter(t.id)}
            >
              Claim {t.claim_number}
            </Button>
          ))}
        </div>
      )}

      {claimFilter !== "all" && (
        <div className="rounded-md border border-border bg-surface-2 p-3 text-sm">
          <p className="mb-1 font-mono text-xs font-semibold">
            Target claim {targetById.get(claimFilter)?.claim_number}
          </p>
          <p className="text-muted-foreground">{targetById.get(claimFilter)?.claim_text}</p>
        </div>
      )}

      {rows.length === 0 ? (
        <EmptyState
          title="No sufficiently similar references were identified."
          description={`No reference reaches the ${Math.round(threshold * 100)}% combined-score threshold. Lower the threshold or adjust weights in Settings.`}
        />
      ) : (
        <div className="card-elevated overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-8">#</TableHead>
                <TableHead>Top Similar Prior Art</TableHead>
                <TableHead>Semantic</TableHead>
                <TableHead>Keyword</TableHead>
                <TableHead>Classification</TableHead>
                <TableHead>Combined</TableHead>
                <TableHead>Publication</TableHead>
                <TableHead>Priority</TableHead>
                <TableHead className="text-right">Cited</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {rows.map(({ s, pa }, i) => (
                <TableRow key={s.id}>
                  <TableCell className="font-mono text-xs text-muted-foreground">{i + 1}</TableCell>
                  <TableCell className="min-w-64">
                    <div className="flex flex-wrap items-center gap-1.5">
                      <span className="font-mono text-xs font-semibold text-primary">
                        {s.candidate_patent?.patent_number}
                      </span>
                      {(pa?.cited_by_target || pa?.cites_target) && (
                        <Badge variant="outline" className="gap-1 text-[10px]">
                          <Link2 className="h-3 w-3" /> citation link
                        </Badge>
                      )}
                    </div>
                    <p className="text-sm leading-snug">{s.candidate_patent?.title}</p>
                    <p className="text-xs text-muted-foreground">
                      Best match: claim {s.candidate_claim?.claim_number} vs target claim{" "}
                      {targetById.get(s.target_claim_id)?.claim_number}
                    </p>
                    <div className="mt-1">
                      <RelevanceLabel
                        score={Number(s.combined_score)}
                        threshold={defaultThreshold}
                      />
                    </div>
                  </TableCell>
                  <TableCell className="min-w-28">
                    {s.semantic_score === null ? (
                      <span className="text-xs text-muted-foreground">n/a</span>
                    ) : (
                      <ScoreBar value={Number(s.semantic_score)} size="sm" />
                    )}
                  </TableCell>
                  <TableCell className="min-w-28">
                    <ScoreBar value={Number(s.keyword_score)} size="sm" />
                  </TableCell>
                  <TableCell className="min-w-28">
                    <ScoreBar value={Number(s.classification_score)} size="sm" />
                  </TableCell>
                  <TableCell className="min-w-32">
                    <ScoreBar value={Number(s.combined_score)} />
                  </TableCell>
                  <TableCell className="text-xs">
                    {fmtDate(s.candidate_patent?.publication_date)}
                  </TableCell>
                  <TableCell className="text-xs">
                    {fmtDate(s.candidate_patent?.priority_date)}
                    {pa?.predates_target && (
                      <span className="ml-1 rounded bg-secondary px-1 font-mono text-[10px]">
                        predates
                      </span>
                    )}
                  </TableCell>
                  <TableCell className="text-right font-mono text-xs">
                    {pa?.citation_count ?? 0}
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-1">
                      <Button asChild size="sm" variant="ghost" className="h-7 px-2">
                        <Link
                          to="/patents/$id"
                          params={{ id: s.candidate_patent_id }}
                          aria-label="View patent"
                        >
                          <Eye className="h-3.5 w-3.5" />
                        </Link>
                      </Button>
                      <Button asChild size="sm" variant="outline" className="h-7">
                        <Link
                          to="/compare"
                          search={{
                            analysis: b.analysis.id,
                            target: s.target_claim_id,
                            candidate: s.candidate_claim_id,
                          }}
                        >
                          <Columns2 className="h-3.5 w-3.5" /> Compare
                        </Link>
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}
      <p className="text-xs text-muted-foreground">
        High similarity does not establish that a document is invalidating prior art. Each reference
        requires legal review. Threshold and weights: Settings.{" "}
        {pct(Number(summary["set_coverage_pct"] ?? 0))} of features covered by the selected
        reference set.
      </p>
    </div>
  );
}
