import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import type { AnalysisBundle } from "./useAnalysis";
import { getClaimComparison } from "@/lib/analysis.functions";
import { stem, normalizeText, STOPWORDS } from "@/lib/nlp/text";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { LoadingState, ErrorState, ScoreBar, errorMessage } from "@/components/common";
import { CoverageMark, FeatureEditor, FeatureMatrix } from "./FeatureMatrix";
import { cn } from "@/lib/utils";

function Highlighted({ text, matched }: { text: string; matched: Set<string> }) {
  const parts = text.split(/(\s+)/);
  return (
    <p className="text-sm leading-relaxed">
      {parts.map((p, i) => {
        if (/^\s+$/.test(p)) return p;
        const norm = normalizeText(p).replace(/^-+|-+$/g, "");
        const hit = norm.length >= 3 && !STOPWORDS.has(norm) && matched.has(stem(norm));
        return (
          <span key={i} className={cn(hit && "rounded-sm bg-accent/20 px-0.5 text-foreground")}>
            {p}
          </span>
        );
      })}
    </p>
  );
}

export function ComparisonPanel({
  b,
  targetClaimId,
  candidateClaimId,
  onChange,
}: {
  b: AnalysisBundle;
  targetClaimId?: string | undefined;
  candidateClaimId?: string | undefined;
  onChange: (v: { target?: string; candidate?: string }) => void;
}) {
  const compare = useServerFn(getClaimComparison);
  const target =
    targetClaimId && b.targetClaims.some((t) => t.id === targetClaimId)
      ? targetClaimId
      : b.targetClaims[0]?.id;
  const candidates = useMemo(
    () =>
      b.similarity
        .filter((s) => s.target_claim_id === target)
        .sort((x, y) => Number(y.combined_score) - Number(x.combined_score)),
    [b.similarity, target],
  );
  const candidate =
    candidateClaimId && candidates.some((c) => c.candidate_claim_id === candidateClaimId)
      ? candidateClaimId
      : candidates[0]?.candidate_claim_id;
  const [refIds, setRefIds] = useState<string[] | undefined>(undefined);

  const q = useQuery({
    queryKey: ["compare", b.analysis.id, target, candidate],
    queryFn: () =>
      compare({
        data: { analysisId: b.analysis.id, targetClaimId: target!, candidateClaimId: candidate! },
      }),
    enabled: Boolean(target && candidate),
  });

  const chosen = candidates.find((c) => c.candidate_claim_id === candidate);
  const matrixRefs =
    refIds ??
    [chosen?.candidate_patent_id, ...b.priorArt.map((p) => p.patent_id)]
      .filter((x): x is string => Boolean(x))
      .filter((v, i, a) => a.indexOf(v) === i)
      .slice(0, 3);

  return (
    <div className="space-y-4">
      <div className="grid gap-3 md:grid-cols-2">
        <div>
          <p className="mb-1 text-xs font-medium uppercase tracking-wider text-muted-foreground">
            Target patent claim
          </p>
          <Select value={target ?? ""} onValueChange={(v) => onChange({ target: v })}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {b.targetClaims.map((t) => (
                <SelectItem key={t.id} value={t.id}>
                  Claim {t.claim_number} · {t.claim_type} · {t.claim_text.slice(0, 60)}…
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div>
          <p className="mb-1 text-xs font-medium uppercase tracking-wider text-muted-foreground">
            Selected prior-art claim
          </p>
          <Select value={candidate ?? ""} onValueChange={(v) => onChange({ candidate: v })}>
            <SelectTrigger>
              <SelectValue placeholder="No candidate claims" />
            </SelectTrigger>
            <SelectContent>
              {candidates.map((c) => (
                <SelectItem key={c.id} value={c.candidate_claim_id}>
                  <span className="font-mono text-xs">{c.candidate_patent?.patent_number}</span>{" "}
                  claim {c.candidate_claim?.claim_number} ·{" "}
                  {Math.round(Number(c.combined_score) * 100)}%
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {!candidate && (
        <p className="text-sm text-muted-foreground">
          No sufficiently similar references were identified for this claim.
        </p>
      )}
      {q.isLoading && <LoadingState label="Comparing claims…" />}
      {q.isError && <ErrorState message={errorMessage(q.error)} onRetry={() => q.refetch()} />}
      {q.data && (
        <>
          <div className="grid gap-4 lg:grid-cols-2">
            <div className="card-elevated p-4">
              <div className="mb-2 flex items-center gap-2">
                <Badge>Target</Badge>
                <span className="font-mono text-xs">
                  {b.patent.patent_number} · claim {q.data.target.claim_number}
                </span>
              </div>
              <Highlighted
                text={q.data.target.claim_text}
                matched={new Set(q.data.matchingConcepts)}
              />
            </div>
            <div className="card-elevated p-4">
              <div className="mb-2 flex items-center gap-2">
                <Badge variant="secondary">Prior art</Badge>
                <span className="font-mono text-xs">
                  {chosen?.candidate_patent?.patent_number} · claim {q.data.candidate.claim_number}
                </span>
              </div>
              <Highlighted
                text={q.data.candidate.claim_text}
                matched={new Set(q.data.matchingConcepts)}
              />
              <p className="mt-2 text-xs text-muted-foreground">
                {chosen?.candidate_patent?.title}
              </p>
            </div>
          </div>

          <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-4">
            <div className="card-elevated p-3">
              <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                Scores
              </p>
              <div className="mt-2 space-y-1.5 text-xs">
                <div>
                  <span className="text-muted-foreground">Semantic</span>
                  {q.data.scores?.semantic_score == null ? (
                    <span className="ml-2 text-muted-foreground">n/a (keyword mode)</span>
                  ) : (
                    <ScoreBar value={Number(q.data.scores.semantic_score)} size="sm" />
                  )}
                </div>
                <div>
                  <span className="text-muted-foreground">Keyword</span>
                  <ScoreBar
                    value={Number(q.data.scores?.keyword_score ?? q.data.keywordSimilarity)}
                    size="sm"
                  />
                </div>
                <div>
                  <span className="text-muted-foreground">Classification</span>
                  <ScoreBar value={Number(q.data.scores?.classification_score ?? 0)} size="sm" />
                </div>
                <div>
                  <span className="font-medium">Combined</span>
                  <ScoreBar value={Number(q.data.scores?.combined_score ?? 0)} />
                </div>
              </div>
              <p
                className={cn(
                  "mt-2 text-xs",
                  q.data.confidenceLabel === "high"
                    ? "text-success"
                    : q.data.confidenceLabel === "medium"
                      ? "text-warning-foreground"
                      : "text-destructive",
                )}
              >
                Matching confidence: {q.data.confidenceLabel} ({Math.round(q.data.confidence * 100)}
                %)
              </p>
            </div>
            <div className="card-elevated p-3">
              <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                Matching concepts
              </p>
              <div className="mt-2 flex flex-wrap gap-1">
                {q.data.matchingConcepts.length ? (
                  q.data.matchingConcepts.map((t) => (
                    <Badge key={t} className="bg-accent/15 text-foreground hover:bg-accent/15">
                      {t}
                    </Badge>
                  ))
                ) : (
                  <span className="text-xs text-muted-foreground">None</span>
                )}
              </div>
            </div>
            <div className="card-elevated p-3">
              <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                Similar phrases
              </p>
              <div className="mt-2 flex flex-wrap gap-1">
                {q.data.similarPhrases.length ? (
                  q.data.similarPhrases.map((t) => (
                    <Badge key={t} variant="secondary">
                      {t}
                    </Badge>
                  ))
                ) : (
                  <span className="text-xs text-muted-foreground">No shared bigrams</span>
                )}
              </div>
            </div>
            <div className="card-elevated p-3">
              <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                Different concepts
              </p>
              <p className="mt-2 text-[10px] text-muted-foreground">Only in target</p>
              <div className="flex flex-wrap gap-1">
                {q.data.targetOnlyConcepts.slice(0, 12).map((t) => (
                  <Badge key={t} variant="outline" className="border-warning/50">
                    {t}
                  </Badge>
                ))}
              </div>
              <p className="mt-2 text-[10px] text-muted-foreground">Only in prior art</p>
              <div className="flex flex-wrap gap-1">
                {q.data.candidateOnlyConcepts.slice(0, 12).map((t) => (
                  <Badge key={t} variant="outline">
                    {t}
                  </Badge>
                ))}
              </div>
            </div>
          </div>

          <div className="card-elevated p-4">
            <h3 className="text-sm font-semibold">Feature check against this prior-art claim</h3>
            <p className="text-xs text-muted-foreground">
              Missing features are those not identified in the selected claim text.
            </p>
            <ul className="mt-3 space-y-1.5">
              {q.data.features.map((f, i) => (
                <li key={f.id} className="flex items-center gap-2 text-sm">
                  <CoverageMark
                    status={f.status}
                    score={f.score}
                    matched={f.matched}
                    missing={f.missing}
                  />
                  <span className="font-mono text-[10px] text-muted-foreground">F{i + 1}</span>
                  <span className={cn(f.status === "none" && "text-muted-foreground")}>
                    {f.feature_text}
                  </span>
                  {f.status === "none" && (
                    <Badge variant="outline" className="ml-auto text-[10px] text-destructive">
                      missing
                    </Badge>
                  )}
                </li>
              ))}
            </ul>
          </div>
        </>
      )}

      <div className="card-elevated p-4">
        <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
          <div>
            <h3 className="text-sm font-semibold">Claim feature matrix</h3>
            <p className="text-xs text-muted-foreground">
              ✓ Covered · ~ Partially matched · ✕ Not identified. Automated matching is not a legal
              determination.
            </p>
          </div>
          <div className="flex flex-wrap gap-1">
            {b.priorArt.slice(0, 8).map((p) => {
              const active = matrixRefs.includes(p.patent_id);
              return (
                <button
                  key={p.patent_id}
                  type="button"
                  onClick={() =>
                    setRefIds(
                      active
                        ? matrixRefs.filter((x) => x !== p.patent_id)
                        : [...matrixRefs, p.patent_id].slice(-5),
                    )
                  }
                  className={cn(
                    "rounded-md border px-2 py-0.5 font-mono text-[11px]",
                    active
                      ? "border-primary bg-primary text-primary-foreground"
                      : "border-border text-muted-foreground hover:bg-secondary",
                  )}
                >
                  {p.patent?.patent_number}
                </button>
              );
            })}
          </div>
        </div>
        <FeatureMatrix b={b} referenceIds={matrixRefs} claimId={target} />
      </div>

      <div className="card-elevated p-4">
        <h3 className="text-sm font-semibold">
          Edit extracted features (claim {b.targetClaims.find((t) => t.id === target)?.claim_number}
          )
        </h3>
        <div className="mt-3">
          <FeatureEditor b={b} claimId={target} />
        </div>
      </div>
    </div>
  );
}
