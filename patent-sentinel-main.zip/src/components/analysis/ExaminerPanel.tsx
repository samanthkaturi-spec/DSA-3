import type { AnalysisBundle } from "./useAnalysis";
import { ScoreBar, pct } from "@/components/common";
import { Badge } from "@/components/ui/badge";

export function ExaminerPanel({ b }: { b: AnalysisBundle }) {
  if (b.examinerRecommendations.length === 0)
    return (
      <p className="text-sm text-muted-foreground">No examiner recommendation was computed.</p>
    );
  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center gap-2">
        <Badge variant="secondary">Prototype Examiner Assignment Recommendation</Badge>
        <span className="text-xs text-muted-foreground">
          Overall = 0.35·domain + 0.30·expertise + 0.25·workload balance + 0.10·experience.
          Fictional examiners; nobody is actually assigned.
        </span>
      </div>
      <div className="grid gap-3 lg:grid-cols-2">
        {b.examinerRecommendations.map((r) => (
          <div key={r.id} className="card-elevated p-4">
            <div className="flex items-start justify-between gap-2">
              <div>
                <p className="font-semibold">
                  #{r.rank} {r.examiner?.name}
                </p>
                <p className="font-mono text-xs text-muted-foreground">
                  {r.examiner?.examiner_code} · {r.examiner?.experience_years} yrs · workload{" "}
                  {r.examiner?.current_workload}/{r.examiner?.max_workload}
                </p>
              </div>
              <p className="stat-number text-2xl font-semibold text-primary">
                {pct(Number(r.overall_score))}
              </p>
            </div>
            <div className="mt-3 space-y-1.5 text-xs">
              <div>
                <span className="text-muted-foreground">Domain match</span>
                <ScoreBar value={Number(r.domain_match)} size="sm" />
              </div>
              <div>
                <span className="text-muted-foreground">Expertise (CPC/IPC)</span>
                <ScoreBar value={Number(r.expertise_score)} size="sm" />
              </div>
              <div>
                <span className="text-muted-foreground">Workload balance</span>
                <ScoreBar value={Number(r.workload_score)} size="sm" />
              </div>
              <div>
                <span className="text-muted-foreground">Experience</span>
                <ScoreBar value={Number(r.experience_score)} size="sm" />
              </div>
            </div>
            <div className="mt-3 flex flex-wrap gap-1">
              {r.examiner?.technical_domains.map((d) => (
                <Badge key={d} variant="outline" className="text-[10px]">
                  {d}
                </Badge>
              ))}
              {r.examiner?.cpc_expertise.map((c) => (
                <Badge key={c} variant="secondary" className="font-mono text-[10px]">
                  {c}
                </Badge>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
