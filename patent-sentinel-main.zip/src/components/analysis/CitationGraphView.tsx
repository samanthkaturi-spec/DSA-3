import { useEffect, useMemo, useRef, useState } from "react";
import { Link } from "@tanstack/react-router";
import {
  forceCenter,
  forceCollide,
  forceLink,
  forceManyBody,
  forceSimulation,
  type SimulationNodeDatum,
  type SimulationLinkDatum,
} from "d3-force";
import { Maximize2, Minus, Plus, RotateCcw, Search } from "lucide-react";
import type { CitationGraph } from "@/lib/citations.functions";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { DatasetBadge, fmtDate } from "@/components/common";
import { cn } from "@/lib/utils";

type GNode = CitationGraph["nodes"][number] & SimulationNodeDatum;
type GLink = SimulationLinkDatum<GNode> & { id: string; type: string };

export function CitationGraphView({
  graph,
  focusId,
  onExpand,
  onReset,
  height = 520,
}: {
  graph: CitationGraph;
  focusId?: string | null;
  onExpand?: (id: string) => void;
  onReset?: () => void;
  height?: number;
}) {
  const [nodes, setNodes] = useState<GNode[]>([]);
  const [links, setLinks] = useState<GLink[]>([]);
  const [selected, setSelected] = useState<string | null>(focusId ?? null);
  const [query, setQuery] = useState("");
  const [minDegree, setMinDegree] = useState(0);
  const [view, setView] = useState({ x: 0, y: 0, k: 1 });
  const drag = useRef<{ x: number; y: number; vx: number; vy: number } | null>(null);
  const W = 900;
  const H = height;

  useEffect(() => {
    const ns: GNode[] = graph.nodes.map((n) => ({ ...n }));
    const byId = new Map(ns.map((n) => [n.id, n]));
    const ls: GLink[] = graph.edges
      .filter((e) => byId.has(e.source) && byId.has(e.target))
      .map((e) => ({ id: e.id, type: e.type, source: e.source, target: e.target }));
    const sim = forceSimulation(ns)
      .force(
        "link",
        forceLink<GNode, GLink>(ls)
          .id((d) => d.id)
          .distance(90),
      )
      .force("charge", forceManyBody().strength(-260))
      .force("center", forceCenter(W / 2, H / 2))
      .force(
        "collide",
        forceCollide<GNode>().radius((d) => 14 + Math.sqrt(d.inDegree) * 6),
      )
      .stop();
    for (let i = 0; i < 300; i++) sim.tick();
    setNodes([...ns]);
    setLinks([...ls]);
    setView({ x: 0, y: 0, k: 1 });
  }, [graph, H]);

  useEffect(() => setSelected(focusId ?? null), [focusId]);

  const visible = useMemo(
    () => new Set(nodes.filter((n) => n.degree >= minDegree || n.id === focusId).map((n) => n.id)),
    [nodes, minDegree, focusId],
  );
  const matches = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return null;
    return new Set(
      nodes
        .filter(
          (n) =>
            n.patent_number.toLowerCase().includes(q) ||
            n.title.toLowerCase().includes(q) ||
            (n.assignee ?? "").toLowerCase().includes(q),
        )
        .map((n) => n.id),
    );
  }, [nodes, query]);
  const sel = nodes.find((n) => n.id === selected) ?? null;
  const neighbors = useMemo(() => {
    const s = new Set<string>();
    if (!selected) return s;
    for (const l of links) {
      const a = typeof l.source === "object" ? l.source.id : (l.source as string);
      const b = typeof l.target === "object" ? l.target.id : (l.target as string);
      if (a === selected) s.add(b);
      if (b === selected) s.add(a);
    }
    return s;
  }, [links, selected]);

  const radius = (n: GNode) => 7 + Math.sqrt(n.inDegree + 1) * 5 + n.pagerank * 60;
  const maxPr = Math.max(...nodes.map((n) => n.pagerank), 0.0001);

  const zoom = (f: number) => setView((v) => ({ ...v, k: Math.max(0.3, Math.min(4, v.k * f)) }));
  function onWheel(e: React.WheelEvent) {
    e.preventDefault();
    zoom(e.deltaY < 0 ? 1.1 : 0.9);
  }

  const related = sel ? nodes.filter((n) => neighbors.has(n.id)) : [];

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-2">
        <div className="relative">
          <Search className="absolute left-2.5 top-2.5 h-3.5 w-3.5 text-muted-foreground" />
          <Input
            className="h-9 w-56 pl-8 text-sm"
            placeholder="Search nodes…"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
        </div>
        <div className="flex items-center gap-1 text-xs text-muted-foreground">
          Min. degree
          {[0, 1, 2, 3].map((d) => (
            <Button
              key={d}
              size="sm"
              variant={minDegree === d ? "secondary" : "ghost"}
              className="h-7 w-7 px-0 font-mono"
              onClick={() => setMinDegree(d)}
            >
              {d}
            </Button>
          ))}
        </div>
        <div className="ml-auto flex items-center gap-1">
          <Button
            size="icon"
            variant="outline"
            className="h-8 w-8"
            onClick={() => zoom(1.2)}
            aria-label="Zoom in"
          >
            <Plus className="h-4 w-4" />
          </Button>
          <Button
            size="icon"
            variant="outline"
            className="h-8 w-8"
            onClick={() => zoom(0.85)}
            aria-label="Zoom out"
          >
            <Minus className="h-4 w-4" />
          </Button>
          <Button
            size="sm"
            variant="outline"
            className="h-8"
            onClick={() => {
              setView({ x: 0, y: 0, k: 1 });
              setQuery("");
              setMinDegree(0);
              setSelected(focusId ?? null);
              onReset?.();
            }}
          >
            <RotateCcw className="h-3.5 w-3.5" /> Reset
          </Button>
        </div>
      </div>

      <div className="grid gap-4 lg:grid-cols-[1fr_320px]">
        <div className="card-elevated overflow-hidden">
          <svg
            viewBox={`0 0 ${W} ${H}`}
            className="h-auto w-full cursor-grab touch-none select-none bg-card active:cursor-grabbing"
            style={{ maxHeight: H }}
            onWheel={onWheel}
            onPointerDown={(e) => {
              drag.current = { x: e.clientX, y: e.clientY, vx: view.x, vy: view.y };
              (e.target as Element).setPointerCapture?.(e.pointerId);
            }}
            onPointerMove={(e) => {
              if (drag.current)
                setView((v) => ({
                  ...v,
                  x: drag.current!.vx + (e.clientX - drag.current!.x),
                  y: drag.current!.vy + (e.clientY - drag.current!.y),
                }));
            }}
            onPointerUp={() => (drag.current = null)}
            onPointerLeave={() => (drag.current = null)}
          >
            <defs>
              <marker
                id="arrow"
                viewBox="0 0 10 10"
                refX="10"
                refY="5"
                markerWidth="7"
                markerHeight="7"
                orient="auto-start-reverse"
              >
                <path d="M 0 0 L 10 5 L 0 10 z" fill="oklch(0.62 0.03 255)" />
              </marker>
            </defs>
            <g transform={`translate(${view.x},${view.y}) scale(${view.k})`}>
              {links.map((l) => {
                const s = l.source as GNode;
                const t = l.target as GNode;
                if (!visible.has(s.id) || !visible.has(t.id)) return null;
                const active = selected && (s.id === selected || t.id === selected);
                const dx = t.x! - s.x!,
                  dy = t.y! - s.y!;
                const len = Math.hypot(dx, dy) || 1;
                const rt = radius(t);
                return (
                  <line
                    key={l.id}
                    x1={s.x}
                    y1={s.y}
                    x2={t.x! - (dx / len) * (rt + 2)}
                    y2={t.y! - (dy / len) * (rt + 2)}
                    stroke={active ? "oklch(0.6 0.12 218)" : "oklch(0.85 0.012 250)"}
                    strokeWidth={active ? 2 : 1.2}
                    markerEnd="url(#arrow)"
                    strokeDasharray={l.type === "examiner" ? "4 3" : undefined}
                  />
                );
              })}
              {nodes.map((n) => {
                if (!visible.has(n.id)) return null;
                const r = radius(n);
                const isSel = n.id === selected;
                const isFocus = n.id === focusId;
                const dim =
                  (matches && !matches.has(n.id)) || (selected && !isSel && !neighbors.has(n.id));
                return (
                  <g
                    key={n.id}
                    transform={`translate(${n.x},${n.y})`}
                    className="cursor-pointer"
                    opacity={dim ? 0.25 : 1}
                    onClick={(e) => {
                      e.stopPropagation();
                      setSelected(n.id);
                    }}
                    onDoubleClick={() => onExpand?.(n.id)}
                  >
                    <circle
                      r={r}
                      fill={
                        isFocus
                          ? "oklch(0.6 0.12 218)"
                          : isSel
                            ? "oklch(0.3 0.075 262)"
                            : `oklch(${0.95 - (n.pagerank / maxPr) * 0.45} 0.05 262)`
                      }
                      stroke={isSel || isFocus ? "oklch(0.3 0.075 262)" : "oklch(0.6 0.03 255)"}
                      strokeWidth={isSel ? 2.5 : 1.2}
                    />
                    <text
                      y={r + 11}
                      textAnchor="middle"
                      fontSize={9}
                      fontFamily="IBM Plex Mono, monospace"
                      fill="oklch(0.4 0.03 258)"
                    >
                      {n.patent_number.replace("DEMO-US-", "D-")}
                    </text>
                  </g>
                );
              })}
            </g>
          </svg>
          <div className="flex flex-wrap items-center gap-3 border-t border-border px-3 py-2 text-[11px] text-muted-foreground">
            <span>Node size: in-degree + PageRank</span>
            <span>Arrow: citing → cited</span>
            <span>Dashed: examiner citation</span>
            <span>
              Click: details · Double-click: expand neighbourhood · Scroll: zoom · Drag: pan
            </span>
          </div>
        </div>

        <div className="card-elevated p-4">
          {!sel ? (
            <p className="text-sm text-muted-foreground">
              Click a node to see patent details, centrality metrics and related patents.
            </p>
          ) : (
            <div className="space-y-2 text-sm">
              <div className="flex flex-wrap items-center gap-1.5">
                <span className="font-mono text-xs font-semibold text-primary">
                  {sel.patent_number}
                </span>
              </div>
              <p className="font-semibold leading-snug">{sel.title}</p>
              <p className="text-xs text-muted-foreground">
                {sel.assignee ?? "—"} · Published {fmtDate(sel.publication_date)}
              </p>
              <div className="grid grid-cols-2 gap-1.5 text-xs">
                <Metric label="Citation count (in)" v={sel.inDegree} />
                <Metric label="Cites (out)" v={sel.outDegree} />
                <Metric label="Degree centrality" v={sel.degreeCentrality.toFixed(3)} />
                <Metric label="PageRank" v={sel.pagerank.toFixed(4)} />
              </div>
              <div className="flex flex-wrap gap-1">
                {sel.cpc_codes.map((c) => (
                  <Badge key={c} variant="secondary" className="font-mono text-[10px]">
                    {c}
                  </Badge>
                ))}
              </div>
              <div className="flex gap-2 pt-1">
                <Button asChild size="sm" variant="outline">
                  <Link to="/patents/$id" params={{ id: sel.id }}>
                    View patent
                  </Link>
                </Button>
                {onExpand && (
                  <Button size="sm" variant="outline" onClick={() => onExpand(sel.id)}>
                    <Maximize2 className="h-3.5 w-3.5" /> Expand node
                  </Button>
                )}
              </div>
              <div>
                <p className="mt-2 text-xs font-medium uppercase tracking-wider text-muted-foreground">
                  Related patents ({related.length})
                </p>
                <ul className="mt-1 max-h-48 space-y-1 overflow-y-auto text-xs">
                  {related.map((n) => (
                    <li key={n.id}>
                      <button
                        type="button"
                        className="text-left hover:underline"
                        onClick={() => setSelected(n.id)}
                      >
                        <span className="font-mono">{n.patent_number}</span> · {n.title}
                      </button>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          )}
        </div>
      </div>

      <div className="card-elevated overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Citing patent</TableHead>
              <TableHead>Cited patent</TableHead>
              <TableHead>Type</TableHead>
              <TableHead className="text-right">Cited in-degree</TableHead>
              <TableHead className="text-right">Cited PageRank</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {links
              .filter(
                (l) => visible.has((l.source as GNode).id) && visible.has((l.target as GNode).id),
              )
              .map((l) => {
                const s = l.source as GNode,
                  t = l.target as GNode;
                const hi = selected && (s.id === selected || t.id === selected);
                return (
                  <TableRow key={l.id} className={cn(hi && "bg-secondary/60")}>
                    <TableCell>
                      <button
                        type="button"
                        className="text-left text-sm hover:underline"
                        onClick={() => setSelected(s.id)}
                      >
                        <span className="font-mono text-xs">{s.patent_number}</span> · {s.title}
                      </button>
                    </TableCell>
                    <TableCell>
                      <button
                        type="button"
                        className="text-left text-sm hover:underline"
                        onClick={() => setSelected(t.id)}
                      >
                        <span className="font-mono text-xs">{t.patent_number}</span> · {t.title}
                      </button>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline" className="text-[10px] capitalize">
                        {l.type}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right font-mono text-xs">{t.inDegree}</TableCell>
                    <TableCell className="text-right font-mono text-xs">
                      {t.pagerank.toFixed(4)}
                    </TableCell>
                  </TableRow>
                );
              })}
            {links.length === 0 && (
              <TableRow>
                <TableCell colSpan={5} className="text-center text-sm text-muted-foreground">
                  No citation relationships in this view.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}

function Metric({ label, v }: { label: string; v: string | number }) {
  return (
    <div className="rounded border border-border p-1.5">
      <p className="text-[10px] text-muted-foreground">{label}</p>
      <p className="font-mono">{v}</p>
    </div>
  );
}
