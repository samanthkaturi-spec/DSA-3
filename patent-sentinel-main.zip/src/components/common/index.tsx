import type { ReactNode } from "react";
import { Link } from "@tanstack/react-router";
import { AlertTriangle, FlaskConical, Inbox, Loader2, Scale } from "lucide-react";
import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { LEGAL_DISCLAIMER } from "@/lib/analysis-stages";

export function PageHeader({
  title,
  description,
  actions,
  eyebrow,
}: {
  title: string;
  description?: string | undefined;
  actions?: ReactNode;
  eyebrow?: string;
}) {
  return (
    <div className="mb-6 flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
      <div>
        {eyebrow && (
          <p className="mb-1 text-xs font-medium uppercase tracking-wider text-accent">{eyebrow}</p>
        )}
        <h1 className="text-2xl font-semibold text-foreground md:text-3xl">{title}</h1>
        {description && (
          <p className="mt-1 max-w-2xl text-sm text-muted-foreground">{description}</p>
        )}
      </div>
      {actions && <div className="flex flex-wrap items-center gap-2">{actions}</div>}
    </div>
  );
}

export function DemoBadge({
  className,
  label = "DEMO DATA",
}: {
  className?: string | undefined;
  label?: string;
}) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-sm border border-demo-foreground/30 bg-demo px-1.5 py-0.5 font-mono text-[10px] font-semibold uppercase tracking-wider text-demo-foreground",
        className,
      )}
    >
      <FlaskConical className="h-3 w-3" /> {label}
    </span>
  );
}

export function DatasetBadge({
  isDemo,
  className,
}: {
  isDemo: boolean;
  className?: string | undefined;
}) {
  return isDemo ? (
    <DemoBadge className={className} />
  ) : (
    <Badge
      variant="outline"
      className={cn("font-mono text-[10px] uppercase tracking-wider", className)}
    >
      Imported
    </Badge>
  );
}

export function StatCard({
  label,
  value,
  hint,
  icon,
  tone = "default",
}: {
  label: string;
  value: ReactNode;
  hint?: string;
  icon?: ReactNode;
  tone?: "default" | "accent";
}) {
  return (
    <div className="card-elevated p-4">
      <div className="flex items-start justify-between">
        <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
          {label}
        </p>
        {icon && (
          <span className={cn("text-muted-foreground", tone === "accent" && "text-accent")}>
            {icon}
          </span>
        )}
      </div>
      <p className="stat-number mt-2 text-2xl font-semibold text-foreground md:text-3xl">{value}</p>
      {hint && <p className="mt-1 text-xs text-muted-foreground">{hint}</p>}
    </div>
  );
}

export function pct(v: number | null | undefined, digits = 0): string {
  if (v === null || v === undefined || Number.isNaN(Number(v))) return "—";
  return `${(Number(v) * 100).toFixed(digits)}%`;
}

export function scoreTone(v: number | null | undefined): "high" | "mid" | "low" | "none" {
  if (v === null || v === undefined) return "none";
  const n = Number(v);
  if (n >= 0.7) return "high";
  if (n >= 0.5) return "mid";
  return "low";
}

export function ScoreBar({
  value,
  className,
  showLabel = true,
  size = "md",
}: {
  value: number | null | undefined;
  className?: string | undefined;
  showLabel?: boolean;
  size?: "sm" | "md";
}) {
  const tone = scoreTone(value);
  const width =
    value === null || value === undefined ? 0 : Math.max(2, Math.min(100, Number(value) * 100));
  return (
    <div className={cn("flex items-center gap-2", className)}>
      <div
        className={cn(
          "h-1.5 w-full min-w-16 overflow-hidden rounded-full bg-muted",
          size === "md" && "h-2",
        )}
      >
        <div
          className={cn(
            "h-full rounded-full transition-all",
            tone === "high" && "bg-accent",
            tone === "mid" && "bg-info",
            tone === "low" && "bg-muted-foreground/50",
            tone === "none" && "bg-transparent",
          )}
          style={{ width: `${width}%` }}
        />
      </div>
      {showLabel && (
        <span className="w-12 shrink-0 text-right font-mono text-xs tabular-nums text-foreground">
          {pct(value)}
        </span>
      )}
    </div>
  );
}

export function RelevanceLabel({ score, threshold = 0.5 }: { score: number; threshold?: number }) {
  if (score >= 0.8)
    return (
      <Badge className="bg-accent text-accent-foreground hover:bg-accent">
        High Similarity Reference
      </Badge>
    );
  if (score >= threshold) return <Badge variant="secondary">Potentially Relevant Prior Art</Badge>;
  return (
    <Badge variant="outline" className="text-muted-foreground">
      Below threshold
    </Badge>
  );
}

export function ScoringModeBadge({
  mode,
  notice,
}: {
  mode: string | null | undefined;
  notice?: string | null;
}) {
  const semantic = mode === "semantic";
  return (
    <div className="flex flex-wrap items-center gap-2">
      <Badge variant={semantic ? "default" : "secondary"} className="font-mono text-[11px]">
        {semantic
          ? "Scoring: semantic + keyword + classification"
          : "Scoring: keyword + classification (fallback)"}
      </Badge>
      {notice && (
        <span className="inline-flex items-center gap-1 text-xs text-warning-foreground">
          <AlertTriangle className="h-3.5 w-3.5 text-warning" /> {notice}
        </span>
      )}
    </div>
  );
}

export function LegalNotice({ compact = false, text }: { compact?: boolean; text?: string }) {
  return (
    <div
      className={cn(
        "flex items-start gap-2 rounded-md border border-border bg-surface-2 text-muted-foreground",
        compact ? "px-3 py-2 text-xs" : "p-4 text-sm",
      )}
    >
      <Scale className={cn("shrink-0", compact ? "mt-0.5 h-3.5 w-3.5" : "mt-0.5 h-4 w-4")} />
      <p>{text ?? LEGAL_DISCLAIMER}</p>
    </div>
  );
}

export function LoadingState({ label = "Loading…" }: { label?: string }) {
  return (
    <div className="flex items-center justify-center gap-2 py-16 text-sm text-muted-foreground">
      <Loader2 className="h-4 w-4 animate-spin" /> {label}
    </div>
  );
}

export function EmptyState({
  title,
  description,
  action,
  icon,
}: {
  title: string;
  description?: string | undefined;
  action?: ReactNode;
  icon?: ReactNode;
}) {
  return (
    <div className="flex flex-col items-center justify-center rounded-lg border border-dashed border-border bg-card px-6 py-14 text-center">
      <div className="mb-3 rounded-full bg-secondary p-3 text-muted-foreground">
        {icon ?? <Inbox className="h-5 w-5" />}
      </div>
      <h3 className="text-base font-semibold text-foreground">{title}</h3>
      {description && <p className="mt-1 max-w-md text-sm text-muted-foreground">{description}</p>}
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}

export function ErrorState({ message, onRetry }: { message: string; onRetry?: () => void }) {
  return (
    <div className="flex flex-col items-center justify-center rounded-lg border border-destructive/30 bg-destructive/5 px-6 py-12 text-center">
      <AlertTriangle className="mb-3 h-6 w-6 text-destructive" />
      <p className="text-sm font-medium text-foreground">{message}</p>
      {onRetry && (
        <Button variant="outline" size="sm" className="mt-4" onClick={onRetry}>
          Try again
        </Button>
      )}
    </div>
  );
}

export function errorMessage(
  e: unknown,
  fallback = "Something went wrong. Please try again.",
): string {
  if (e instanceof Error && e.message && !/^\s*$/.test(e.message)) {
    const m = e.message;
    if (/Unauthorized/i.test(m)) return "Your session has expired. Please sign in again.";
    if (/fetch failed|NetworkError|Failed to fetch/i.test(m))
      return "Unable to reach the server. Please check your connection and try again.";
    return m.length > 240 ? fallback : m;
  }
  return fallback;
}

export function NoAnalysisPrompt({ text }: { text?: string }) {
  return (
    <EmptyState
      title="No completed analysis selected"
      description={
        text ??
        "Run a prior-art analysis in the Patent Analyzer first, then pick it from the selector above."
      }
      action={
        <Button asChild>
          <Link to="/analyzer">Open Patent Analyzer</Link>
        </Button>
      }
    />
  );
}

export function fmtDate(d: string | null | undefined): string {
  if (!d) return "—";
  const dt = new Date(d);
  if (Number.isNaN(dt.getTime())) return d;
  return dt.toLocaleDateString("en-GB", { year: "numeric", month: "short", day: "2-digit" });
}
