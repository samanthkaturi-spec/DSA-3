import { createFileRoute, Link } from "@tanstack/react-router";
import { z } from "zod";
import {
  useAnalysisBundle,
  useAnalysesList,
  AnalysisPicker,
  AnalysisHeaderMeta,
} from "@/components/analysis/useAnalysis";
import { PriorArtPanel } from "@/components/analysis/PriorArtPanel";
import {
  PageHeader,
  LoadingState,
  ErrorState,
  NoAnalysisPrompt,
  LegalNotice,
  errorMessage,
  fmtDate,
  pct,
} from "@/components/common";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

const searchSchema = z.object({ analysis: z.string().uuid().optional() });

export const Route = createFileRoute("/_authenticated/prior-art")({
  validateSearch: (s) => searchSchema.parse(s),
  head: () => ({
    meta: [
      { title: "Prior-Art Analysis – Patent Prior-Art Analytics Engine" },
      {
        name: "description",
        content:
          "Ranked potentially relevant prior art per target claim with semantic, keyword and classification similarity.",
      },
      { property: "og:title", content: "Prior-Art Analysis" },
      {
        property: "og:description",
        content: "Ranked potentially relevant prior art with similarity scores.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: PriorArtPage,
});

function PriorArtPage() {
  const { analysis } = Route.useSearch();
  const q = useAnalysisBundle(analysis);
  const list = useAnalysesList();
  return (
    <div>
      <PageHeader
        eyebrow="Results"
        title="Prior-Art Analysis"
        description="Potentially relevant prior art ranked by combined similarity for each independent target claim."
      />
      <div className="mb-4">
        <AnalysisPicker value={analysis} to="/prior-art" />
      </div>
      {!analysis && (
        <div className="space-y-4">
          <NoAnalysisPrompt />
          {list.data && list.data.length > 0 && (
            <div className="card-elevated overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Patent</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">References</TableHead>
                    <TableHead className="text-right">Top</TableHead>
                    <TableHead className="text-right">Action</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {list.data.map((a) => {
                    const s = (a.summary ?? {}) as Record<string, number>;
                    return (
                      <TableRow key={a.id}>
                        <TableCell>
                          <span className="font-mono text-xs">{a.patent?.patent_number}</span>
                          <p className="max-w-sm truncate text-xs text-muted-foreground">
                            {a.patent?.title}
                          </p>
                        </TableCell>
                        <TableCell className="text-xs">{fmtDate(a.created_at)}</TableCell>
                        <TableCell>
                          <Badge
                            variant={
                              a.status === "completed"
                                ? "default"
                                : a.status === "failed"
                                  ? "destructive"
                                  : "secondary"
                            }
                          >
                            {a.status}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right font-mono text-xs">
                          {s["references_found"] ?? "—"}
                        </TableCell>
                        <TableCell className="text-right font-mono text-xs">
                          {pct(s["top_similarity"])}
                        </TableCell>
                        <TableCell className="text-right">
                          <Button asChild size="sm" variant="outline">
                            <Link to="/analyses/$id" params={{ id: a.id }}>
                              Open
                            </Link>
                          </Button>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          )}
        </div>
      )}
      {analysis && q.isLoading && <LoadingState label="Loading results…" />}
      {analysis && q.isError && (
        <ErrorState message={errorMessage(q.error)} onRetry={() => q.refetch()} />
      )}
      {q.data && (
        <div className="space-y-4">
          <AnalysisHeaderMeta b={q.data} />
          <PriorArtPanel b={q.data} />
        </div>
      )}
      <div className="mt-8">
        <LegalNotice compact />
      </div>
    </div>
  );
}
