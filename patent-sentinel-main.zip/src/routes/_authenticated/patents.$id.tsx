import { createFileRoute, Link } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Bookmark, BookmarkCheck, Network, ScanSearch } from "lucide-react";
import { toast } from "sonner";
import { getPatent, toggleShortlist } from "@/lib/patents.functions";
import { PatentOverview } from "@/components/analysis/PatentOverview";
import {
  PageHeader,
  LoadingState,
  ErrorState,
  errorMessage,
  fmtDate,
  pct,
} from "@/components/common";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/_authenticated/patents/$id")({
  head: () => ({
    meta: [
      { title: "Patent detail – Patent Prior-Art Analytics Engine" },
      {
        name: "description",
        content: "Patent record with claims, classification and citation relationships.",
      },
      { property: "og:title", content: "Patent detail" },
      {
        property: "og:description",
        content: "Claims, classification and citations for one patent.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: PatentPage,
});

function PatentPage() {
  const { id } = Route.useParams();
  const qc = useQueryClient();
  const fn = useServerFn(getPatent);
  const toggle = useServerFn(toggleShortlist);
  const q = useQuery({ queryKey: ["patent", id], queryFn: () => fn({ data: { id } }) });
  const mut = useMutation({
    mutationFn: () => toggle({ data: { patentId: id } }),
    onSuccess: (r) => {
      qc.invalidateQueries({ queryKey: ["patent", id] });
      qc.invalidateQueries({ queryKey: ["shortlist"] });
      toast.success(r.shortlisted ? "Added to prior-art shortlist" : "Removed from shortlist");
    },
    onError: (e) => toast.error(errorMessage(e)),
  });

  if (q.isLoading) return <LoadingState label="Loading patent…" />;
  if (q.isError || !q.data)
    return (
      <ErrorState
        message={errorMessage(q.error, "Patent not found in the available corpus.")}
        onRetry={() => q.refetch()}
      />
    );
  const d = q.data;

  return (
    <div>
      <PageHeader
        eyebrow="Patent record"
        title={d.patent.patent_number}
        description={
          d.patent.is_demo
            ? "Fictional demo patent – not a real publication."
            : `Source: ${d.patent.source}`
        }
        actions={
          <>
            <Button variant="outline" onClick={() => mut.mutate()} disabled={mut.isPending}>
              {d.shortlisted ? (
                <BookmarkCheck className="h-4 w-4" />
              ) : (
                <Bookmark className="h-4 w-4" />
              )}{" "}
              {d.shortlisted ? "In Prior Art list" : "Add to Prior Art"}
            </Button>
            <Button asChild variant="outline">
              <Link to="/citations" search={{ patent: id }}>
                <Network className="h-4 w-4" /> Citation network
              </Link>
            </Button>
            <Button asChild>
              <Link to="/analyzer" search={{ patent: id }}>
                <ScanSearch className="h-4 w-4" /> Analyze
              </Link>
            </Button>
          </>
        }
      />
      <PatentOverview detail={d} />
      {d.analyses.length > 0 && (
        <div className="card-elevated mt-4 p-4">
          <h3 className="text-sm font-semibold">Analyses of this patent</h3>
          <ul className="mt-2 space-y-1 text-sm">
            {d.analyses.map((a) => {
              const s = (a.summary ?? {}) as Record<string, number>;
              return (
                <li key={a.id} className="flex items-center justify-between gap-2">
                  <span>
                    {fmtDate(a.created_at)} · {a.status} · {s["references_found"] ?? 0} references ·
                    top {pct(s["top_similarity"])}
                  </span>
                  <Button asChild size="sm" variant="outline">
                    <Link to="/analyses/$id" params={{ id: a.id }}>
                      Open
                    </Link>
                  </Button>
                </li>
              );
            })}
          </ul>
        </div>
      )}
    </div>
  );
}
