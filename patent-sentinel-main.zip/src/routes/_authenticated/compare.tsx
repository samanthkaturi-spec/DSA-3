import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { z } from "zod";
import {
  useAnalysesList,
  useAnalysisBundle,
  AnalysisPicker,
  AnalysisHeaderMeta,
} from "@/components/analysis/useAnalysis";
import { ComparisonPanel } from "@/components/analysis/ComparisonPanel";
import {
  PageHeader,
  LoadingState,
  ErrorState,
  NoAnalysisPrompt,
  LegalNotice,
  errorMessage,
} from "@/components/common";
import { Button } from "@/components/ui/button";

const searchSchema = z.object({
  analysis: z.string().uuid().optional(),
  target: z.string().uuid().optional(),
  candidate: z.string().uuid().optional(),
  patent: z.string().uuid().optional(),
});

export const Route = createFileRoute("/_authenticated/compare")({
  validateSearch: (s) => searchSchema.parse(s),
  head: () => ({
    meta: [
      { title: "Claim Comparison – Patent Prior-Art Analytics Engine" },
      {
        name: "description",
        content:
          "Side-by-side comparison of a target claim and a prior-art claim with matching concepts, missing features and a claim-feature matrix.",
      },
      { property: "og:title", content: "Claim Comparison" },
      { property: "og:description", content: "Side-by-side claim comparison and feature matrix." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: ComparePage,
});

function ComparePage() {
  const { analysis, target, candidate, patent } = Route.useSearch();
  const navigate = useNavigate();
  const list = useAnalysesList();
  // If arriving with a patent id (from Search → Compare), pick that patent's latest completed analysis.
  const derived =
    !analysis && patent
      ? list.data?.find((a) => a.patent_id === patent && a.status === "completed")?.id
      : undefined;
  const id = analysis ?? derived;
  const q = useAnalysisBundle(id);

  return (
    <div>
      <PageHeader
        eyebrow="Comparison"
        title="Claim Comparison"
        description="Compare a target claim with a selected prior-art claim. Highlights show shared concepts; the feature matrix marks coverage per reference."
      />
      <div className="mb-4">
        <AnalysisPicker value={id} to="/compare" />
      </div>
      {!id && patent && list.data && (
        <div className="mb-4 rounded-md border border-border bg-surface-2 p-3 text-sm">
          No completed analysis exists for this patent yet.{" "}
          <Button asChild variant="link" className="h-auto p-0">
            <Link to="/analyzer" search={{ patent }}>
              Run an analysis first →
            </Link>
          </Button>
        </div>
      )}
      {!id && !patent && <NoAnalysisPrompt />}
      {id && q.isLoading && <LoadingState label="Loading claims…" />}
      {id && q.isError && (
        <ErrorState message={errorMessage(q.error)} onRetry={() => q.refetch()} />
      )}
      {q.data && (
        <div className="space-y-4">
          <AnalysisHeaderMeta b={q.data} />
          <ComparisonPanel
            b={q.data}
            targetClaimId={target}
            candidateClaimId={candidate}
            onChange={(v) =>
              navigate({
                to: "/compare",
                search: (prev) => ({
                  ...prev,
                  analysis: id,
                  ...(v.target ? { target: v.target, candidate: undefined } : {}),
                  ...(v.candidate ? { candidate: v.candidate } : {}),
                }),
                replace: true,
              })
            }
          />
        </div>
      )}
      <div className="mt-8">
        <LegalNotice compact />
      </div>
    </div>
  );
}
