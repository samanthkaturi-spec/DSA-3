import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Bookmark, BookmarkCheck, Columns2, Eye, Filter, ScanSearch, Search } from "lucide-react";
import { toast } from "sonner";
import {
  searchPatents,
  toggleShortlist,
  listShortlist,
  type SearchInput,
} from "@/lib/patents.functions";
import {
  PageHeader,
  LoadingState,
  ErrorState,
  EmptyState,
  fmtDate,
  errorMessage,
} from "@/components/common";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Slider } from "@/components/ui/slider";

export const Route = createFileRoute("/_authenticated/search")({
  head: () => ({
    meta: [
      { title: "Patent Search – Patent Prior-Art Analytics Engine" },
      {
        name: "description",
        content:
          "Full-text patent search by number, title, abstract, claims, inventor, assignee, CPC and IPC with date filters.",
      },
      { property: "og:title", content: "Patent Search" },
      {
        property: "og:description",
        content:
          "Search your uploaded patent collection by number, title, claims and classifications.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: SearchPage,
});

const FIELDS: Array<{ value: SearchInput["field"]; label: string }> = [
  { value: "all", label: "All fields" },
  { value: "patent_number", label: "Patent number" },
  { value: "title", label: "Title" },
  { value: "abstract", label: "Abstract" },
  { value: "claims", label: "Claim text" },
  { value: "inventor", label: "Inventor" },
  { value: "assignee", label: "Assignee" },
  { value: "cpc", label: "CPC" },
  { value: "ipc", label: "IPC" },
];

function SearchPage() {
  const navigate = useNavigate();
  const qc = useQueryClient();
  const search = useServerFn(searchPatents);
  const toggle = useServerFn(toggleShortlist);
  const shortlistFn = useServerFn(listShortlist);

  const [form, setForm] = useState<SearchInput>({ q: "", field: "all", dataset: "all", limit: 60 });
  const [submitted, setSubmitted] = useState<SearchInput | null>(null);
  const [showFilters, setShowFilters] = useState(false);
  const [minRank, setMinRank] = useState(0);

  const results = useQuery({
    queryKey: ["search", submitted],
    queryFn: () => search({ data: submitted! }),
    enabled: submitted !== null,
  });
  const shortlist = useQuery({ queryKey: ["shortlist"], queryFn: () => shortlistFn() });
  const shortlisted = new Set((shortlist.data ?? []).map((s) => s.patent_id));

  const toggleMut = useMutation({
    mutationFn: (patentId: string) => toggle({ data: { patentId } }),
    onSuccess: (r) => {
      qc.invalidateQueries({ queryKey: ["shortlist"] });
      toast.success(
        r.shortlisted ? "Added to prior-art shortlist" : "Removed from prior-art shortlist",
      );
    },
    onError: (e) => toast.error(errorMessage(e)),
  });

  function submit(e?: FormEvent) {
    e?.preventDefault();
    setSubmitted(form);
  }

  const rows = (results.data ?? []).filter((r) => {
    if (!submitted?.q || minRank === 0) return true;
    const max = Math.max(...(results.data ?? []).map((x) => Number(x.rank) || 0), 0.0001);
    return (Number(r.rank) || 0) / max >= minRank;
  });

  return (
    <div>
      <PageHeader
        eyebrow="Corpus"
        title="Patent Search"
        description="Full-text search across the active dataset. Results include claim and citation counts."
      />

      <form onSubmit={submit} className="card-elevated p-4">
        <div className="flex flex-col gap-3 md:flex-row">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              className="pl-9"
              placeholder="Search title, claim, assignee, patent number…"
              value={form.q}
              onChange={(e) => setForm({ ...form, q: e.target.value })}
            />
          </div>
          <Select
            value={form.field}
            onValueChange={(v) => setForm({ ...form, field: v as SearchInput["field"] })}
          >
            <SelectTrigger className="md:w-44">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {FIELDS.map((f) => (
                <SelectItem key={f.value} value={f.value}>
                  {f.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button type="button" variant="outline" onClick={() => setShowFilters((s) => !s)}>
            <Filter className="h-4 w-4" /> Filters
          </Button>
          <Button type="submit">
            <Search className="h-4 w-4" /> Search
          </Button>
        </div>
        {showFilters && (
          <div className="mt-4 grid gap-3 border-t border-border pt-4 sm:grid-cols-2 lg:grid-cols-4">
            <div className="space-y-1">
              <Label className="text-xs">Publication from</Label>
              <Input
                type="date"
                value={form.pubFrom ?? ""}
                onChange={(e) => setForm({ ...form, pubFrom: e.target.value })}
              />
            </div>
            <div className="space-y-1">
              <Label className="text-xs">Publication to</Label>
              <Input
                type="date"
                value={form.pubTo ?? ""}
                onChange={(e) => setForm({ ...form, pubTo: e.target.value })}
              />
            </div>
            <div className="space-y-1">
              <Label className="text-xs">Filing from</Label>
              <Input
                type="date"
                value={form.filingFrom ?? ""}
                onChange={(e) => setForm({ ...form, filingFrom: e.target.value })}
              />
            </div>
            <div className="space-y-1">
              <Label className="text-xs">Filing to</Label>
              <Input
                type="date"
                value={form.filingTo ?? ""}
                onChange={(e) => setForm({ ...form, filingTo: e.target.value })}
              />
            </div>
            <div className="space-y-1">
              <Label className="text-xs">CPC classification (prefix)</Label>
              <Input
                placeholder="G06V"
                value={form.cpc ?? ""}
                onChange={(e) => setForm({ ...form, cpc: e.target.value })}
              />
            </div>
            <div className="space-y-1">
              <Label className="text-xs">IPC classification (prefix)</Label>
              <Input
                placeholder="A61B"
                value={form.ipc ?? ""}
                onChange={(e) => setForm({ ...form, ipc: e.target.value })}
              />
            </div>
            <div className="space-y-1">
              <Label className="text-xs">Assignee contains</Label>
              <Input
                placeholder="Robotics"
                value={form.assignee ?? ""}
                onChange={(e) => setForm({ ...form, assignee: e.target.value })}
              />
            </div>
            <div className="space-y-1">
              <Label className="text-xs">
                Relevance threshold: {Math.round(minRank * 100)}% of best match
              </Label>
              <Slider
                value={[minRank]}
                min={0}
                max={0.9}
                step={0.05}
                onValueChange={([v]) => setMinRank(v ?? 0)}
                className="mt-3"
              />
            </div>
          </div>
        )}
      </form>

      <div className="mt-6">
        {submitted === null && (
          <EmptyState
            icon={<Search className="h-5 w-5" />}
            title="Search your patent collection"
            description="Search by keyword, patent number, classification, or leave the query empty to browse everything you have uploaded."
          />
        )}
        {results.isLoading && <LoadingState label="Searching corpus…" />}
        {results.isError && (
          <ErrorState
            message={errorMessage(
              results.error,
              "Unable to retrieve patent data. Please try again.",
            )}
            onRetry={() => results.refetch()}
          />
        )}
        {results.data && rows.length === 0 && (
          <EmptyState
            title="Patent not found in the available corpus."
            description="No patents matched your query and filters. Try broader terms or another field."
          />
        )}
        {rows.length > 0 && (
          <>
            <p className="mb-3 text-xs text-muted-foreground">
              {rows.length} result{rows.length === 1 ? "" : "s"}
            </p>
            <div className="grid gap-3">
              {rows.map((p) => (
                <article key={p.id} className="card-elevated p-4">
                  <div className="flex flex-col gap-3 lg:flex-row lg:items-start lg:justify-between">
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="font-mono text-xs font-semibold text-primary">
                          {p.patent_number}
                        </span>
                        <span className="text-xs text-muted-foreground">
                          Published {fmtDate(p.publication_date)}
                        </span>
                      </div>
                      <h3 className="mt-1 font-semibold leading-snug">
                        <Link to="/patents/$id" params={{ id: p.id }} className="hover:underline">
                          {p.title}
                        </Link>
                      </h3>
                      <p className="text-xs text-muted-foreground">{p.assignee ?? "Unassigned"}</p>
                      <p className="mt-2 line-clamp-2 text-sm text-muted-foreground">
                        {p.abstract}
                      </p>
                      <div className="mt-2 flex flex-wrap items-center gap-1.5">
                        {p.cpc_codes.slice(0, 4).map((c) => (
                          <Badge key={c} variant="secondary" className="font-mono text-[10px]">
                            {c}
                          </Badge>
                        ))}
                        {p.ipc_codes.slice(0, 2).map((c) => (
                          <Badge key={"i" + c} variant="outline" className="font-mono text-[10px]">
                            IPC {c}
                          </Badge>
                        ))}
                        <span className="ml-1 text-xs text-muted-foreground">
                          {p.claim_count} claims · cited {p.citation_count}×
                        </span>
                      </div>
                    </div>
                    <div className="flex shrink-0 flex-wrap gap-2 lg:flex-col">
                      <Button asChild size="sm" variant="outline">
                        <Link to="/patents/$id" params={{ id: p.id }}>
                          <Eye className="h-4 w-4" /> View Patent
                        </Link>
                      </Button>
                      <Button
                        size="sm"
                        onClick={() => navigate({ to: "/analyzer", search: { patent: p.id } })}
                      >
                        <ScanSearch className="h-4 w-4" /> Analyze
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => navigate({ to: "/compare", search: { patent: p.id } })}
                      >
                        <Columns2 className="h-4 w-4" /> Compare
                      </Button>
                      <Button
                        size="sm"
                        variant={shortlisted.has(p.id) ? "secondary" : "outline"}
                        onClick={() => toggleMut.mutate(p.id)}
                        disabled={toggleMut.isPending}
                      >
                        {shortlisted.has(p.id) ? (
                          <BookmarkCheck className="h-4 w-4" />
                        ) : (
                          <Bookmark className="h-4 w-4" />
                        )}
                        {shortlisted.has(p.id) ? "In Prior Art list" : "Add to Prior Art"}
                      </Button>
                    </div>
                  </div>
                </article>
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
