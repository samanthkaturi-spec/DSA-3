import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { z } from "zod";
import { useQuery } from "@tanstack/react-query";
import { createClientOnlyFn, useServerFn } from "@tanstack/react-start";
import { FileUp, Hash, ClipboardPaste, Loader2, Search } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import {
  createPatentFromText,
  findPatentByNumber,
  getPatent,
  listPatents,
} from "@/lib/patents.functions";
import {
  PageHeader,
  LoadingState,
  ErrorState,
  LegalNotice,
  errorMessage,
  EmptyState,
} from "@/components/common";
import { PatentOverview } from "@/components/analysis/PatentOverview";
import {
  AnalysisProgressPanel,
  RunAnalysisButton,
  StageList,
  useAnalysisRunner,
  type StageState,
} from "@/components/analysis/AnalysisRunner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
const searchSchema = z.object({ patent: z.string().uuid().optional() });
const ACCEPTED_TYPES = [".pdf", ".txt", ".docx", ".md"];
const loadDocumentParser = createClientOnlyFn(() => import("@/lib/document-parse.client"));

export const Route = createFileRoute("/_authenticated/analyzer")({
  validateSearch: (s) => searchSchema.parse(s),
  head: () => ({
    meta: [
      { title: "Patent Analyzer – Patent Prior-Art Analytics Engine" },
      {
        name: "description",
        content:
          "Enter a patent number, upload a PDF/DOCX/TXT or paste text; extract claims and run the prior-art analysis pipeline.",
      },
      { property: "og:title", content: "Patent Analyzer" },
      { property: "og:description", content: "Extract claims and run prior-art analysis." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: AnalyzerPage,
});

function AnalyzerPage() {
  const { patent: patentParam } = Route.useSearch();
  const navigate = useNavigate();
  const getPatentFn = useServerFn(getPatent);
  const findByNumber = useServerFn(findPatentByNumber);
  const createFromText = useServerFn(createPatentFromText);
  const listFn = useServerFn(listPatents);

  const [patentId, setPatentId] = useState<string | null>(patentParam ?? null);
  const [numberInput, setNumberInput] = useState("");
  const [pasteText, setPasteText] = useState("");
  const [pasteTitle, setPasteTitle] = useState("");
  const [pasteNumber, setPasteNumber] = useState("");
  const [busy, setBusy] = useState(false);
  const [preStages, setPreStages] = useState<StageState[]>([]);
  const fileRef = useRef<HTMLInputElement>(null);
  const runner = useAnalysisRunner();

  useEffect(() => {
    if (patentParam) setPatentId(patentParam);
  }, [patentParam]);

  const detail = useQuery({
    queryKey: ["patent", patentId],
    queryFn: () => getPatentFn({ data: { id: patentId! } }),
    enabled: Boolean(patentId),
  });
  const patentList = useQuery({ queryKey: ["patents"], queryFn: () => listFn({ data: {} }) });

  async function lookup() {
    if (!numberInput.trim()) return;
    setBusy(true);
    try {
      const p = await findByNumber({ data: { patentNumber: numberInput } });
      select(p.id);
    } catch (e) {
      toast.error(errorMessage(e, "Patent not found in the available corpus."));
    } finally {
      setBusy(false);
    }
  }

  function select(id: string) {
    setPatentId(id);
    setPreStages([]);
    navigate({ to: "/analyzer", search: { patent: id }, replace: true });
  }

  async function handleFile(file: File) {
    setBusy(true);
    const stages: StageState[] = [
      { key: "uploading", label: "Uploading", status: "running" },
      { key: "extracting_text", label: "Extracting text", status: "pending" },
    ];
    setPreStages(stages);
    const set = (key: string, patch: Partial<StageState>) => {
      stages.splice(
        0,
        stages.length,
        ...stages.map((s) => (s.key === key ? { ...s, ...patch } : s)),
      );
      setPreStages([...stages]);
    };
    try {
      const { data: userData } = await supabase.auth.getUser();
      const uid = userData.user?.id;
      if (!uid) throw new Error("Your session has expired. Please sign in again.");
      const path = `${uid}/${Date.now()}-${file.name.replace(/[^a-zA-Z0-9._-]/g, "_")}`;
      const { error: upErr } = await supabase.storage
        .from("patent-documents")
        .upload(path, file, { upsert: false });
      if (upErr) throw new Error("Unable to upload the document. Please try again.");
      set("uploading", {
        status: "done",
        detail: `${file.name} (${(file.size / 1024).toFixed(0)} KB)`,
      });
      set("extracting_text", { status: "running" });
      const { extractTextFromFile } = await loadDocumentParser();
      const text = await extractTextFromFile(file, (msg) =>
        set("extracting_text", { detail: msg }),
      );
      const res = await createFromText({
        data: { text, source: "upload", fileName: file.name, storagePath: path },
      });
      set("extracting_text", {
        status: "done",
        detail: `${text.length.toLocaleString()} characters · ${res.claimCount} claims (${res.independentCount} independent)`,
      });
      toast.success(`Extracted ${res.claimCount} claims from ${file.name}`);
      setPatentId(res.id);
      navigate({ to: "/analyzer", search: { patent: res.id }, replace: true });
    } catch (e) {
      const msg = errorMessage(
        e,
        "Unable to process this document. Please verify the file format.",
      );
      set(stages.find((s) => s.status === "running")?.key ?? "extracting_text", {
        status: "failed",
        detail: msg,
      });
      toast.error(msg);
    } finally {
      setBusy(false);
      if (fileRef.current) fileRef.current.value = "";
    }
  }

  async function handlePaste() {
    setBusy(true);
    try {
      const res = await createFromText({
        data: {
          text: pasteText,
          source: "manual",
          ...(pasteTitle ? { title: pasteTitle } : {}),
          ...(pasteNumber ? { patentNumber: pasteNumber } : {}),
        },
      });
      toast.success(`Extracted ${res.claimCount} claims`);
      setPreStages([
        {
          key: "extracting_text",
          label: "Extracting text",
          status: "done",
          detail: `${res.claimCount} claims (${res.independentCount} independent)`,
        },
      ]);
      setPatentId(res.id);
      navigate({ to: "/analyzer", search: { patent: res.id }, replace: true });
    } catch (e) {
      toast.error(errorMessage(e, "Unable to process this text."));
    } finally {
      setBusy(false);
    }
  }

  return (
    <div>
      <PageHeader
        eyebrow="Pipeline"
        title="Patent Analyzer"
        description="Select a target patent, review the extracted claims, then run the prior-art analysis."
      />

      <div className="card-elevated p-4">
        <Tabs defaultValue="number">
          <TabsList>
            <TabsTrigger value="number">
              <Hash className="mr-1 h-3.5 w-3.5" /> Patent number
            </TabsTrigger>
            <TabsTrigger value="upload">
              <FileUp className="mr-1 h-3.5 w-3.5" /> Upload document
            </TabsTrigger>
            <TabsTrigger value="paste">
              <ClipboardPaste className="mr-1 h-3.5 w-3.5" /> Paste text
            </TabsTrigger>
          </TabsList>
          <TabsContent value="number" className="mt-4">
            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label>Enter a patent number from the corpus</Label>
                <div className="flex gap-2">
                  <Input
                    placeholder="Patent number"
                    value={numberInput}
                    onChange={(e) => setNumberInput(e.target.value)}
                    onKeyDown={(e) => e.key === "Enter" && lookup()}
                  />
                  <Button onClick={lookup} disabled={busy || !numberInput.trim()}>
                    {busy ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <Search className="h-4 w-4" />
                    )}{" "}
                    Look up
                  </Button>
                </div>
                <p className="text-xs text-muted-foreground">
                  Only patents uploaded to your account are searchable here. External patent offices
                  are not queried.
                </p>
              </div>
              <div className="space-y-2">
                <Label htmlFor="uploaded-patent-select">Or select an uploaded patent</Label>
                <select
                  id="uploaded-patent-select"
                  className="h-10 w-full rounded-md border border-input bg-background px-3 text-sm"
                  value={
                    patentId && patentList.data?.some((p) => p.id === patentId) ? patentId : ""
                  }
                  onChange={(e) => {
                    if (e.target.value) select(e.target.value);
                  }}
                >
                  <option value="">
                    {patentList.isLoading ? "Loading patents…" : "Choose from your collection"}
                  </option>
                  {(patentList.data ?? []).map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.patent_number} · {p.title}
                    </option>
                  ))}
                </select>
                {patentList.data?.length === 0 && (
                  <EmptyState
                    title="Your collection is empty"
                    description="Import a CSV/JSON dataset or upload a patent document to get started."
                  />
                )}
              </div>
            </div>
          </TabsContent>
          <TabsContent value="upload" className="mt-4">
            <div
              className="flex flex-col items-center justify-center rounded-lg border-2 border-dashed border-border bg-surface-2 px-6 py-10 text-center"
              onDragOver={(e) => e.preventDefault()}
              onDrop={(e) => {
                e.preventDefault();
                const f = e.dataTransfer.files?.[0];
                if (f) handleFile(f);
              }}
            >
              <FileUp className="mb-2 h-6 w-6 text-muted-foreground" />
              <p className="text-sm font-medium">Drop a patent document here or choose a file</p>
              <p className="mt-1 text-xs text-muted-foreground">
                PDF, DOCX or TXT · up to 20 MB · text is extracted in your browser, then claims are
                identified on the server
              </p>
              <input
                ref={fileRef}
                type="file"
                accept={ACCEPTED_TYPES.join(",")}
                className="hidden"
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (f) handleFile(f);
                }}
              />
              <Button
                className="mt-4"
                variant="outline"
                onClick={() => fileRef.current?.click()}
                disabled={busy}
              >
                {busy ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <FileUp className="h-4 w-4" />
                )}{" "}
                Choose file
              </Button>
            </div>
          </TabsContent>
          <TabsContent value="paste" className="mt-4 space-y-3">
            <div className="grid gap-3 md:grid-cols-2">
              <div className="space-y-1">
                <Label>Title (optional)</Label>
                <Input
                  value={pasteTitle}
                  onChange={(e) => setPasteTitle(e.target.value)}
                  placeholder="Detected from text when omitted"
                />
              </div>
              <div className="space-y-1">
                <Label>Patent number (optional)</Label>
                <Input
                  value={pasteNumber}
                  onChange={(e) => setPasteNumber(e.target.value)}
                  placeholder="Auto-generated when omitted"
                />
              </div>
            </div>
            <div className="space-y-1">
              <div className="flex items-center justify-between">
                <Label>Patent text with numbered claims</Label>
              </div>
              <Textarea
                rows={10}
                value={pasteText}
                onChange={(e) => setPasteText(e.target.value)}
                placeholder={
                  "Abstract\n…\n\nClaims\n1. A system comprising: …\n2. The system of claim 1, wherein …"
                }
                className="font-mono text-xs"
              />
            </div>
            <Button onClick={handlePaste} disabled={busy || pasteText.trim().length < 40}>
              {busy && <Loader2 className="h-4 w-4 animate-spin" />} Extract claims
            </Button>
          </TabsContent>
        </Tabs>
      </div>

      {preStages.length > 0 && runner.stages.length === 0 && (
        <div className="card-elevated mt-4 p-4">
          <h3 className="mb-2 text-sm font-semibold">Document processing</h3>
          <StageList stages={preStages} />
        </div>
      )}

      {patentId && (
        <div className="mt-6 space-y-4">
          {detail.isLoading && <LoadingState label="Loading patent…" />}
          {detail.isError && (
            <ErrorState
              message={errorMessage(
                detail.error,
                "Unable to retrieve patent data. Please try again.",
              )}
              onRetry={() => detail.refetch()}
            />
          )}
          {detail.data && (
            <>
              <PatentOverview detail={detail.data} />
              <div className="card-elevated flex flex-col gap-4 p-4 md:flex-row md:items-center md:justify-between">
                <div>
                  <h3 className="font-semibold">
                    Ready to analyse {detail.data.patent.patent_number}
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    {detail.data.claims.filter((c) => c.is_independent).length ||
                      detail.data.claims.length}{" "}
                    target claim(s) will be compared against the selected corpus using your current
                    similarity settings.
                  </p>
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  <RunAnalysisButton
                    onClick={() =>
                      runner.start(
                        patentId,
                        preStages.map((s) => ({ ...s, status: "done" as const })),
                      )
                    }
                    running={runner.running}
                    disabled={detail.data.claims.length === 0}
                  />
                </div>
              </div>
              <AnalysisProgressPanel
                stages={runner.stages}
                progress={runner.progress}
                error={runner.error}
                running={runner.running}
              />
              {runner.error && runner.analysisId && (
                <Button variant="outline" onClick={() => runner.start(patentId)}>
                  Retry analysis
                </Button>
              )}
            </>
          )}
        </div>
      )}

      <div className="mt-8">
        <LegalNotice compact />
      </div>
    </div>
  );
}
