import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { FileText, Loader2, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { listReports, generateReport, deleteReport } from "@/lib/reports.functions";
import { useAnalysesList } from "@/components/analysis/useAnalysis";
import {
  PageHeader,
  LoadingState,
  ErrorState,
  EmptyState,
  DemoBadge,
  fmtDate,
  errorMessage,
} from "@/components/common";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";

export const Route = createFileRoute("/_authenticated/reports/")({
  head: () => ({
    meta: [
      { title: "Reports – Patent Prior-Art Analytics Engine" },
      {
        name: "description",
        content: "Generate, view, print and export prior-art analysis reports.",
      },
      { property: "og:title", content: "Analysis Reports" },
      { property: "og:description", content: "Generate and export prior-art analysis reports." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: ReportsPage,
});

function ReportsPage() {
  const qc = useQueryClient();
  const navigate = useNavigate();
  const listFn = useServerFn(listReports);
  const gen = useServerFn(generateReport);
  const del = useServerFn(deleteReport);
  const reports = useQuery({ queryKey: ["reports"], queryFn: () => listFn() });
  const analyses = useAnalysesList();
  const [selected, setSelected] = useState<string | undefined>(undefined);

  const genMut = useMutation({
    mutationFn: () => gen({ data: { analysisId: selected! } }),
    onSuccess: (r) => {
      qc.invalidateQueries({ queryKey: ["reports"] });
      toast.success("Report generated");
      navigate({ to: "/reports/$id", params: { id: r.id } });
    },
    onError: (e) => toast.error(errorMessage(e)),
  });
  const delMut = useMutation({
    mutationFn: (id: string) => del({ data: { id } }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["reports"] });
      toast.success("Report deleted");
    },
    onError: (e) => toast.error(errorMessage(e)),
  });
  const completed = (analyses.data ?? []).filter((a) => a.status === "completed");

  return (
    <div>
      <PageHeader
        eyebrow="Output"
        title="Reports"
        description="Generate a structured analysis report from any completed analysis. Reports can be printed / saved as PDF; similarity results export to CSV from the report page."
      />
      <div className="card-elevated flex flex-col gap-3 p-4 md:flex-row md:items-center">
        <Select value={selected ?? ""} onValueChange={setSelected}>
          <SelectTrigger className="md:w-[460px]">
            <SelectValue
              placeholder={
                completed.length ? "Choose a completed analysis" : "No completed analyses yet"
              }
            />
          </SelectTrigger>
          <SelectContent>
            {completed.map((a) => (
              <SelectItem key={a.id} value={a.id}>
                <span className="font-mono text-xs">{a.patent?.patent_number}</span> ·{" "}
                {a.patent?.title?.slice(0, 50)} · {fmtDate(a.created_at)}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Button onClick={() => genMut.mutate()} disabled={!selected || genMut.isPending}>
          {genMut.isPending ? (
            <Loader2 className="h-4 w-4 animate-spin" />
          ) : (
            <FileText className="h-4 w-4" />
          )}{" "}
          Generate report
        </Button>
      </div>

      <div className="mt-6">
        {reports.isLoading && <LoadingState label="Loading reports…" />}
        {reports.isError && (
          <ErrorState message={errorMessage(reports.error)} onRetry={() => reports.refetch()} />
        )}
        {reports.data && reports.data.length === 0 && (
          <EmptyState
            icon={<FileText className="h-5 w-5" />}
            title="No reports yet"
            description="Generate your first report from a completed analysis above."
          />
        )}
        {reports.data && reports.data.length > 0 && (
          <div className="card-elevated overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Report</TableHead>
                  <TableHead>Target</TableHead>
                  <TableHead>Scoring</TableHead>
                  <TableHead className="text-right">References</TableHead>
                  <TableHead>Created</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {reports.data.map((r) => (
                  <TableRow key={r.id}>
                    <TableCell className="font-medium">
                      <Link to="/reports/$id" params={{ id: r.id }} className="hover:underline">
                        {r.title}
                      </Link>
                    </TableCell>
                    <TableCell>
                      <span className="font-mono text-xs">{r.patent_number}</span>{" "}
                      {r.is_demo && <DemoBadge className="ml-1" />}
                    </TableCell>
                    <TableCell>
                      <Badge variant="secondary" className="text-[10px]">
                        {r.scoring_mode}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right font-mono text-xs">{r.references}</TableCell>
                    <TableCell className="text-xs">{fmtDate(r.created_at)}</TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-1">
                        <Button asChild size="sm" variant="outline">
                          <Link to="/reports/$id" params={{ id: r.id }}>
                            Open
                          </Link>
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          className="text-destructive"
                          onClick={() => delMut.mutate(r.id)}
                          aria-label="Delete report"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </div>
    </div>
  );
}
