declare module "mammoth/mammoth.browser" {
  const m: typeof import("mammoth");
  export = m;
}
