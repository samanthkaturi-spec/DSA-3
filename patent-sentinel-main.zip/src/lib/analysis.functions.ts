import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { SERVER_STAGES } from "@/lib/analysis-stages";
import { tokenize } from "@/lib/nlp/text";
import { toSettings, DEFAULT_SETTINGS } from "@/lib/settings.functions";
import {
  runStage,
  loadAnalysisBundle,
  compareClaims,
  stageCoverage,
  PipelineError,
} from "@/lib/analysis-pipeline.server";

const stageKeys = SERVER_STAGES.map((s) => s.key) as [string, ...string[]];

function friendly(e: unknown, fallback: string): never {
  if (e instanceof PipelineError) throw new Error(e.message);
  if (e instanceof Error && /not found|unavailable|Unable|No /.test(e.message))
    throw new Error(e.message);
  console.error(e);
  throw new Error(fallback);
}

export const createAnalysis = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ patentId: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { data: patent } = await supabase
      .from("patents")
      .select("id")
      .eq("id", data.patentId)
      .maybeSingle();
    if (!patent) throw new Error("Patent not found in the available corpus.");
    const { data: settingsRow } = await supabase
      .from("user_settings")
      .select("*")
      .eq("user_id", userId)
      .maybeSingle();
    const settings = settingsRow ? toSettings(settingsRow) : DEFAULT_SETTINGS;
    const { data: created, error } = await supabase
      .from("analyses")
      .insert({
        user_id: userId,
        patent_id: data.patentId,
        status: "running",
        stage: "created",
        progress: 0,
        dataset_mode: "all",
        settings_snapshot: settings,
      })
      .select("id")
      .single();
    if (error || !created) throw new Error("Unable to start the analysis. Please try again.");
    return { analysisId: created.id };
  });

export const runAnalysisStage = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z.object({ analysisId: z.string().uuid(), stage: z.enum(stageKeys) }).parse(input),
  )
  .handler(async ({ data, context }) => {
    try {
      return await runStage(
        context.supabase,
        context.userId,
        data.analysisId,
        data.stage as (typeof SERVER_STAGES)[number]["key"],
      );
    } catch (e) {
      friendly(e, "The analysis step could not be completed. Please try again.");
    }
  });

export const getAnalysis = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    try {
      return await loadAnalysisBundle(context.supabase, context.userId, data.id);
    } catch (e) {
      friendly(e, "Unable to retrieve analysis data. Please try again.");
    }
  });

export const listAnalyses = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z.object({ limit: z.number().int().min(1).max(200).default(50) }).parse(input ?? {}),
  )
  .handler(async ({ data, context }) => {
    const { supabase } = context;
    const { data: rows, error } = await supabase
      .from("analyses")
      .select(
        "id, patent_id, status, stage, progress, scoring_mode, dataset_mode, summary, created_at, completed_at, error_message",
      )
      .order("created_at", { ascending: false })
      .limit(data.limit);
    if (error) throw new Error("Unable to retrieve analysis data. Please try again.");
    const ids = [...new Set((rows ?? []).map((r) => r.patent_id))];
    const patents = ids.length
      ? ((await supabase.from("patents").select("id, patent_number, title, assignee").in("id", ids))
          .data ?? [])
      : [];
    const byId = new Map(patents.map((p) => [p.id, p]));
    return (rows ?? []).map((r) => ({ ...r, patent: byId.get(r.patent_id) ?? null }));
  });

export const deleteAnalysis = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase.from("analyses").delete().eq("id", data.id);
    if (error) throw new Error("Unable to delete the analysis.");
    return { ok: true };
  });

export const getClaimComparison = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({
        analysisId: z.string().uuid(),
        targetClaimId: z.string().uuid(),
        candidateClaimId: z.string().uuid(),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    try {
      return await compareClaims(
        context.supabase,
        context.userId,
        data.analysisId,
        data.targetClaimId,
        data.candidateClaimId,
      );
    } catch (e) {
      friendly(e, "Unable to compare these claims. Please try again.");
    }
  });

// ---------- Feature editing ----------

export const addFeature = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({
        analysisId: z.string().uuid(),
        claimId: z.string().uuid(),
        text: z.string().trim().min(2).max(300),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { data: last } = await supabase
      .from("claim_features")
      .select("feature_order")
      .eq("analysis_id", data.analysisId)
      .eq("claim_id", data.claimId)
      .order("feature_order", { ascending: false })
      .limit(1)
      .maybeSingle();
    const { error } = await supabase.from("claim_features").insert({
      analysis_id: data.analysisId,
      claim_id: data.claimId,
      feature_text: data.text,
      keywords: [...new Set(tokenize(data.text))],
      source: "manual",
      feature_order: (last?.feature_order ?? -1) + 1,
      user_id: userId,
    });
    if (error) throw new Error("Unable to add the feature.");
    return { ok: true };
  });

export const updateFeature = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z.object({ id: z.string().uuid(), text: z.string().trim().min(2).max(300) }).parse(input),
  )
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase
      .from("claim_features")
      .update({
        feature_text: data.text,
        keywords: [...new Set(tokenize(data.text))],
        source: "manual",
      })
      .eq("id", data.id);
    if (error) throw new Error("Unable to update the feature.");
    return { ok: true };
  });

export const deleteFeature = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase.from("claim_features").delete().eq("id", data.id);
    if (error) throw new Error("Unable to remove the feature.");
    return { ok: true };
  });

export const recomputeCoverage = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ analysisId: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { data: analysis } = await supabase
      .from("analyses")
      .select("*")
      .eq("id", data.analysisId)
      .maybeSingle();
    if (!analysis) throw new Error("Analysis not found.");
    try {
      return await stageCoverage(supabase, analysis, userId);
    } catch (e) {
      friendly(e, "Unable to recompute claim coverage. Please try again.");
    }
  });
