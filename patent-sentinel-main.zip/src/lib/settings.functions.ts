import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export const DEFAULT_SETTINGS = {
  semantic_weight: 0.6,
  keyword_weight: 0.25,
  classification_weight: 0.15,
  fallback_keyword_weight: 0.7,
  fallback_classification_weight: 0.3,
  similarity_threshold: 0.5,
  max_results: 10,
  embedding_provider: "lovable" as "lovable" | "custom" | "none",
  embedding_model: "google/gemini-embedding-2",
  custom_embedding_base_url: null as string | null,
  custom_embedding_model: null as string | null,
  search_mode: "hybrid" as "hybrid" | "keyword" | "semantic",
};

export type UserSettings = typeof DEFAULT_SETTINGS;

const SettingsSchema = z.object({
  semantic_weight: z.number().min(0).max(1),
  keyword_weight: z.number().min(0).max(1),
  classification_weight: z.number().min(0).max(1),
  fallback_keyword_weight: z.number().min(0).max(1),
  fallback_classification_weight: z.number().min(0).max(1),
  similarity_threshold: z.number().min(0).max(1),
  max_results: z.number().int().min(3).max(50),
  embedding_provider: z.enum(["lovable", "custom", "none"]),
  embedding_model: z.string().min(1).max(120),
  custom_embedding_base_url: z.string().url().max(300).nullable(),
  custom_embedding_model: z.string().max(120).nullable(),
  search_mode: z.enum(["hybrid", "keyword", "semantic"]),
});

export const getSettings = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase, userId } = context;
    const { data, error } = await supabase
      .from("user_settings")
      .select("*")
      .eq("user_id", userId)
      .maybeSingle();
    if (error) throw new Error("Unable to load settings. Please try again.");
    if (data) return toSettings(data);
    const { data: created, error: insErr } = await supabase
      .from("user_settings")
      .insert({ user_id: userId, ...DEFAULT_SETTINGS })
      .select("*")
      .single();
    if (insErr || !created) throw new Error("Unable to initialise settings. Please try again.");
    return toSettings(created);
  });

export const saveSettings = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => SettingsSchema.parse(input))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { data: row, error } = await supabase
      .from("user_settings")
      .upsert({ user_id: userId, ...data, updated_at: new Date().toISOString() })
      .select("*")
      .single();
    if (error || !row) throw new Error("Unable to save settings. Please try again.");
    return toSettings(row);
  });

export const resetSettings = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase, userId } = context;
    const { data: row, error } = await supabase
      .from("user_settings")
      .upsert({ user_id: userId, ...DEFAULT_SETTINGS, updated_at: new Date().toISOString() })
      .select("*")
      .single();
    if (error || !row) throw new Error("Unable to reset settings. Please try again.");
    return toSettings(row);
  });

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export function toSettings(row: any): UserSettings {
  return {
    semantic_weight: Number(row.semantic_weight),
    keyword_weight: Number(row.keyword_weight),
    classification_weight: Number(row.classification_weight),
    fallback_keyword_weight: Number(row.fallback_keyword_weight),
    fallback_classification_weight: Number(row.fallback_classification_weight),
    similarity_threshold: Number(row.similarity_threshold),
    max_results: Number(row.max_results),
    embedding_provider: row.embedding_provider,
    embedding_model: row.embedding_model,
    custom_embedding_base_url: row.custom_embedding_base_url ?? null,
    custom_embedding_model: row.custom_embedding_model ?? null,
    search_mode: row.search_mode,
  };
}
