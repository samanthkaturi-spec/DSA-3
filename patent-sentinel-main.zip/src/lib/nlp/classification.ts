// Classification (CPC / IPC) similarity based on hierarchical code overlap.

function norm(code: string): string {
  return code.toUpperCase().replace(/\s+/g, "");
}

/** Similarity between two single codes at hierarchy levels: section, class, subclass, main group, full. */
export function codeSimilarity(a: string, b: string): number {
  const x = norm(a);
  const y = norm(b);
  if (!x || !y) return 0;
  if (x === y) return 1;
  const mainX = x.split("/")[0]!;
  const mainY = y.split("/")[0]!;
  if (mainX === mainY) return 0.8;
  if (x.slice(0, 4) === y.slice(0, 4)) return 0.6;
  if (x.slice(0, 3) === y.slice(0, 3)) return 0.4;
  if (x[0] === y[0]) return 0.15;
  return 0;
}

/** Symmetric best-match average across two code sets. Returns 0..1. */
export function classificationSimilarity(a: string[], b: string[]): number {
  if (!a?.length || !b?.length) return 0;
  const dir = (from: string[], to: string[]) =>
    from.reduce((sum, c) => sum + Math.max(...to.map((d) => codeSimilarity(c, d))), 0) /
    from.length;
  return (dir(a, b) + dir(b, a)) / 2;
}

export function subclassOf(code: string): string {
  return norm(code).slice(0, 4);
}
export function classOf(code: string): string {
  return norm(code).slice(0, 3);
}
export function sectionOf(code: string): string {
  return norm(code).slice(0, 1);
}

export const CPC_SECTIONS: Record<string, string> = {
  A: "Human Necessities",
  B: "Operations & Transport",
  C: "Chemistry & Metallurgy",
  D: "Textiles & Paper",
  E: "Fixed Constructions",
  F: "Mechanical Engineering",
  G: "Physics",
  H: "Electricity",
  Y: "Emerging Technologies",
};
