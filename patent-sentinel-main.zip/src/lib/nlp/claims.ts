// Patent document structure extraction: title, abstract, claims.

export interface ExtractedClaim {
  claim_number: number;
  claim_text: string;
  is_independent: boolean;
  depends_on: number | null;
  claim_type: "system" | "method" | "crm";
}

export interface ExtractedDocument {
  title: string | null;
  abstract: string | null;
  claimsText: string | null;
  claims: ExtractedClaim[];
  patentNumber: string | null;
  description: string | null;
}

const DEPENDENCY_RE = /(?:of|to|in|with|by)\s+(?:any\s+(?:one\s+)?of\s+)?claims?\s+(\d{1,3})/i;

export function classifyClaim(text: string): ExtractedClaim["claim_type"] {
  const t = text.trim().toLowerCase();
  if (/^(a|an|the)?\s*(method|process)\b/.test(t)) return "method";
  if (
    /^(a|an|the)?\s*(non-transitory|computer[- ]readable|storage medium|machine[- ]readable)/.test(
      t,
    )
  )
    return "crm";
  return "system";
}

/** Split a block of claims text ("1. A system ... 2. The system of claim 1 ...") into claims. */
export function splitClaims(claimsText: string): ExtractedClaim[] {
  const text = claimsText.replace(/\r/g, "");
  // Split before a claim number at a line start or after sentence-ending punctuation.
  const parts = text.split(/(?:^|\n|(?<=[.;])\s+)(?=\d{1,3}\s*[.)]\s+[A-Z(])/g);
  const claims: ExtractedClaim[] = [];
  for (const raw of parts) {
    const m = raw.match(/^\s*(\d{1,3})\s*[.)]\s*([\s\S]*)$/);
    if (!m) continue;
    const num = Number(m[1]);
    const body = m[2]!.replace(/\s+/g, " ").trim();
    if (!body || body.length < 10) continue;
    const dep = body.match(DEPENDENCY_RE);
    const dependsOn = dep ? Number(dep[1]) : null;
    claims.push({
      claim_number: num,
      claim_text: body,
      is_independent: dependsOn === null,
      depends_on: dependsOn,
      claim_type: classifyClaim(body),
    });
  }
  // keep sequence sane – drop duplicate numbers keeping first
  const seen = new Set<number>();
  return claims.filter((c) =>
    seen.has(c.claim_number) ? false : (seen.add(c.claim_number), true),
  );
}

function sectionAfter(text: string, headingRe: RegExp, stopRe: RegExp): string | null {
  const m = headingRe.exec(text);
  if (!m) return null;
  const start = m.index + m[0].length;
  const rest = text.slice(start);
  const stop = stopRe.exec(rest);
  const section = stop ? rest.slice(0, stop.index) : rest;
  const cleaned = section.trim();
  return cleaned.length > 0 ? cleaned : null;
}

/** Extract title / abstract / claims / patent number from raw patent text. */
export function extractDocument(rawText: string): ExtractedDocument {
  const text = rawText.replace(/\r/g, "").replace(/\u00a0/g, " ");

  const numberMatch =
    text.match(/\b(?:US|EP|WO|CN|JP|KR|IN|DEMO-US)[- ]?\d{4,}(?:[- ]?[A-Z]\d?)?\b/i) ??
    text.match(/Patent\s+(?:No\.?|Number)[:\s]+([A-Z0-9/-]+)/i);
  const patentNumber = numberMatch ? (numberMatch[1] ?? numberMatch[0]).trim() : null;

  const claimsHeading =
    /(?:^|\n)\s*(?:claims?|what is claimed is|we claim|i claim|the invention claimed is)\s*[:.]?\s*(?=\n|\d)/i;
  let claimsText = sectionAfter(
    text,
    claimsHeading,
    /\n\s*(?:abstract|description|background|brief description|detailed description)\s*[:\n]/i,
  );
  if (!claimsText) {
    // fall back: find the first numbered claim pattern in the whole text
    const idx = text.search(/(?:^|\n)\s*1\s*[.)]\s+(?:A|An|The)\s+[a-z]/);
    if (idx >= 0) claimsText = text.slice(idx).trim();
  }
  const claims = claimsText ? splitClaims(claimsText) : [];

  const abstract = sectionAfter(
    text,
    /(?:^|\n)\s*abstract\s*(?:of the disclosure)?\s*[:.]?\s*\n?/i,
    /\n\s*(?:claims?|background|field|description|technical field|summary|what is claimed)\b/i,
  );

  let title: string | null = null;
  const titleTag = text.match(/(?:^|\n)\s*title\s*[:-]\s*(.+)/i);
  if (titleTag) title = titleTag[1]!.trim();
  if (!title) {
    const firstLine = text
      .split("\n")
      .map((l) => l.trim())
      .find(
        (l) =>
          l.length > 8 && l.length < 180 && !/^\d/.test(l) && !/^(abstract|claims?)\b/i.test(l),
      );
    title = firstLine ?? null;
  }

  const description = sectionAfter(
    text,
    /(?:^|\n)\s*(?:detailed description|description|background(?: of the invention)?)\s*[:.]?\s*\n/i,
    /\n\s*(?:claims?|what is claimed|abstract)\b/i,
  );

  return {
    title,
    abstract: abstract ? abstract.replace(/\s+/g, " ").slice(0, 2000) : null,
    claimsText,
    claims,
    patentNumber,
    description: description ? description.slice(0, 20000) : null,
  };
}
