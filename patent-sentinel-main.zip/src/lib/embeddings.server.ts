// Server-only embedding provider abstraction.
// Provider "lovable": Lovable AI Gateway (no user key needed).
// Provider "custom": any OpenAI-compatible /embeddings endpoint; the key is read
// from the CUSTOM_EMBEDDING_API_KEY backend secret – never from the client.

export interface EmbeddingConfig {
  provider: "lovable" | "custom" | "none";
  model: string;
  customBaseUrl?: string | null;
  customModel?: string | null;
}

export class EmbeddingUnavailableError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "EmbeddingUnavailableError";
  }
}

const BATCH = 100;

export async function embedTexts(texts: string[], cfg: EmbeddingConfig): Promise<number[][]> {
  if (cfg.provider === "none")
    throw new EmbeddingUnavailableError("Semantic embeddings are disabled in Settings.");
  if (texts.length === 0) return [];

  let url: string;
  let key: string | undefined;
  let model: string;
  if (cfg.provider === "custom") {
    if (!cfg.customBaseUrl)
      throw new EmbeddingUnavailableError("Custom embedding endpoint is not configured.");
    url = cfg.customBaseUrl.replace(/\/+$/, "") + "/embeddings";
    key = process.env["CUSTOM_EMBEDDING_API_KEY"];
    if (!key)
      throw new EmbeddingUnavailableError(
        "CUSTOM_EMBEDDING_API_KEY secret is not set on the backend.",
      );
    model = cfg.customModel || cfg.model;
  } else {
    url = "https://ai.gateway.lovable.dev/v1/embeddings";
    key = process.env["LOVABLE_API_KEY"];
    if (!key)
      throw new EmbeddingUnavailableError("Lovable AI key is not configured on the backend.");
    model = cfg.model || "google/gemini-embedding-2";
  }

  const out: number[][] = new Array(texts.length);
  for (let i = 0; i < texts.length; i += BATCH) {
    const batch = texts.slice(i, i + BATCH).map((t) => t.slice(0, 8000));
    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
      body: JSON.stringify({ model, input: batch }),
    });
    if (!res.ok) {
      const body = await res.text().catch(() => "");
      let msg = `Embedding service returned ${res.status}.`;
      if (res.status === 402) msg = "Embedding service credits are exhausted.";
      else if (res.status === 429) msg = "Embedding service rate limit reached.";
      else if (res.status === 401 || res.status === 403)
        msg = "Embedding service rejected the configured credentials.";
      console.error("[embeddings]", res.status, body.slice(0, 300));
      throw new EmbeddingUnavailableError(msg);
    }
    const json = (await res.json()) as { data: Array<{ index: number; embedding: number[] }> };
    for (const item of json.data) out[i + item.index] = item.embedding;
  }
  return out;
}

export function toVectorLiteral(vec: number[]): string {
  return "[" + vec.map((v) => Number(v.toFixed(6))).join(",") + "]";
}

export function parseVectorLiteral(v: unknown): number[] | null {
  if (!v) return null;
  if (Array.isArray(v)) return v as number[];
  if (typeof v === "string") {
    try {
      return JSON.parse(v) as number[];
    } catch {
      return null;
    }
  }
  return null;
}
