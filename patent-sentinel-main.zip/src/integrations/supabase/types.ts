export type Json = string | number | boolean | null | { [key: string]: Json | undefined } | Json[];

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5";
  };
  public: {
    Tables: {
      analyses: {
        Row: {
          completed_at: string | null;
          created_at: string;
          dataset_mode: string;
          error_message: string | null;
          id: string;
          patent_id: string;
          progress: number;
          scoring_mode: string | null;
          scoring_notice: string | null;
          settings_snapshot: Json;
          stage: string;
          status: string;
          summary: Json;
          user_id: string;
        };
        Insert: {
          completed_at?: string | null;
          created_at?: string;
          dataset_mode?: string;
          error_message?: string | null;
          id?: string;
          patent_id: string;
          progress?: number;
          scoring_mode?: string | null;
          scoring_notice?: string | null;
          settings_snapshot?: Json;
          stage?: string;
          status?: string;
          summary?: Json;
          user_id: string;
        };
        Update: {
          completed_at?: string | null;
          created_at?: string;
          dataset_mode?: string;
          error_message?: string | null;
          id?: string;
          patent_id?: string;
          progress?: number;
          scoring_mode?: string | null;
          scoring_notice?: string | null;
          settings_snapshot?: Json;
          stage?: string;
          status?: string;
          summary?: Json;
          user_id?: string;
        };
        Relationships: [
          {
            foreignKeyName: "analyses_patent_id_fkey";
            columns: ["patent_id"];
            isOneToOne: false;
            referencedRelation: "patents";
            referencedColumns: ["id"];
          },
        ];
      };
      analysis_claims: {
        Row: {
          analysis_id: string;
          claim_id: string;
          created_at: string;
          id: string;
          user_id: string;
        };
        Insert: {
          analysis_id: string;
          claim_id: string;
          created_at?: string;
          id?: string;
          user_id: string;
        };
        Update: {
          analysis_id?: string;
          claim_id?: string;
          created_at?: string;
          id?: string;
          user_id?: string;
        };
        Relationships: [
          {
            foreignKeyName: "analysis_claims_analysis_id_fkey";
            columns: ["analysis_id"];
            isOneToOne: false;
            referencedRelation: "analyses";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "analysis_claims_claim_id_fkey";
            columns: ["claim_id"];
            isOneToOne: false;
            referencedRelation: "patent_claims";
            referencedColumns: ["id"];
          },
        ];
      };
      analysis_references: {
        Row: {
          analysis_id: string;
          created_at: string;
          id: string;
          newly_covered_features: string[];
          patent_id: string;
          reason: string | null;
          selection_order: number;
          user_id: string;
        };
        Insert: {
          analysis_id: string;
          created_at?: string;
          id?: string;
          newly_covered_features?: string[];
          patent_id: string;
          reason?: string | null;
          selection_order?: number;
          user_id: string;
        };
        Update: {
          analysis_id?: string;
          created_at?: string;
          id?: string;
          newly_covered_features?: string[];
          patent_id?: string;
          reason?: string | null;
          selection_order?: number;
          user_id?: string;
        };
        Relationships: [
          {
            foreignKeyName: "analysis_references_analysis_id_fkey";
            columns: ["analysis_id"];
            isOneToOne: false;
            referencedRelation: "analyses";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "analysis_references_patent_id_fkey";
            columns: ["patent_id"];
            isOneToOne: false;
            referencedRelation: "patents";
            referencedColumns: ["id"];
          },
        ];
      };
      claim_features: {
        Row: {
          analysis_id: string;
          claim_id: string;
          created_at: string;
          feature_order: number;
          feature_text: string;
          id: string;
          keywords: string[];
          source: string;
          user_id: string;
        };
        Insert: {
          analysis_id: string;
          claim_id: string;
          created_at?: string;
          feature_order?: number;
          feature_text: string;
          id?: string;
          keywords?: string[];
          source?: string;
          user_id: string;
        };
        Update: {
          analysis_id?: string;
          claim_id?: string;
          created_at?: string;
          feature_order?: number;
          feature_text?: string;
          id?: string;
          keywords?: string[];
          source?: string;
          user_id?: string;
        };
        Relationships: [
          {
            foreignKeyName: "claim_features_analysis_id_fkey";
            columns: ["analysis_id"];
            isOneToOne: false;
            referencedRelation: "analyses";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "claim_features_claim_id_fkey";
            columns: ["claim_id"];
            isOneToOne: false;
            referencedRelation: "patent_claims";
            referencedColumns: ["id"];
          },
        ];
      };
      examiner_recommendations: {
        Row: {
          analysis_id: string;
          created_at: string;
          domain_match: number;
          examiner_id: string;
          experience_score: number;
          expertise_score: number;
          id: string;
          overall_score: number;
          rank: number;
          user_id: string;
          workload_score: number;
        };
        Insert: {
          analysis_id: string;
          created_at?: string;
          domain_match?: number;
          examiner_id: string;
          experience_score?: number;
          expertise_score?: number;
          id?: string;
          overall_score?: number;
          rank?: number;
          user_id: string;
          workload_score?: number;
        };
        Update: {
          analysis_id?: string;
          created_at?: string;
          domain_match?: number;
          examiner_id?: string;
          experience_score?: number;
          expertise_score?: number;
          id?: string;
          overall_score?: number;
          rank?: number;
          user_id?: string;
          workload_score?: number;
        };
        Relationships: [
          {
            foreignKeyName: "examiner_recommendations_analysis_id_fkey";
            columns: ["analysis_id"];
            isOneToOne: false;
            referencedRelation: "analyses";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "examiner_recommendations_examiner_id_fkey";
            columns: ["examiner_id"];
            isOneToOne: false;
            referencedRelation: "examiners";
            referencedColumns: ["id"];
          },
        ];
      };
      examiners: {
        Row: {
          cpc_expertise: string[];
          created_at: string;
          current_workload: number;
          examiner_code: string;
          experience_years: number;
          id: string;
          ipc_expertise: string[];
          is_demo: boolean;
          max_workload: number;
          name: string;
          technical_domains: string[];
        };
        Insert: {
          cpc_expertise?: string[];
          created_at?: string;
          current_workload?: number;
          examiner_code: string;
          experience_years?: number;
          id?: string;
          ipc_expertise?: string[];
          is_demo?: boolean;
          max_workload?: number;
          name: string;
          technical_domains?: string[];
        };
        Update: {
          cpc_expertise?: string[];
          created_at?: string;
          current_workload?: number;
          examiner_code?: string;
          experience_years?: number;
          id?: string;
          ipc_expertise?: string[];
          is_demo?: boolean;
          max_workload?: number;
          name?: string;
          technical_domains?: string[];
        };
        Relationships: [];
      };
      import_jobs: {
        Row: {
          created_at: string;
          duplicate_rows: number;
          errors: Json;
          file_name: string | null;
          id: string;
          imported_rows: number;
          invalid_rows: number;
          total_rows: number;
          user_id: string;
          valid_rows: number;
        };
        Insert: {
          created_at?: string;
          duplicate_rows?: number;
          errors?: Json;
          file_name?: string | null;
          id?: string;
          imported_rows?: number;
          invalid_rows?: number;
          total_rows?: number;
          user_id: string;
          valid_rows?: number;
        };
        Update: {
          created_at?: string;
          duplicate_rows?: number;
          errors?: Json;
          file_name?: string | null;
          id?: string;
          imported_rows?: number;
          invalid_rows?: number;
          total_rows?: number;
          user_id?: string;
          valid_rows?: number;
        };
        Relationships: [];
      };
      patent_citations: {
        Row: {
          citation_type: string;
          cited_patent_id: string;
          citing_patent_id: string;
          created_at: string;
          id: string;
          is_demo: boolean;
          owner_id: string | null;
        };
        Insert: {
          citation_type?: string;
          cited_patent_id: string;
          citing_patent_id: string;
          created_at?: string;
          id?: string;
          is_demo?: boolean;
          owner_id?: string | null;
        };
        Update: {
          citation_type?: string;
          cited_patent_id?: string;
          citing_patent_id?: string;
          created_at?: string;
          id?: string;
          is_demo?: boolean;
          owner_id?: string | null;
        };
        Relationships: [
          {
            foreignKeyName: "patent_citations_cited_patent_id_fkey";
            columns: ["cited_patent_id"];
            isOneToOne: false;
            referencedRelation: "patents";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "patent_citations_citing_patent_id_fkey";
            columns: ["citing_patent_id"];
            isOneToOne: false;
            referencedRelation: "patents";
            referencedColumns: ["id"];
          },
        ];
      };
      patent_claims: {
        Row: {
          claim_number: number;
          claim_text: string;
          claim_type: string;
          created_at: string;
          depends_on: number | null;
          embedding: unknown;
          embedding_model: string | null;
          id: string;
          is_demo: boolean;
          is_independent: boolean;
          owner_id: string | null;
          patent_id: string;
          search_vector: unknown;
        };
        Insert: {
          claim_number: number;
          claim_text: string;
          claim_type?: string;
          created_at?: string;
          depends_on?: number | null;
          embedding?: unknown;
          embedding_model?: string | null;
          id?: string;
          is_demo?: boolean;
          is_independent?: boolean;
          owner_id?: string | null;
          patent_id: string;
          search_vector?: unknown;
        };
        Update: {
          claim_number?: number;
          claim_text?: string;
          claim_type?: string;
          created_at?: string;
          depends_on?: number | null;
          embedding?: unknown;
          embedding_model?: string | null;
          id?: string;
          is_demo?: boolean;
          is_independent?: boolean;
          owner_id?: string | null;
          patent_id?: string;
          search_vector?: unknown;
        };
        Relationships: [
          {
            foreignKeyName: "patent_claims_patent_id_fkey";
            columns: ["patent_id"];
            isOneToOne: false;
            referencedRelation: "patents";
            referencedColumns: ["id"];
          },
        ];
      };
      patents: {
        Row: {
          abstract: string | null;
          assignee: string | null;
          claims: string | null;
          cpc_codes: string[];
          created_at: string;
          description: string | null;
          filing_date: string | null;
          id: string;
          inventors: string[];
          ipc_codes: string[];
          is_demo: boolean;
          owner_id: string | null;
          patent_number: string;
          priority_date: string | null;
          publication_date: string | null;
          search_vector: unknown;
          source: string;
          title: string;
        };
        Insert: {
          abstract?: string | null;
          assignee?: string | null;
          claims?: string | null;
          cpc_codes?: string[];
          created_at?: string;
          description?: string | null;
          filing_date?: string | null;
          id?: string;
          inventors?: string[];
          ipc_codes?: string[];
          is_demo?: boolean;
          owner_id?: string | null;
          patent_number: string;
          priority_date?: string | null;
          publication_date?: string | null;
          search_vector?: unknown;
          source?: string;
          title: string;
        };
        Update: {
          abstract?: string | null;
          assignee?: string | null;
          claims?: string | null;
          cpc_codes?: string[];
          created_at?: string;
          description?: string | null;
          filing_date?: string | null;
          id?: string;
          inventors?: string[];
          ipc_codes?: string[];
          is_demo?: boolean;
          owner_id?: string | null;
          patent_number?: string;
          priority_date?: string | null;
          publication_date?: string | null;
          search_vector?: unknown;
          source?: string;
          title?: string;
        };
        Relationships: [];
      };
      prior_art_results: {
        Row: {
          analysis_id: string;
          avg_combined_score: number;
          best_classification_score: number;
          best_combined_score: number;
          best_keyword_score: number;
          best_semantic_score: number | null;
          coverage: Json;
          covered_count: number;
          created_at: string;
          id: string;
          partial_count: number;
          patent_id: string;
          predates_target: boolean | null;
          rank: number;
          user_id: string;
        };
        Insert: {
          analysis_id: string;
          avg_combined_score?: number;
          best_classification_score?: number;
          best_combined_score?: number;
          best_keyword_score?: number;
          best_semantic_score?: number | null;
          coverage?: Json;
          covered_count?: number;
          created_at?: string;
          id?: string;
          partial_count?: number;
          patent_id: string;
          predates_target?: boolean | null;
          rank?: number;
          user_id: string;
        };
        Update: {
          analysis_id?: string;
          avg_combined_score?: number;
          best_classification_score?: number;
          best_combined_score?: number;
          best_keyword_score?: number;
          best_semantic_score?: number | null;
          coverage?: Json;
          covered_count?: number;
          created_at?: string;
          id?: string;
          partial_count?: number;
          patent_id?: string;
          predates_target?: boolean | null;
          rank?: number;
          user_id?: string;
        };
        Relationships: [
          {
            foreignKeyName: "prior_art_results_analysis_id_fkey";
            columns: ["analysis_id"];
            isOneToOne: false;
            referencedRelation: "analyses";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "prior_art_results_patent_id_fkey";
            columns: ["patent_id"];
            isOneToOne: false;
            referencedRelation: "patents";
            referencedColumns: ["id"];
          },
        ];
      };
      prior_art_shortlist: {
        Row: {
          created_at: string;
          id: string;
          note: string | null;
          patent_id: string;
          user_id: string;
        };
        Insert: {
          created_at?: string;
          id?: string;
          note?: string | null;
          patent_id: string;
          user_id: string;
        };
        Update: {
          created_at?: string;
          id?: string;
          note?: string | null;
          patent_id?: string;
          user_id?: string;
        };
        Relationships: [
          {
            foreignKeyName: "prior_art_shortlist_patent_id_fkey";
            columns: ["patent_id"];
            isOneToOne: false;
            referencedRelation: "patents";
            referencedColumns: ["id"];
          },
        ];
      };
      profiles: {
        Row: {
          created_at: string;
          email: string | null;
          full_name: string | null;
          id: string;
          organization: string | null;
          updated_at: string;
        };
        Insert: {
          created_at?: string;
          email?: string | null;
          full_name?: string | null;
          id: string;
          organization?: string | null;
          updated_at?: string;
        };
        Update: {
          created_at?: string;
          email?: string | null;
          full_name?: string | null;
          id?: string;
          organization?: string | null;
          updated_at?: string;
        };
        Relationships: [];
      };
      reports: {
        Row: {
          analysis_id: string;
          content: Json;
          created_at: string;
          id: string;
          title: string;
          user_id: string;
        };
        Insert: {
          analysis_id: string;
          content?: Json;
          created_at?: string;
          id?: string;
          title: string;
          user_id: string;
        };
        Update: {
          analysis_id?: string;
          content?: Json;
          created_at?: string;
          id?: string;
          title?: string;
          user_id?: string;
        };
        Relationships: [
          {
            foreignKeyName: "reports_analysis_id_fkey";
            columns: ["analysis_id"];
            isOneToOne: false;
            referencedRelation: "analyses";
            referencedColumns: ["id"];
          },
        ];
      };
      similarity_results: {
        Row: {
          analysis_id: string;
          candidate_claim_id: string;
          candidate_patent_id: string;
          classification_score: number;
          combined_score: number;
          created_at: string;
          id: string;
          keyword_score: number;
          matched_terms: string[];
          semantic_score: number | null;
          target_claim_id: string;
          user_id: string;
        };
        Insert: {
          analysis_id: string;
          candidate_claim_id: string;
          candidate_patent_id: string;
          classification_score?: number;
          combined_score?: number;
          created_at?: string;
          id?: string;
          keyword_score?: number;
          matched_terms?: string[];
          semantic_score?: number | null;
          target_claim_id: string;
          user_id: string;
        };
        Update: {
          analysis_id?: string;
          candidate_claim_id?: string;
          candidate_patent_id?: string;
          classification_score?: number;
          combined_score?: number;
          created_at?: string;
          id?: string;
          keyword_score?: number;
          matched_terms?: string[];
          semantic_score?: number | null;
          target_claim_id?: string;
          user_id?: string;
        };
        Relationships: [
          {
            foreignKeyName: "similarity_results_analysis_id_fkey";
            columns: ["analysis_id"];
            isOneToOne: false;
            referencedRelation: "analyses";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "similarity_results_candidate_claim_id_fkey";
            columns: ["candidate_claim_id"];
            isOneToOne: false;
            referencedRelation: "patent_claims";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "similarity_results_candidate_patent_id_fkey";
            columns: ["candidate_patent_id"];
            isOneToOne: false;
            referencedRelation: "patents";
            referencedColumns: ["id"];
          },
          {
            foreignKeyName: "similarity_results_target_claim_id_fkey";
            columns: ["target_claim_id"];
            isOneToOne: false;
            referencedRelation: "patent_claims";
            referencedColumns: ["id"];
          },
        ];
      };
      user_settings: {
        Row: {
          classification_weight: number;
          custom_embedding_base_url: string | null;
          custom_embedding_model: string | null;
          dataset_mode: string;
          embedding_model: string;
          embedding_provider: string;
          fallback_classification_weight: number;
          fallback_keyword_weight: number;
          keyword_weight: number;
          max_results: number;
          search_mode: string;
          semantic_weight: number;
          similarity_threshold: number;
          updated_at: string;
          user_id: string;
        };
        Insert: {
          classification_weight?: number;
          custom_embedding_base_url?: string | null;
          custom_embedding_model?: string | null;
          dataset_mode?: string;
          embedding_model?: string;
          embedding_provider?: string;
          fallback_classification_weight?: number;
          fallback_keyword_weight?: number;
          keyword_weight?: number;
          max_results?: number;
          search_mode?: string;
          semantic_weight?: number;
          similarity_threshold?: number;
          updated_at?: string;
          user_id: string;
        };
        Update: {
          classification_weight?: number;
          custom_embedding_base_url?: string | null;
          custom_embedding_model?: string | null;
          dataset_mode?: string;
          embedding_model?: string;
          embedding_provider?: string;
          fallback_classification_weight?: number;
          fallback_keyword_weight?: number;
          keyword_weight?: number;
          max_results?: number;
          search_mode?: string;
          semantic_weight?: number;
          similarity_threshold?: number;
          updated_at?: string;
          user_id?: string;
        };
        Relationships: [];
      };
    };
    Views: {
      [_ in never]: never;
    };
    Functions: {
      dashboard_stats: { Args: never; Returns: Json };
      immutable_array_to_string: { Args: { arr: string[] }; Returns: string };
      match_claims: {
        Args: {
          dataset?: string;
          exclude_patent?: string;
          match_count?: number;
          query_embedding: unknown;
        };
        Returns: {
          claim_id: string;
          patent_id: string;
          similarity: number;
        }[];
      };
      search_patents: {
        Args: {
          assignee_filter?: string;
          cpc_filter?: string;
          dataset?: string;
          field?: string;
          filing_from?: string;
          filing_to?: string;
          ipc_filter?: string;
          lim?: number;
          pub_from?: string;
          pub_to?: string;
          q?: string;
        };
        Returns: {
          abstract: string;
          assignee: string;
          citation_count: number;
          claim_count: number;
          cpc_codes: string[];
          filing_date: string;
          id: string;
          inventors: string[];
          ipc_codes: string[];
          is_demo: boolean;
          patent_number: string;
          priority_date: string;
          publication_date: string;
          rank: number;
          source: string;
          title: string;
        }[];
      };
      split_claims_text: {
        Args: { txt: string };
        Returns: {
          claim_number: number;
          claim_text: string;
          depends_on: number;
          is_independent: boolean;
        }[];
      };
    };
    Enums: {
      [_ in never]: never;
    };
    CompositeTypes: {
      [_ in never]: never;
    };
  };
};

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">;

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">];

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals;
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals;
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R;
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] & DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R;
      }
      ? R
      : never
    : never;

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    keyof DefaultSchema["Tables"] | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals;
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals;
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I;
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I;
      }
      ? I
      : never
    : never;

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    keyof DefaultSchema["Tables"] | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals;
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals;
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U;
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U;
      }
      ? U
      : never
    : never;

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    keyof DefaultSchema["Enums"] | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals;
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals;
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never;

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    keyof DefaultSchema["CompositeTypes"] | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals;
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals;
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never;

export const Constants = {
  public: {
    Enums: {},
  },
} as const;
