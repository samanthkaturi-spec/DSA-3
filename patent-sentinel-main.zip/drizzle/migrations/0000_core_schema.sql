create extension if not exists vector with schema extensions;

create or replace function public.immutable_array_to_string(arr text[])
returns text language sql immutable strict as $$ select array_to_string(arr, ' ') $$;

-- ========== Profiles ==========
create table public.profiles (
  id uuid primary key,
  email text,
  full_name text,
  organization text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
grant select, insert, update on public.profiles to authenticated;
grant all on public.profiles to service_role;
alter table public.profiles enable row level security;
create policy "profiles_select_own" on public.profiles for select to authenticated using (id = auth.uid());
create policy "profiles_insert_own" on public.profiles for insert to authenticated with check (id = auth.uid());
create policy "profiles_update_own" on public.profiles for update to authenticated using (id = auth.uid());

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, email, full_name)
  values (new.id, new.email, coalesce(new.raw_user_meta_data->>'full_name', ''))
  on conflict (id) do nothing;
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users
for each row execute function public.handle_new_user();

-- ========== User settings ==========
create table public.user_settings (
  user_id uuid primary key,
  semantic_weight numeric not null default 0.60,
  keyword_weight numeric not null default 0.25,
  classification_weight numeric not null default 0.15,
  fallback_keyword_weight numeric not null default 0.70,
  fallback_classification_weight numeric not null default 0.30,
  similarity_threshold numeric not null default 0.50,
  max_results integer not null default 10,
  embedding_provider text not null default 'lovable',
  embedding_model text not null default 'google/gemini-embedding-2',
  custom_embedding_base_url text,
  custom_embedding_model text,
  search_mode text not null default 'hybrid',
  dataset_mode text not null default 'demo',
  updated_at timestamptz not null default now()
);
grant select, insert, update, delete on public.user_settings to authenticated;
grant all on public.user_settings to service_role;
alter table public.user_settings enable row level security;
create policy "settings_all_own" on public.user_settings for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

-- ========== Patents ==========
create table public.patents (
  id uuid primary key default gen_random_uuid(),
  patent_number text not null,
  title text not null,
  abstract text,
  description text,
  claims text,
  inventors text[] not null default '{}',
  assignee text,
  filing_date date,
  publication_date date,
  priority_date date,
  cpc_codes text[] not null default '{}',
  ipc_codes text[] not null default '{}',
  source text not null default 'imported',
  is_demo boolean not null default false,
  owner_id uuid,
  created_at timestamptz not null default now(),
  search_vector tsvector generated always as (
    setweight(to_tsvector('english', coalesce(patent_number,'')), 'A') ||
    setweight(to_tsvector('english', coalesce(title,'')), 'A') ||
    setweight(to_tsvector('english', coalesce(abstract,'')), 'B') ||
    setweight(to_tsvector('english', coalesce(claims,'')), 'C') ||
    setweight(to_tsvector('english', coalesce(assignee,'')), 'B') ||
    setweight(to_tsvector('english', coalesce(public.immutable_array_to_string(inventors),'')), 'B')
  ) stored,
  unique (patent_number, owner_id)
);
create index patents_search_idx on public.patents using gin (search_vector);
create index patents_owner_idx on public.patents (owner_id);
create index patents_demo_idx on public.patents (is_demo);
grant select, insert, update, delete on public.patents to authenticated;
grant all on public.patents to service_role;
alter table public.patents enable row level security;
create policy "patents_select_visible" on public.patents for select to authenticated using (is_demo = true or owner_id = auth.uid());
create policy "patents_insert_own" on public.patents for insert to authenticated with check (owner_id = auth.uid() and is_demo = false);
create policy "patents_update_own" on public.patents for update to authenticated using (owner_id = auth.uid());
create policy "patents_delete_own" on public.patents for delete to authenticated using (owner_id = auth.uid());

-- ========== Claims ==========
create table public.patent_claims (
  id uuid primary key default gen_random_uuid(),
  patent_id uuid not null references public.patents(id) on delete cascade,
  claim_number integer not null,
  claim_type text not null default 'system',
  claim_text text not null,
  is_independent boolean not null default true,
  depends_on integer,
  is_demo boolean not null default false,
  owner_id uuid,
  embedding extensions.halfvec(3072),
  embedding_model text,
  created_at timestamptz not null default now(),
  search_vector tsvector generated always as (to_tsvector('english', coalesce(claim_text,''))) stored
);
create index claims_patent_idx on public.patent_claims (patent_id);
create index claims_search_idx on public.patent_claims using gin (search_vector);
create index claims_embedding_idx on public.patent_claims using hnsw (embedding extensions.halfvec_cosine_ops);
grant select, insert, update, delete on public.patent_claims to authenticated;
grant all on public.patent_claims to service_role;
alter table public.patent_claims enable row level security;
create policy "claims_select_visible" on public.patent_claims for select to authenticated using (is_demo = true or owner_id = auth.uid());
create policy "claims_insert_own" on public.patent_claims for insert to authenticated with check (owner_id = auth.uid() and is_demo = false);
create policy "claims_update_visible" on public.patent_claims for update to authenticated using (is_demo = true or owner_id = auth.uid());
create policy "claims_delete_own" on public.patent_claims for delete to authenticated using (owner_id = auth.uid());

-- ========== Citations ==========
create table public.patent_citations (
  id uuid primary key default gen_random_uuid(),
  citing_patent_id uuid not null references public.patents(id) on delete cascade,
  cited_patent_id uuid not null references public.patents(id) on delete cascade,
  citation_type text not null default 'applicant',
  is_demo boolean not null default false,
  owner_id uuid,
  created_at timestamptz not null default now(),
  unique (citing_patent_id, cited_patent_id)
);
create index citations_citing_idx on public.patent_citations (citing_patent_id);
create index citations_cited_idx on public.patent_citations (cited_patent_id);
grant select, insert, update, delete on public.patent_citations to authenticated;
grant all on public.patent_citations to service_role;
alter table public.patent_citations enable row level security;
create policy "citations_select_visible" on public.patent_citations for select to authenticated using (is_demo = true or owner_id = auth.uid());
create policy "citations_insert_own" on public.patent_citations for insert to authenticated with check (owner_id = auth.uid() and is_demo = false);
create policy "citations_delete_own" on public.patent_citations for delete to authenticated using (owner_id = auth.uid());

-- ========== Analyses ==========
create table public.analyses (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,
  patent_id uuid not null references public.patents(id) on delete cascade,
  status text not null default 'pending',
  stage text not null default 'created',
  progress integer not null default 0,
  scoring_mode text,
  scoring_notice text,
  dataset_mode text not null default 'demo',
  settings_snapshot jsonb not null default '{}'::jsonb,
  summary jsonb not null default '{}'::jsonb,
  error_message text,
  created_at timestamptz not null default now(),
  completed_at timestamptz
);
create index analyses_user_idx on public.analyses (user_id, created_at desc);
grant select, insert, update, delete on public.analyses to authenticated;
grant all on public.analyses to service_role;
alter table public.analyses enable row level security;
create policy "analyses_all_own" on public.analyses for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

create table public.analysis_claims (
  id uuid primary key default gen_random_uuid(),
  analysis_id uuid not null references public.analyses(id) on delete cascade,
  claim_id uuid not null references public.patent_claims(id) on delete cascade,
  user_id uuid not null,
  created_at timestamptz not null default now(),
  unique (analysis_id, claim_id)
);
grant select, insert, update, delete on public.analysis_claims to authenticated;
grant all on public.analysis_claims to service_role;
alter table public.analysis_claims enable row level security;
create policy "analysis_claims_all_own" on public.analysis_claims for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

create table public.claim_features (
  id uuid primary key default gen_random_uuid(),
  analysis_id uuid not null references public.analyses(id) on delete cascade,
  claim_id uuid not null references public.patent_claims(id) on delete cascade,
  feature_order integer not null default 0,
  feature_text text not null,
  keywords text[] not null default '{}',
  source text not null default 'auto',
  user_id uuid not null,
  created_at timestamptz not null default now()
);
create index claim_features_analysis_idx on public.claim_features (analysis_id);
grant select, insert, update, delete on public.claim_features to authenticated;
grant all on public.claim_features to service_role;
alter table public.claim_features enable row level security;
create policy "claim_features_all_own" on public.claim_features for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

create table public.similarity_results (
  id uuid primary key default gen_random_uuid(),
  analysis_id uuid not null references public.analyses(id) on delete cascade,
  target_claim_id uuid not null references public.patent_claims(id) on delete cascade,
  candidate_claim_id uuid not null references public.patent_claims(id) on delete cascade,
  candidate_patent_id uuid not null references public.patents(id) on delete cascade,
  semantic_score numeric,
  keyword_score numeric not null default 0,
  classification_score numeric not null default 0,
  combined_score numeric not null default 0,
  matched_terms text[] not null default '{}',
  user_id uuid not null,
  created_at timestamptz not null default now()
);
create index similarity_results_analysis_idx on public.similarity_results (analysis_id, combined_score desc);
grant select, insert, update, delete on public.similarity_results to authenticated;
grant all on public.similarity_results to service_role;
alter table public.similarity_results enable row level security;
create policy "similarity_results_all_own" on public.similarity_results for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

create table public.prior_art_results (
  id uuid primary key default gen_random_uuid(),
  analysis_id uuid not null references public.analyses(id) on delete cascade,
  patent_id uuid not null references public.patents(id) on delete cascade,
  rank integer not null default 0,
  best_combined_score numeric not null default 0,
  avg_combined_score numeric not null default 0,
  best_semantic_score numeric,
  best_keyword_score numeric not null default 0,
  best_classification_score numeric not null default 0,
  coverage jsonb not null default '{}'::jsonb,
  covered_count integer not null default 0,
  partial_count integer not null default 0,
  predates_target boolean,
  user_id uuid not null,
  created_at timestamptz not null default now(),
  unique (analysis_id, patent_id)
);
grant select, insert, update, delete on public.prior_art_results to authenticated;
grant all on public.prior_art_results to service_role;
alter table public.prior_art_results enable row level security;
create policy "prior_art_results_all_own" on public.prior_art_results for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

create table public.analysis_references (
  id uuid primary key default gen_random_uuid(),
  analysis_id uuid not null references public.analyses(id) on delete cascade,
  patent_id uuid not null references public.patents(id) on delete cascade,
  selection_order integer not null default 0,
  newly_covered_features uuid[] not null default '{}',
  reason text,
  user_id uuid not null,
  created_at timestamptz not null default now()
);
grant select, insert, update, delete on public.analysis_references to authenticated;
grant all on public.analysis_references to service_role;
alter table public.analysis_references enable row level security;
create policy "analysis_references_all_own" on public.analysis_references for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

-- ========== Examiners ==========
create table public.examiners (
  id uuid primary key default gen_random_uuid(),
  examiner_code text not null unique,
  name text not null,
  technical_domains text[] not null default '{}',
  cpc_expertise text[] not null default '{}',
  ipc_expertise text[] not null default '{}',
  current_workload integer not null default 0,
  max_workload integer not null default 40,
  experience_years integer not null default 1,
  is_demo boolean not null default true,
  created_at timestamptz not null default now()
);
grant select on public.examiners to authenticated;
grant all on public.examiners to service_role;
alter table public.examiners enable row level security;
create policy "examiners_select_all" on public.examiners for select to authenticated using (true);

create table public.examiner_recommendations (
  id uuid primary key default gen_random_uuid(),
  analysis_id uuid not null references public.analyses(id) on delete cascade,
  examiner_id uuid not null references public.examiners(id) on delete cascade,
  domain_match numeric not null default 0,
  expertise_score numeric not null default 0,
  workload_score numeric not null default 0,
  experience_score numeric not null default 0,
  overall_score numeric not null default 0,
  rank integer not null default 0,
  user_id uuid not null,
  created_at timestamptz not null default now()
);
grant select, insert, update, delete on public.examiner_recommendations to authenticated;
grant all on public.examiner_recommendations to service_role;
alter table public.examiner_recommendations enable row level security;
create policy "examiner_recs_all_own" on public.examiner_recommendations for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

-- ========== Reports ==========
create table public.reports (
  id uuid primary key default gen_random_uuid(),
  analysis_id uuid not null references public.analyses(id) on delete cascade,
  user_id uuid not null,
  title text not null,
  content jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
grant select, insert, update, delete on public.reports to authenticated;
grant all on public.reports to service_role;
alter table public.reports enable row level security;
create policy "reports_all_own" on public.reports for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

-- ========== User prior-art shortlist ==========
create table public.prior_art_shortlist (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,
  patent_id uuid not null references public.patents(id) on delete cascade,
  note text,
  created_at timestamptz not null default now(),
  unique (user_id, patent_id)
);
grant select, insert, update, delete on public.prior_art_shortlist to authenticated;
grant all on public.prior_art_shortlist to service_role;
alter table public.prior_art_shortlist enable row level security;
create policy "shortlist_all_own" on public.prior_art_shortlist for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

-- ========== Import jobs ==========
create table public.import_jobs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,
  file_name text,
  total_rows integer not null default 0,
  valid_rows integer not null default 0,
  invalid_rows integer not null default 0,
  duplicate_rows integer not null default 0,
  imported_rows integer not null default 0,
  errors jsonb not null default '[]'::jsonb,
  created_at timestamptz not null default now()
);
grant select, insert, update, delete on public.import_jobs to authenticated;
grant all on public.import_jobs to service_role;
alter table public.import_jobs enable row level security;
create policy "import_jobs_all_own" on public.import_jobs for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

-- ========== Search function (security invoker, RLS applies) ==========
create or replace function public.search_patents(
  q text default '',
  field text default 'all',
  dataset text default 'all',
  cpc_filter text default null,
  ipc_filter text default null,
  assignee_filter text default null,
  pub_from date default null,
  pub_to date default null,
  filing_from date default null,
  filing_to date default null,
  lim integer default 50
)
returns table (
  id uuid, patent_number text, title text, abstract text, assignee text,
  publication_date date, filing_date date, priority_date date,
  cpc_codes text[], ipc_codes text[], inventors text[], is_demo boolean, source text,
  claim_count bigint, citation_count bigint, rank real
)
language sql stable security invoker set search_path = public as $$
  with base as (
    select p.*,
      case when coalesce(q,'') = '' then 0::real
           else ts_rank(p.search_vector, websearch_to_tsquery('english', q)) end as rnk
    from public.patents p
    where (dataset = 'all' or (dataset = 'demo' and p.is_demo) or (dataset = 'imported' and not p.is_demo))
      and (cpc_filter is null or exists (select 1 from unnest(p.cpc_codes) c where c ilike cpc_filter || '%'))
      and (ipc_filter is null or exists (select 1 from unnest(p.ipc_codes) c where c ilike ipc_filter || '%'))
      and (assignee_filter is null or p.assignee ilike '%' || assignee_filter || '%')
      and (pub_from is null or p.publication_date >= pub_from)
      and (pub_to is null or p.publication_date <= pub_to)
      and (filing_from is null or p.filing_date >= filing_from)
      and (filing_to is null or p.filing_date <= filing_to)
      and (
        coalesce(q,'') = '' or
        case field
          when 'patent_number' then p.patent_number ilike '%' || q || '%'
          when 'title' then p.title ilike '%' || q || '%'
          when 'abstract' then p.abstract ilike '%' || q || '%'
          when 'claims' then p.claims ilike '%' || q || '%'
          when 'inventor' then exists (select 1 from unnest(p.inventors) i where i ilike '%' || q || '%')
          when 'assignee' then p.assignee ilike '%' || q || '%'
          when 'cpc' then exists (select 1 from unnest(p.cpc_codes) c where c ilike q || '%')
          when 'ipc' then exists (select 1 from unnest(p.ipc_codes) c where c ilike q || '%')
          else (p.search_vector @@ websearch_to_tsquery('english', q) or p.patent_number ilike '%' || q || '%')
        end
      )
  )
  select b.id, b.patent_number, b.title, b.abstract, b.assignee, b.publication_date, b.filing_date, b.priority_date,
    b.cpc_codes, b.ipc_codes, b.inventors, b.is_demo, b.source,
    (select count(*) from public.patent_claims c where c.patent_id = b.id) as claim_count,
    (select count(*) from public.patent_citations ct where ct.cited_patent_id = b.id) as citation_count,
    b.rnk as rank
  from base b
  order by b.rnk desc, b.publication_date desc nulls last
  limit lim;
$$;
grant execute on function public.search_patents to authenticated;

-- ========== Vector match (RLS applies via security invoker) ==========
create or replace function public.match_claims(
  query_embedding extensions.halfvec(3072),
  match_count integer default 50,
  exclude_patent uuid default null,
  dataset text default 'all'
)
returns table (claim_id uuid, patent_id uuid, similarity double precision)
language sql stable security invoker set search_path = public, extensions as $$
  select c.id, c.patent_id, 1 - (c.embedding <=> query_embedding) as similarity
  from public.patent_claims c
  where c.embedding is not null
    and (exclude_patent is null or c.patent_id <> exclude_patent)
    and (dataset = 'all' or (dataset = 'demo' and c.is_demo) or (dataset = 'imported' and not c.is_demo))
  order by c.embedding <=> query_embedding
  limit match_count;
$$;
grant execute on function public.match_claims to authenticated;

-- ========== Dashboard stats ==========
create or replace function public.dashboard_stats()
returns jsonb language sql stable security invoker set search_path = public as $$
  select jsonb_build_object(
    'total_patents', (select count(*) from public.patents),
    'total_claims', (select count(*) from public.patent_claims),
    'total_analyses', (select count(*) from public.analyses where user_id = auth.uid()),
    'references_found', (select count(*) from public.prior_art_results where user_id = auth.uid()),
    'avg_similarity', (select coalesce(avg(best_combined_score),0) from public.prior_art_results where user_id = auth.uid()),
    'citation_count', (select count(*) from public.patent_citations)
  );
$$;
grant execute on function public.dashboard_stats to authenticated;

-- ========== Claim splitter used by seed + imports ==========
create or replace function public.split_claims_text(txt text)
returns table (claim_number integer, claim_text text, is_independent boolean, depends_on integer)
language plpgsql immutable as $$
declare
  parts text[];
  part text;
  n integer;
  body text;
  dep integer;
begin
  parts := regexp_split_to_array(coalesce(txt,''), E'(?:^|\\n)\\s*(?=\\d{1,3}\\.\\s)');
  foreach part in array parts loop
    if btrim(part) = '' then continue; end if;
    n := (regexp_match(part, '^\s*(\d{1,3})\.'))[1]::integer;
    body := btrim(regexp_replace(part, '^\s*\d{1,3}\.\s*', ''));
    dep := (regexp_match(body, '(?:of|to|in|with) (?:any of )?claims? (\d{1,3})', 'i'))[1]::integer;
    claim_number := n; claim_text := body; is_independent := dep is null; depends_on := dep;
    return next;
  end loop;
end $$;
grant execute on function public.split_claims_text to authenticated;

-- when a patent is inserted with claims text, auto-create claim rows if none exist
create or replace function public.patents_after_insert_claims()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if coalesce(new.claims,'') <> '' and not exists (select 1 from public.patent_claims c where c.patent_id = new.id) then
    insert into public.patent_claims (patent_id, claim_number, claim_text, is_independent, depends_on, claim_type, is_demo, owner_id)
    select new.id, s.claim_number, s.claim_text, s.is_independent, s.depends_on,
      case
        when s.claim_text ~* '^(a|an|the)?\s*(method|process)' then 'method'
        when s.claim_text ~* '^(a|an|the)?\s*(non-transitory|computer[- ]readable|storage medium)' then 'crm'
        else 'system' end,
      new.is_demo, new.owner_id
    from public.split_claims_text(new.claims) s;
  end if;
  return new;
end $$;
create trigger patents_claims_autofill after insert on public.patents
for each row execute function public.patents_after_insert_claims();