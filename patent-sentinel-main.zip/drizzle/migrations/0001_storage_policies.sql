create policy "docs_insert_own" on storage.objects for insert to authenticated
  with check (bucket_id = 'patent-documents' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "docs_select_own" on storage.objects for select to authenticated
  using (bucket_id = 'patent-documents' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "docs_delete_own" on storage.objects for delete to authenticated
  using (bucket_id = 'patent-documents' and (storage.foldername(name))[1] = auth.uid()::text);