<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

## Architecture rules
- All app-internal backend logic lives in `src/lib/*.functions.ts` (createServerFn + requireSupabaseAuth); heavy pipeline code is in `*.server.ts` so it never reaches the browser bundle.
- The analysis pipeline runs stage-by-stage (`src/lib/analysis-stages.ts`); the client calls one stage per request so progress is real and each stage stays under worker time limits.
- Similarity is never random: TF-IDF cosine + CPC/IPC scoring always; embeddings (pgvector halfvec 3072, `google/gemini-embedding-2`) only when configured, otherwise the labelled keyword fallback (0.70/0.30).
- Parent list routes with a `$id` child use `*.index.tsx` (e.g. `reports.index.tsx`) so the detail route renders without an Outlet.
- Demo rows are `is_demo = true` and read-only to users; imported rows are owner-scoped via RLS. Never present demo patents as real.
