export interface GraphEdge {
  source: string;
  target: string;
}

export interface NodeMetrics {
  inDegree: number;
  outDegree: number;
  degree: number;
  degreeCentrality: number;
  pagerank: number;
}

export function computeGraphMetrics(nodeIds: string[], edges: GraphEdge[], damping = 0.85, iterations = 60) {
  const ids = [...new Set(nodeIds)];
  const n = ids.length;
  const idx = new Map(ids.map((id, i) => [id, i]));
  const inDeg = new Array<number>(n).fill(0);
  const outDeg = new Array<number>(n).fill(0);
  const outLinks: number[][] = ids.map(() => []);
  for (const e of edges) {
    const s = idx.get(e.source);
    const t = idx.get(e.target);
    if (s === undefined || t === undefined) continue;
    outDeg[s]!++;
    inDeg[t]!++;
    outLinks[s]!.push(t);
  }
  // PageRank (power iteration)
  let pr = new Array<number>(n).fill(n ? 1 / n : 0);
  for (let it = 0; it < iterations && n > 0; it++) {
    const next = new Array<number>(n).fill((1 - damping) / n);
    let dangling = 0;
    for (let i = 0; i < n; i++) {
      if (outLinks[i]!.length === 0) {
        dangling += pr[i]!;
        continue;
      }
      const share = (damping * pr[i]!) / outLinks[i]!.length;
      for (const t of outLinks[i]!) next[t]! += share;
    }
    const dShare = (damping * dangling) / n;
    for (let i = 0; i < n; i++) next[i]! += dShare;
    pr = next;
  }
  const metrics = new Map<string, NodeMetrics>();
  ids.forEach((id, i) => {
    metrics.set(id, {
      inDegree: inDeg[i]!,
      outDegree: outDeg[i]!,
      degree: inDeg[i]! + outDeg[i]!,
      degreeCentrality: n > 1 ? (inDeg[i]! + outDeg[i]!) / (n - 1) : 0,
      pagerank: pr[i]!,
    });
  });
  return metrics;
}
