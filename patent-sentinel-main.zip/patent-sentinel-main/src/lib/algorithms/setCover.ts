// Greedy Set Cover: choose a small set of references whose feature coverage
// jointly covers as many target features as possible.

export interface SetCoverCandidate {
  id: string;
  covers: Set<string>; // feature ids fully covered
  partial?: Set<string>; // feature ids partially covered (tie-breaker only)
  weight?: number; // e.g. similarity score, tie-breaker
  label?: string;
}

export interface SetCoverStep {
  id: string;
  label?: string | undefined;
  order: number;
  newlyCovered: string[];
  cumulativeCovered: number;
  reason: string;
}

export interface SetCoverResult {
  selected: SetCoverStep[];
  coveredFeatures: string[];
  uncoveredFeatures: string[];
  coveragePct: number;
}

export function greedySetCover(universe: string[], candidates: SetCoverCandidate[]): SetCoverResult {
  const remaining = new Set(universe);
  const selected: SetCoverStep[] = [];
  const available = new Map(candidates.map((c) => [c.id, c]));
  const total = universe.length;

  while (remaining.size > 0 && available.size > 0) {
    let best: SetCoverCandidate | null = null;
    let bestGain: string[] = [];
    let bestPartialGain = 0;
    for (const cand of available.values()) {
      const gain = [...cand.covers].filter((f) => remaining.has(f));
      const partialGain = cand.partial ? [...cand.partial].filter((f) => remaining.has(f)).length : 0;
      const better =
        gain.length > bestGain.length ||
        (gain.length === bestGain.length &&
          gain.length > 0 &&
          (partialGain > bestPartialGain ||
            (partialGain === bestPartialGain && (cand.weight ?? 0) > (best?.weight ?? 0))));
      if (better) {
        best = cand;
        bestGain = gain;
        bestPartialGain = partialGain;
      }
    }
    if (!best || bestGain.length === 0) break;
    for (const f of bestGain) remaining.delete(f);
    available.delete(best.id);
    const covered = total - remaining.size;
    selected.push({
      id: best.id,
      label: best.label,
      order: selected.length + 1,
      newlyCovered: bestGain,
      cumulativeCovered: covered,
      reason: `Selected at step ${selected.length + 1}: adds ${bestGain.length} previously uncovered feature${bestGain.length === 1 ? "" : "s"}${bestPartialGain ? ` (+${bestPartialGain} partial)` : ""}, bringing cumulative coverage to ${covered}/${total}${best.weight !== undefined ? `; similarity ${(best.weight * 100).toFixed(0)}%` : ""}.`,
    });
  }

  const coveredFeatures = universe.filter((f) => !remaining.has(f));
  return {
    selected,
    coveredFeatures,
    uncoveredFeatures: [...remaining],
    coveragePct: total === 0 ? 0 : coveredFeatures.length / total,
  };
}
