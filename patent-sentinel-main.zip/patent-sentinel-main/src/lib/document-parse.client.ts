// Browser-side text extraction for uploaded patent documents.
export const ACCEPTED_TYPES = [".pdf", ".txt", ".docx", ".md"];
export const MAX_FILE_BYTES = 20 * 1024 * 1024;

export class DocumentParseError extends Error {}

export async function extractTextFromFile(file: File, onProgress?: (msg: string) => void): Promise<string> {
  if (file.size > MAX_FILE_BYTES) throw new DocumentParseError("The file exceeds the 20 MB upload limit.");
  const name = file.name.toLowerCase();
  try {
    if (name.endsWith(".pdf")) {
      onProgress?.("Reading PDF pages…");
      const pdfjs = await import("pdfjs-dist");
      const worker = await import("pdfjs-dist/build/pdf.worker.min.mjs?url");
      pdfjs.GlobalWorkerOptions.workerSrc = worker.default;
      const buf = await file.arrayBuffer();
      const doc = await pdfjs.getDocument({ data: buf }).promise;
      const pages: string[] = [];
      for (let i = 1; i <= doc.numPages; i++) {
        onProgress?.(`Extracting text from page ${i} of ${doc.numPages}…`);
        const page = await doc.getPage(i);
        const content = await page.getTextContent();
        let last: number | null = null;
        let line = "";
        const lines: string[] = [];
        for (const item of content.items) {
          if (!("str" in item)) continue;
          const y = Math.round((item.transform as number[])[5] ?? 0);
          if (last !== null && Math.abs(y - last) > 2) {
            lines.push(line.trim());
            line = "";
          }
          line += item.str + (item.hasEOL ? "\n" : " ");
          last = y;
        }
        lines.push(line.trim());
        pages.push(lines.join("\n"));
      }
      const text = pages.join("\n\n");
      if (text.replace(/\s+/g, "").length < 40) {
        throw new DocumentParseError("This PDF contains no extractable text (it may be a scanned image). Please upload a text-based PDF or paste the text.");
      }
      return text;
    }
    if (name.endsWith(".docx")) {
      onProgress?.("Reading DOCX…");
      const mammoth = await import("mammoth/mammoth.browser");
      const result = await mammoth.extractRawText({ arrayBuffer: await file.arrayBuffer() });
      return result.value;
    }
    if (name.endsWith(".txt") || name.endsWith(".md") || file.type.startsWith("text/")) {
      return await file.text();
    }
  } catch (e) {
    if (e instanceof DocumentParseError) throw e;
    console.error("[extractTextFromFile]", e);
    throw new DocumentParseError("Unable to process this document. Please verify the file format.");
  }
  throw new DocumentParseError("Unsupported file type. Please upload a PDF, DOCX or TXT file.");
}
