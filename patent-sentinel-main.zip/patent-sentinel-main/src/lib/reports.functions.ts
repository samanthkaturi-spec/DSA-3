import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import type { Json } from "@/integrations/supabase/types";
import { LEGAL_DISCLAIMER } from "@/lib/analysis-stages";
import { loadAnalysisBundle, PipelineError } from "@/lib/analysis-pipeline.server";

export interface ReportContent {
  generated_at: string;
  executive_summary: string;
  scoring_mode: string;
  scoring_notice: string | null;
  scoring_formula: string | null;
  dataset_mode: string;
  target_patent: {
    id: string;
    patent_number: string;
    title: string;
    assignee: string | null;
    inventors: string[];
    filing_date: string | null;
    publication_date: string | null;
    priority_date: string | null;
    cpc_codes: string[];
    ipc_codes: string[];
    is_demo: boolean;
    abstract: string | null;
  };
  claims_analyzed: Array<{ id: string; claim_number: number; claim_type: string; claim_text: string }>;
  features: Array<{ id: string; claim_id: string; text: string; source: string }>;
  prior_art: Array<{
    rank: number;
    patent_id: string;
    patent_number: string;
    title: string;
    assignee: string | null;
    publication_date: string | null;
    priority_date: string | null;
    combined: number;
    semantic: number | null;
    keyword: number;
    classification: number;
    covered: number;
    partial: number;
    predates_target: boolean | null;
    citation_count: number;
    coverage: Record<string, string>;
    is_demo: boolean;
  }>;
  reference_set: Array<{ order: number; patent_number: string; title: string; reason: string; newly_covered: number }>;
  set_coverage_pct: number;
  citation_summary: { cited_by_target: number; citing_target: number; linked_candidates: number };
  timeline: Array<{ date: string; label: string; kind: string; predates: boolean | null }>;
  examiner_recommendation: Array<{
    rank: number;
    name: string;
    code: string;
    domain_match: number;
    expertise: number;
    workload: number;
    experience: number;
    overall: number;
  }>;
  threshold: number;
  limitations: string[];
  disclaimer: string;
}

export const generateReport = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ analysisId: z.string().uuid(), title: z.string().max(200).optional() }).parse(input))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    let b;
    try {
      b = await loadAnalysisBundle(supabase, userId, data.analysisId);
    } catch (e) {
      throw new Error(e instanceof PipelineError ? e.message : "Unable to retrieve analysis data. Please try again.");
    }
    if (b.analysis.status !== "completed") throw new Error("The analysis must complete before a report can be generated.");
    const s = (b.analysis.summary as Record<string, unknown>) ?? {};
    const threshold = Number(s["threshold"] ?? 0.5);
    const above = b.priorArt.filter((p) => Number(p.best_combined_score) >= threshold).length;
    const featureById = new Map(b.features.map((f) => [f.id, f]));

    const relevantDate = b.patent.priority_date ?? b.patent.filing_date ?? b.patent.publication_date ?? null;
    const timeline: ReportContent["timeline"] = [];
    if (b.patent.priority_date) timeline.push({ date: b.patent.priority_date, label: "Target priority date", kind: "target", predates: null });
    if (b.patent.filing_date) timeline.push({ date: b.patent.filing_date, label: "Target filing date", kind: "target", predates: null });
    if (b.patent.publication_date) timeline.push({ date: b.patent.publication_date, label: "Target publication date", kind: "target", predates: null });
    for (const p of b.priorArt) {
      const d = p.patent?.publication_date ?? p.patent?.filing_date ?? null;
      if (d) timeline.push({ date: d, label: `${p.patent?.patent_number} published`, kind: "prior_art", predates: relevantDate ? d < relevantDate : null });
    }
    timeline.sort((a, b2) => a.date.localeCompare(b2.date));

    const content: ReportContent = {
      generated_at: new Date().toISOString(),
      executive_summary:
        `Automated prior-art screening of ${b.patent.patent_number} (“${b.patent.title}”) analysed ${b.targetClaims.length} independent claim(s) decomposed into ${b.features.length} technical feature(s). ` +
        `${b.priorArt.length} potentially relevant reference(s) were ranked using ${b.analysis.scoring_mode === "semantic" ? "semantic + keyword + classification" : "keyword + classification"} similarity; ${above} exceed the ${Math.round(threshold * 100)}% similarity threshold. ` +
        `A greedy set-cover procedure selected ${b.references.length} reference(s) jointly covering ${Math.round(Number(s["set_coverage_pct"] ?? 0) * 100)}% of the extracted features. ` +
        `These indicators support further review and do not constitute a legal determination of validity or infringement.`,
      scoring_mode: b.analysis.scoring_mode ?? "keyword",
      scoring_notice: b.analysis.scoring_notice,
      scoring_formula: (s["scoring_formula"] as string) ?? null,
      dataset_mode: b.analysis.dataset_mode,
      target_patent: {
        id: b.patent.id,
        patent_number: b.patent.patent_number,
        title: b.patent.title,
        assignee: b.patent.assignee,
        inventors: b.patent.inventors,
        filing_date: b.patent.filing_date,
        publication_date: b.patent.publication_date,
        priority_date: b.patent.priority_date,
        cpc_codes: b.patent.cpc_codes,
        ipc_codes: b.patent.ipc_codes,
        is_demo: b.patent.is_demo,
        abstract: b.patent.abstract,
      },
      claims_analyzed: b.targetClaims.map((c) => ({ id: c.id, claim_number: c.claim_number, claim_type: c.claim_type, claim_text: c.claim_text })),
      features: b.features.map((f) => ({ id: f.id, claim_id: f.claim_id, text: f.feature_text, source: f.source })),
      prior_art: b.priorArt.map((p) => ({
        rank: p.rank,
        patent_id: p.patent_id,
        patent_number: p.patent?.patent_number ?? "?",
        title: p.patent?.title ?? "",
        assignee: p.patent?.assignee ?? null,
        publication_date: p.patent?.publication_date ?? null,
        priority_date: p.patent?.priority_date ?? null,
        combined: Number(p.best_combined_score),
        semantic: p.best_semantic_score === null ? null : Number(p.best_semantic_score),
        keyword: Number(p.best_keyword_score),
        classification: Number(p.best_classification_score),
        covered: p.covered_count,
        partial: p.partial_count,
        predates_target: p.predates_target,
        citation_count: p.citation_count,
        coverage: Object.fromEntries(
          Object.entries((p.coverage as Record<string, { status: string }>) ?? {}).map(([fid, v]) => [fid, v.status]),
        ),
        is_demo: p.patent?.is_demo ?? false,
      })),
      reference_set: b.references.map((r) => ({
        order: r.selection_order,
        patent_number: r.patent?.patent_number ?? "?",
        title: r.patent?.title ?? "",
        reason: r.reason ?? "",
        newly_covered: r.newly_covered_features.filter((id) => featureById.has(id)).length,
      })),
      set_coverage_pct: Number(s["set_coverage_pct"] ?? 0),
      citation_summary: {
        cited_by_target: b.targetCitations.cites.length,
        citing_target: b.targetCitations.citedBy.length,
        linked_candidates: b.priorArt.filter((p) => p.cited_by_target || p.cites_target).length,
      },
      timeline,
      examiner_recommendation: b.examinerRecommendations.map((r) => ({
        rank: r.rank,
        name: r.examiner?.name ?? "",
        code: r.examiner?.examiner_code ?? "",
        domain_match: Number(r.domain_match),
        expertise: Number(r.expertise_score),
        workload: Number(r.workload_score),
        experience: Number(r.experience_score),
        overall: Number(r.overall_score),
      })),
      threshold,
      limitations: [
        "Similarity scores are statistical indicators computed from claim text, keywords and classification codes; they are not legal conclusions.",
        "Claim-feature extraction and coverage matching are heuristic and may be edited by the user; automated matches require human verification.",
        "The corpus is limited to the selected dataset (demo or imported); external patent offices are not queried.",
        "Temporal relevance (dates) requires legal review; grace periods, priority chains and publication rules are not evaluated.",
        "The examiner recommendation is a prototype scoring illustration and does not assign any real examiner.",
        b.patent.is_demo ? "The target patent is part of the clearly fictional DEMO DATA set." : "",
      ].filter(Boolean),
      disclaimer: LEGAL_DISCLAIMER,
    };

    const title = data.title?.trim() || `Prior-Art Analysis Report – ${b.patent.patent_number}`;
    const { data: report, error } = await supabase
      .from("reports")
      .insert({ analysis_id: data.analysisId, user_id: userId, title, content: content as unknown as Json })
      .select("id")
      .single();
    if (error || !report) throw new Error("Unable to save the report. Please try again.");
    return { id: report.id };
  });

export const listReports = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("reports")
      .select("id, analysis_id, title, created_at, content")
      .order("created_at", { ascending: false })
      .limit(100);
    if (error) throw new Error("Unable to load reports.");
    return (data ?? []).map((r) => {
      const c = r.content as unknown as ReportContent;
      return {
        id: r.id,
        analysis_id: r.analysis_id,
        title: r.title,
        created_at: r.created_at,
        patent_number: c?.target_patent?.patent_number ?? "",
        references: c?.prior_art?.length ?? 0,
        scoring_mode: c?.scoring_mode ?? "",
        is_demo: c?.target_patent?.is_demo ?? false,
      };
    });
  });

export const getReport = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { data: row, error } = await context.supabase.from("reports").select("*").eq("id", data.id).maybeSingle();
    if (error) throw new Error("Unable to load the report.");
    if (!row) throw new Error("Report not found.");
    return { ...row, content: row.content as unknown as ReportContent };
  });

export const deleteReport = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase.from("reports").delete().eq("id", data.id);
    if (error) throw new Error("Unable to delete the report.");
    return { ok: true };
  });
