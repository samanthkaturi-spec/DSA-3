export type CoverageStatus = "covered" | "partial" | "none";

export interface CoverageResult {
  status: CoverageStatus;
  score: number; // fraction of feature keywords found in candidate text
  matched: string[];
  missing: string[];
}

export const COVERED_THRESHOLD = 0.7;
export const PARTIAL_THRESHOLD = 0.35;

/** Compare feature keywords against the (stemmed) token set of a candidate document. */
export function featureCoverage(featureKeywords: string[], candidateTokens: Set<string>): CoverageResult {
  const kws = [...new Set(featureKeywords)];
  if (kws.length === 0) return { status: "none", score: 0, matched: [], missing: [] };
  const matched = kws.filter((k) => candidateTokens.has(k));
  const missing = kws.filter((k) => !candidateTokens.has(k));
  const score = matched.length / kws.length;
  const status: CoverageStatus = score >= COVERED_THRESHOLD ? "covered" : score >= PARTIAL_THRESHOLD ? "partial" : "none";
  return { status, score, matched, missing };
}
