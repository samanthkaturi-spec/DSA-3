import { tokenize } from "./text";

export interface ExtractedFeature {
  text: string;
  keywords: string[];
}

const LEADING_RE = /^(?:and|or|further|comprising|including|having|wherein|whereby|the|a|an|at least one|one or more|said)\s+/i;
const TRAILING_RE = /[\s,;:.]+$|\s+(?:and|or)$/i;

function clean(segment: string): string {
  let s = segment.replace(/\s+/g, " ").trim();
  for (let i = 0; i < 4; i++) s = s.replace(LEADING_RE, "").replace(TRAILING_RE, "").trim();
  return s;
}

/**
 * Break an independent claim into technical features (claim elements).
 * Heuristic: strip the preamble, then split the body on semicolons,
 * enumerated elements and "wherein" clauses.
 */
export function extractFeatures(claimText: string): ExtractedFeature[] {
  const text = claimText.replace(/\s+/g, " ").trim();
  const transitional = /\b(?:comprising|comprises|including|includes|consisting of|consisting essentially of|characterized by|having)\s*:?\s*/i;
  const m = transitional.exec(text);
  const preamble = m ? text.slice(0, m.index).trim() : "";
  let body = m ? text.slice(m.index + m[0].length) : text;

  // Separate trailing "wherein" clauses as their own features
  body = body.replace(/\b(?:wherein|whereby|such that)\b/gi, ";$&");

  let segments = body.split(/;|\band\s+(?=(?:a|an|the|at least one|one or more)\s)/i);
  if (segments.length <= 1) {
    segments = body.split(/,\s*(?=(?:a|an|the|at least one|one or more)\s)|\band\s+(?=(?:a|an)\s)/i);
  }
  if (segments.length <= 1) {
    segments = body.split(/,\s*|\band\b/i);
  }

  const features: ExtractedFeature[] = [];
  const seen = new Set<string>();
  const push = (s: string) => {
    const c = clean(s);
    if (c.length < 4) return;
    const keywords = tokenize(c);
    if (keywords.length === 0) return;
    const key = keywords.slice().sort().join("|");
    if (seen.has(key)) return;
    seen.add(key);
    features.push({ text: c.length > 220 ? c.slice(0, 217) + "…" : c, keywords: [...new Set(keywords)] });
  };

  if (preamble && preamble.split(" ").length >= 3) push(preamble);
  segments.forEach(push);

  if (features.length === 0) push(text);
  return features.slice(0, 20);
}
