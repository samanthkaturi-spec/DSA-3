// Text normalisation, tokenisation, TF-IDF and cosine similarity.
// Pure functions – safe to run on both server and client.

export const STOPWORDS = new Set<string>(
  `a an the and or of to in on for with by at from as is are was were be been being this that these those it its into
   than then there their they them which who whom whose what when where why how each any all some such no nor not only
   own same so too very can will just should now said one two first second third least more most further via within
   without wherein whereby thereof therein hereby said comprising comprises comprise including includes include having
   has have configured adapted least about above below between over under also may claim claims according method system
   device apparatus plurality least one respective step steps means`.split(/\s+/).filter(Boolean),
);

export function normalizeText(text: string): string {
  return text
    .toLowerCase()
    .replace(/[\u2018\u2019\u201c\u201d]/g, "'")
    .replace(/[^a-z0-9\s-]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

/** Light-weight suffix stemmer (Porter-lite). Good enough for claim vocabulary. */
export function stem(word: string): string {
  let w = word;
  if (w.length <= 3) return w;
  const rules: Array<[RegExp, string]> = [
    [/ies$/, "y"],
    [/sses$/, "ss"],
    [/([^s])s$/, "$1"],
    [/ization$/, "ize"],
    [/ational$/, "ate"],
    [/tional$/, "tion"],
    [/ingly$/, ""],
    [/edly$/, ""],
    [/ing$/, ""],
    [/ed$/, ""],
    [/ly$/, ""],
    [/ment$/, ""],
    [/ness$/, ""],
    [/ers?$/, ""],
  ];
  for (const [re, rep] of rules) {
    if (re.test(w)) {
      const next = w.replace(re, rep);
      if (next.length >= 3) {
        w = next;
        break;
      }
    }
  }
  if (/[^aeiou]e$/.test(w) && w.length > 4) w = w.slice(0, -1);
  return w;
}

export function tokenize(text: string, opts: { stem?: boolean } = { stem: true }): string[] {
  const norm = normalizeText(text);
  const out: string[] = [];
  for (const raw of norm.split(" ")) {
    const t = raw.replace(/^-+|-+$/g, "");
    if (!t || t.length < 3 || STOPWORDS.has(t) || /^\d+$/.test(t)) continue;
    out.push(opts.stem === false ? t : stem(t));
  }
  return out;
}

export function termFrequency(tokens: string[]): Map<string, number> {
  const tf = new Map<string, number>();
  for (const t of tokens) tf.set(t, (tf.get(t) ?? 0) + 1);
  return tf;
}

export class TfIdf {
  private idf = new Map<string, number>();
  readonly docCount: number;

  constructor(documents: string[][]) {
    this.docCount = documents.length;
    const df = new Map<string, number>();
    for (const doc of documents) {
      for (const t of new Set(doc)) df.set(t, (df.get(t) ?? 0) + 1);
    }
    for (const [t, n] of df) {
      this.idf.set(t, Math.log((1 + this.docCount) / (1 + n)) + 1);
    }
  }

  vector(tokens: string[]): Map<string, number> {
    const tf = termFrequency(tokens);
    const vec = new Map<string, number>();
    const len = tokens.length || 1;
    for (const [t, n] of tf) {
      const idf = this.idf.get(t) ?? Math.log((1 + this.docCount) / 1) + 1;
      vec.set(t, (n / len) * idf);
    }
    return vec;
  }

  weight(term: string): number {
    return this.idf.get(term) ?? 1;
  }
}

export function cosineSparse(a: Map<string, number>, b: Map<string, number>): number {
  let dot = 0;
  let na = 0;
  let nb = 0;
  for (const [t, va] of a) {
    na += va * va;
    const vb = b.get(t);
    if (vb !== undefined) dot += va * vb;
  }
  for (const vb of b.values()) nb += vb * vb;
  if (na === 0 || nb === 0) return 0;
  return dot / (Math.sqrt(na) * Math.sqrt(nb));
}

export function cosineDense(a: number[], b: number[]): number {
  const n = Math.min(a.length, b.length);
  let dot = 0;
  let na = 0;
  let nb = 0;
  for (let i = 0; i < n; i++) {
    dot += a[i]! * b[i]!;
    na += a[i]! * a[i]!;
    nb += b[i]! * b[i]!;
  }
  if (na === 0 || nb === 0) return 0;
  return dot / (Math.sqrt(na) * Math.sqrt(nb));
}

/** Shared terms between two sparse vectors, sorted by combined weight. */
export function sharedTerms(a: Map<string, number>, b: Map<string, number>, limit = 12): string[] {
  const shared: Array<[string, number]> = [];
  for (const [t, va] of a) {
    const vb = b.get(t);
    if (vb !== undefined) shared.push([t, va + vb]);
  }
  return shared
    .sort((x, y) => y[1] - x[1])
    .slice(0, limit)
    .map(([t]) => t);
}

/** Top keywords for a text using TF within the text weighted by token length. */
export function extractKeywords(text: string, limit = 12): string[] {
  const tokens = tokenize(text, { stem: false });
  const tf = termFrequency(tokens);
  return [...tf.entries()]
    .sort((a, b) => b[1] * Math.min(b[0].length, 10) - a[1] * Math.min(a[0].length, 10))
    .slice(0, limit)
    .map(([t]) => t);
}

export function clamp01(x: number): number {
  return Math.max(0, Math.min(1, x));
}
