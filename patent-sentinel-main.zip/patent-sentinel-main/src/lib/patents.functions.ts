import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { extractDocument, splitClaims, type ExtractedClaim } from "@/lib/nlp/claims";
import type { SupabaseClient } from "@supabase/supabase-js";
import type { Database } from "@/integrations/supabase/types";

type DB = SupabaseClient<Database>;

const SearchInput = z.object({
  q: z.string().max(300).default(""),
  field: z.enum(["all", "patent_number", "title", "abstract", "claims", "inventor", "assignee", "cpc", "ipc"]).default("all"),
  dataset: z.literal("all").default("all"),
  cpc: z.string().max(30).optional(),
  ipc: z.string().max(30).optional(),
  assignee: z.string().max(120).optional(),
  pubFrom: z.string().optional(),
  pubTo: z.string().optional(),
  filingFrom: z.string().optional(),
  filingTo: z.string().optional(),
  limit: z.number().int().min(1).max(200).default(60),
});
export type SearchInput = z.infer<typeof SearchInput>;

const nul = (s?: string) => (s && s.trim() ? s.trim() : null);

export const searchPatents = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => SearchInput.parse(input))
  .handler(async ({ data, context }) => {
    const args: Record<string, string | number> = { q: data.q.trim(), field: data.field, dataset: data.dataset, lim: data.limit };
    const opt: Array<[string, string | undefined]> = [
      ["cpc_filter", data.cpc], ["ipc_filter", data.ipc], ["assignee_filter", data.assignee],
      ["pub_from", data.pubFrom], ["pub_to", data.pubTo], ["filing_from", data.filingFrom], ["filing_to", data.filingTo],
    ];
    for (const [k, v] of opt) { const n = nul(v); if (n) args[k] = n; }
    const { data: rows, error } = await context.supabase.rpc("search_patents", args);
    if (error) {
      console.error("[searchPatents]", error);
      throw new Error("Unable to retrieve patent data. Please try again.");
    }
    return rows ?? [];
  });

export const listPatents = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({}).parse(input ?? {}))
  .handler(async ({ data, context }) => {
    void data;
    const { data: rows, error } = await context.supabase
      .from("patents")
      .select("id, patent_number, title, assignee, publication_date, cpc_codes")
      .order("patent_number")
      .limit(500);
    if (error) throw new Error("Unable to retrieve patent data. Please try again.");
    return rows ?? [];
  });

export const getPatent = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ id: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { data: patentRow, error } = await supabase.from("patents").select("*").eq("id", data.id).maybeSingle();
    if (error) throw new Error("Unable to retrieve patent data. Please try again.");
    if (!patentRow) throw new Error("Patent not found in the available corpus.");
    const { search_vector: _sv, ...patent } = patentRow;
    void _sv;
    const [claimsRes, citesRes, citedByRes, shortRes, analysesRes] = await Promise.all([
      supabase
        .from("patent_claims")
        .select("id, claim_number, claim_type, claim_text, is_independent, depends_on, embedding_model")
        .eq("patent_id", data.id)
        .order("claim_number"),
      supabase.from("patent_citations").select("id, cited_patent_id, citation_type").eq("citing_patent_id", data.id),
      supabase.from("patent_citations").select("id, citing_patent_id, citation_type").eq("cited_patent_id", data.id),
      supabase.from("prior_art_shortlist").select("id").eq("user_id", userId).eq("patent_id", data.id).maybeSingle(),
      supabase
        .from("analyses")
        .select("id, status, created_at, summary")
        .eq("patent_id", data.id)
        .order("created_at", { ascending: false })
        .limit(5),
    ]);
    const relatedIds = [
      ...(citesRes.data ?? []).map((c) => c.cited_patent_id),
      ...(citedByRes.data ?? []).map((c) => c.citing_patent_id),
    ];
    const related = relatedIds.length
      ? (
          await supabase
            .from("patents")
            .select("id, patent_number, title, assignee, publication_date")
            .in("id", relatedIds)
        ).data ?? []
      : [];
    const byId = new Map(related.map((r) => [r.id, r]));
    return {
      patent,
      claims: claimsRes.data ?? [],
      cites: (citesRes.data ?? []).map((c) => ({ ...c, patent: byId.get(c.cited_patent_id) ?? null })),
      citedBy: (citedByRes.data ?? []).map((c) => ({ ...c, patent: byId.get(c.citing_patent_id) ?? null })),
      shortlisted: Boolean(shortRes.data),
      analyses: analysesRes.data ?? [],
    };
  });

export const findPatentByNumber = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ patentNumber: z.string().min(1).max(60) }).parse(input))
  .handler(async ({ data, context }) => {
    const num = data.patentNumber.trim();
    const { data: rows, error } = await context.supabase
      .from("patents")
      .select("id, patent_number, title")
      .ilike("patent_number", `%${num.replace(/[%_]/g, "")}%`)
      .limit(5);
    if (error) throw new Error("Unable to retrieve patent data. Please try again.");
    if (!rows || rows.length === 0) throw new Error("Patent not found in the available corpus.");
    const exact = rows.find((r) => r.patent_number.toLowerCase() === num.toLowerCase());
    return exact ?? rows[0]!;
  });

// ---------- Create from uploaded / pasted text ----------

const CreateFromTextInput = z.object({
  text: z.string().min(40, "The document text is too short to analyze.").max(400_000),
  source: z.enum(["upload", "manual"]),
  fileName: z.string().max(200).optional(),
  storagePath: z.string().max(400).optional(),
  patentNumber: z.string().max(60).optional(),
  title: z.string().max(300).optional(),
});

async function insertPatentWithClaims(
  supabase: DB,
  userId: string,
  patent: {
    patent_number: string;
    title: string;
    abstract: string | null;
    description: string | null;
    inventors: string[];
    assignee: string | null;
    filing_date: string | null;
    publication_date: string | null;
    priority_date: string | null;
    cpc_codes: string[];
    ipc_codes: string[];
    source: string;
  },
  claims: ExtractedClaim[],
) {
  const { data: inserted, error } = await supabase
    .from("patents")
    .insert({ ...patent, claims: null, owner_id: userId, is_demo: false })
    .select("id")
    .single();
  if (error || !inserted) {
    console.error("[insertPatent]", error);
    throw new Error("Unable to store the patent. Please try again.");
  }
  if (claims.length) {
    const { error: cErr } = await supabase.from("patent_claims").insert(
      claims.map((c) => ({
        patent_id: inserted.id,
        claim_number: c.claim_number,
        claim_type: c.claim_type,
        claim_text: c.claim_text,
        is_independent: c.is_independent,
        depends_on: c.depends_on,
        owner_id: userId,
        is_demo: false,
      })),
    );
    if (cErr) {
      console.error("[insertClaims]", cErr);
      throw new Error("Unable to store the extracted claims. Please try again.");
    }
    const claimsText = claims.map((c) => `${c.claim_number}. ${c.claim_text}`).join("\n");
    await supabase.from("patents").update({ claims: claimsText }).eq("id", inserted.id);
  }
  return inserted.id as string;
}

export const createPatentFromText = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => CreateFromTextInput.parse(input))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const doc = extractDocument(data.text);
    if (doc.claims.length === 0) {
      throw new Error(
        "Unable to process this document. No numbered claims (e.g. \"1. A system comprising …\") could be identified. Please verify the file format or paste the claims section.",
      );
    }
    let patentNumber = (data.patentNumber?.trim() || doc.patentNumber || "").trim();
    if (!patentNumber) patentNumber = `UPL-${Date.now().toString(36).toUpperCase()}`;
    const { data: dup } = await supabase
      .from("patents")
      .select("id")
      .eq("owner_id", userId)
      .eq("patent_number", patentNumber)
      .maybeSingle();
    if (dup) patentNumber = `${patentNumber}-${Date.now().toString(36).slice(-4).toUpperCase()}`;

    const id = await insertPatentWithClaims(
      supabase,
      userId,
      {
        patent_number: patentNumber,
        title: (data.title?.trim() || doc.title || data.fileName || "Untitled uploaded patent").slice(0, 300),
        abstract: doc.abstract,
        description: doc.description ?? (data.storagePath ? `Source file: ${data.storagePath}` : null),
        inventors: [],
        assignee: null,
        filing_date: null,
        publication_date: null,
        priority_date: null,
        cpc_codes: [],
        ipc_codes: [],
        source: data.source,
      },
      doc.claims,
    );
    return {
      id,
      patentNumber,
      title: doc.title,
      claimCount: doc.claims.length,
      independentCount: doc.claims.filter((c) => c.is_independent).length,
      abstractFound: Boolean(doc.abstract),
    };
  });

export const updatePatentMeta = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({
        id: z.string().uuid(),
        title: z.string().min(1).max(300).optional(),
        assignee: z.string().max(200).nullable().optional(),
        inventors: z.array(z.string().max(120)).max(30).optional(),
        cpc_codes: z.array(z.string().max(20)).max(40).optional(),
        ipc_codes: z.array(z.string().max(20)).max(40).optional(),
        filing_date: z.string().nullable().optional(),
        publication_date: z.string().nullable().optional(),
        priority_date: z.string().nullable().optional(),
        abstract: z.string().max(5000).nullable().optional(),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    const { id, ...rest } = data;
    const patch = Object.fromEntries(Object.entries(rest).filter(([, v]) => v !== undefined)) as Database["public"]["Tables"]["patents"]["Update"];
    const { error } = await context.supabase.from("patents").update(patch).eq("id", id).eq("owner_id", context.userId);
    if (error) throw new Error("Unable to update the patent record. Only imported/uploaded patents can be edited.");
    return { ok: true };
  });

// ---------- Import (CSV / JSON) ----------

const dateStr = z
  .string()
  .trim()
  .regex(/^\d{4}-\d{2}-\d{2}$/, "must be YYYY-MM-DD")
  .refine((s) => !Number.isNaN(Date.parse(s)), "is not a valid date");

const ImportRow = z.object({
  patent_number: z.string().trim().min(3, "is required").max(60),
  title: z.string().trim().min(3, "is required").max(300),
  abstract: z.string().trim().max(5000).optional().default(""),
  claims: z.string().trim().min(10, "must contain at least one claim").max(200_000),
  inventors: z.string().trim().max(2000).optional().default(""),
  assignee: z.string().trim().max(200).optional().default(""),
  filing_date: z.union([dateStr, z.literal("")]).optional().default(""),
  publication_date: z.union([dateStr, z.literal("")]).optional().default(""),
  priority_date: z.union([dateStr, z.literal("")]).optional().default(""),
  cpc_codes: z.string().trim().max(1000).optional().default(""),
  ipc_codes: z.string().trim().max(1000).optional().default(""),
  description: z.string().trim().max(50_000).optional().default(""),
});

const splitList = (s: string) =>
  s
    .split(/[;|,]/)
    .map((x) => x.trim())
    .filter(Boolean);

export const importPatents = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({
        files: z.array(z.object({ fileName: z.string().max(200), rows: z.array(z.record(z.unknown())).max(2000) })).min(1).max(10),
      })
      .parse(input),
  )
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const errors: Array<{ file_name: string; row: number; patent_number: string; message: string }> = [];
    const valid: Array<{ fileName: string; row: number; parsed: z.infer<typeof ImportRow>; claims: ExtractedClaim[] }> = [];
    const fileRows = new Map<string, number>();
    const seenNumbers = new Set<string>();
    let duplicates = 0;

    const { data: existing } = await supabase.from("patents").select("patent_number").eq("owner_id", userId);
    const existingNumbers = new Set((existing ?? []).map((p) => p.patent_number.toLowerCase()));

    let totalRows = 0;
    for (const file of data.files) {
      totalRows += file.rows.length;
      fileRows.set(file.fileName, file.rows.length);
      file.rows.forEach((raw, i) => {
      const rowNo = i + 1;
      // normalise keys & stringify values
      const obj: Record<string, string> = {};
      for (const [k, v] of Object.entries(raw)) {
        if (v == null) continue;
        obj[k.trim().toLowerCase()] = Array.isArray(v) ? v.join("; ") : String(v);
      }
      const parsed = ImportRow.safeParse(obj);
      if (!parsed.success) {
        const issue = parsed.error.issues[0];
        errors.push({
          file_name: file.fileName,
          row: rowNo,
          patent_number: obj["patent_number"] ?? "",
          message: `${issue?.path.join(".") || "row"} ${issue?.message ?? "is invalid"}`,
        });
        return;
      }
      const num = parsed.data.patent_number.toLowerCase();
      if (seenNumbers.has(num) || existingNumbers.has(num)) {
        duplicates++;
        errors.push({ file_name: file.fileName, row: rowNo, patent_number: parsed.data.patent_number, message: "duplicate patent_number (skipped)" });
        return;
      }
      const claims = splitClaims(parsed.data.claims);
      if (claims.length === 0) {
        errors.push({ file_name: file.fileName, row: rowNo, patent_number: parsed.data.patent_number, message: "claims could not be parsed into numbered claims" });
        return;
      }
      seenNumbers.add(num);
      valid.push({ fileName: file.fileName, row: rowNo, parsed: parsed.data, claims });
    });
    }

    let imported = 0;
    for (const v of valid) {
      try {
        const p = v.parsed;
        await insertPatentWithClaims(
          supabase,
          userId,
          {
            patent_number: p.patent_number,
            title: p.title,
            abstract: p.abstract || null,
            description: p.description || null,
            inventors: splitList(p.inventors),
            assignee: p.assignee || null,
            filing_date: p.filing_date || null,
            publication_date: p.publication_date || null,
            priority_date: p.priority_date || null,
            cpc_codes: splitList(p.cpc_codes),
            ipc_codes: splitList(p.ipc_codes),
            source: "imported",
          },
          v.claims,
        );
        imported++;
      } catch (e) {
        errors.push({ file_name: v.fileName, row: v.row, patent_number: v.parsed.patent_number, message: e instanceof Error ? e.message : "insert failed" });
      }
    }

    const stats = {
      total_rows: totalRows,
      valid_rows: valid.length,
      invalid_rows: totalRows - valid.length - duplicates,
      duplicate_rows: duplicates,
      imported_rows: imported,
    };
    for (const file of data.files) {
      const fileErrors = errors.filter((e) => e.file_name === file.fileName);
      const fileValid = valid.filter((v) => v.fileName === file.fileName).length;
      const fileDuplicates = fileErrors.filter((e) => e.message.startsWith("duplicate patent_number")).length;
      const fileImported = Math.max(0, fileValid - fileErrors.filter((e) => e.message !== "duplicate patent_number (skipped)").length);
      const fileTotal = fileRows.get(file.fileName) ?? file.rows.length;
      await supabase.from("import_jobs").insert({
        user_id: userId,
        file_name: file.fileName,
        total_rows: fileTotal,
        valid_rows: fileValid,
        invalid_rows: fileTotal - fileValid - fileDuplicates,
        duplicate_rows: fileDuplicates,
        imported_rows: fileImported,
        errors: fileErrors,
      });
    }
    return {
      ...stats,
      errors,
      files: data.files.map((f) => ({
        file_name: f.fileName,
        total_rows: fileRows.get(f.fileName) ?? f.rows.length,
        valid_rows: valid.filter((v) => v.fileName === f.fileName).length,
        duplicate_rows: errors.filter((e) => e.file_name === f.fileName && e.message.startsWith("duplicate patent_number")).length,
        errors: errors.filter((e) => e.file_name === f.fileName).length,
      })),
    };
  });

export const listImportJobs = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("import_jobs")
      .select("*")
      .order("created_at", { ascending: false })
      .limit(20);
    if (error) throw new Error("Unable to load import history.");
    return data ?? [];
  });

// ---------- Prior-art shortlist ----------

export const toggleShortlist = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) => z.object({ patentId: z.string().uuid() }).parse(input))
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { data: existing } = await supabase
      .from("prior_art_shortlist")
      .select("id")
      .eq("user_id", userId)
      .eq("patent_id", data.patentId)
      .maybeSingle();
    if (existing) {
      await supabase.from("prior_art_shortlist").delete().eq("id", existing.id);
      return { shortlisted: false };
    }
    const { error } = await supabase.from("prior_art_shortlist").insert({ user_id: userId, patent_id: data.patentId });
    if (error) throw new Error("Unable to update your prior-art shortlist.");
    return { shortlisted: true };
  });

export const listShortlist = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase } = context;
    const { data: rows, error } = await supabase
      .from("prior_art_shortlist")
      .select("id, patent_id, note, created_at")
      .order("created_at", { ascending: false });
    if (error) throw new Error("Unable to load your prior-art shortlist.");
    const ids = (rows ?? []).map((r) => r.patent_id);
    const patents = ids.length
      ? (
          await supabase
            .from("patents")
            .select("id, patent_number, title, assignee, publication_date, cpc_codes")
            .in("id", ids)
        ).data ?? []
      : [];
    const byId = new Map(patents.map((p) => [p.id, p]));
    return (rows ?? []).map((r) => ({ ...r, patent: byId.get(r.patent_id) ?? null }));
  });
