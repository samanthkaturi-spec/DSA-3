import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { subclassOf, sectionOf, CPC_SECTIONS } from "@/lib/nlp/classification";

export const getDashboardData = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase } = context;
    const [statsRes, analysesRes, priorArtRes, patentsRes, citesRes] = await Promise.all([
      supabase.rpc("dashboard_stats"),
      supabase
        .from("analyses")
        .select("id, patent_id, status, created_at, summary, scoring_mode")
        .order("created_at", { ascending: false })
        .limit(200),
      supabase.from("prior_art_results").select("best_combined_score").limit(2000),
      supabase.from("patents").select("id, cpc_codes, publication_date").limit(1000),
      supabase.from("patent_citations").select("citing_patent_id").limit(5000),
    ]);
    if (statsRes.error) throw new Error("Unable to retrieve patent data. Please try again.");
    const stats = (statsRes.data ?? {}) as Record<string, number>;
    const analyses = analysesRes.data ?? [];

    // activity by month (last 6 months)
    const months: { month: string; analyses: number }[] = [];
    const now = new Date();
    for (let i = 5; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      months.push({ month: d.toLocaleString("en", { month: "short" }), analyses: 0 });
    }
    for (const a of analyses) {
      const d = new Date(a.created_at);
      const diff = (now.getFullYear() - d.getFullYear()) * 12 + now.getMonth() - d.getMonth();
      if (diff >= 0 && diff <= 5) months[5 - diff]!.analyses++;
    }

    // similarity distribution
    const buckets = ["0-20%", "20-40%", "40-60%", "60-80%", "80-100%"].map((range) => ({ range, count: 0 }));
    for (const r of priorArtRes.data ?? []) {
      const s = Number(r.best_combined_score);
      buckets[Math.min(4, Math.floor(s * 5))]!.count++;
    }

    // classification distribution by subclass (top 8) and section
    const sub = new Map<string, number>();
    const sec = new Map<string, number>();
    for (const p of patentsRes.data ?? []) {
      const seen = new Set<string>();
      for (const c of p.cpc_codes ?? []) {
        const s = subclassOf(c);
        if (!seen.has(s)) (seen.add(s), sub.set(s, (sub.get(s) ?? 0) + 1));
        sec.set(sectionOf(c), (sec.get(sectionOf(c)) ?? 0) + 1);
      }
    }
    const classification = [...sub.entries()].sort((a, b) => b[1] - a[1]).slice(0, 8).map(([code, count]) => ({ code, count }));
    const sections = [...sec.entries()].map(([code, count]) => ({ code, label: CPC_SECTIONS[code] ?? code, count }));

    // citation activity by citing patent publication year
    const pubYear = new Map((patentsRes.data ?? []).map((p) => [p.id, p.publication_date ? p.publication_date.slice(0, 4) : null]));
    const years = new Map<string, number>();
    for (const c of citesRes.data ?? []) {
      const y = pubYear.get(c.citing_patent_id);
      if (y) years.set(y, (years.get(y) ?? 0) + 1);
    }
    const citationActivity = [...years.entries()].sort().map(([year, citations]) => ({ year, citations }));

    const recentIds = analyses.slice(0, 8).map((a) => a.patent_id);
    const patents = recentIds.length
      ? (await supabase.from("patents").select("id, patent_number, title").in("id", recentIds)).data ?? []
      : [];
    const byId = new Map(patents.map((p) => [p.id, p]));

    return {
      stats: {
        total_patents: Number(stats["total_patents"] ?? 0),
        total_claims: Number(stats["total_claims"] ?? 0),
        total_analyses: Number(stats["total_analyses"] ?? 0),
        references_found: Number(stats["references_found"] ?? 0),
        avg_similarity: Number(stats["avg_similarity"] ?? 0),
        citation_count: Number(stats["citation_count"] ?? 0),
      },
      activity: months,
      distribution: buckets,
      classification,
      sections,
      citationActivity,
      recent: analyses.slice(0, 8).map((a) => ({ ...a, patent: byId.get(a.patent_id) ?? null })),
    };
  });
