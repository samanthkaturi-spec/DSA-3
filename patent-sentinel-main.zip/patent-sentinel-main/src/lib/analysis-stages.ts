// Client-safe list of pipeline stages executed by the server, in order.
export const SERVER_STAGES = [
  { key: "extracting_claims", label: "Extracting claims" },
  { key: "extracting_features", label: "Extracting claim features" },
  { key: "generating_representations", label: "Generating representations" },
  { key: "searching_corpus", label: "Searching patent corpus" },
  { key: "calculating_similarity", label: "Calculating similarity" },
  { key: "analyzing_citations", label: "Analyzing citations" },
  { key: "calculating_coverage", label: "Calculating claim coverage" },
  { key: "generating_results", label: "Generating results" },
] as const;

export type ServerStage = (typeof SERVER_STAGES)[number]["key"];

export const STAGE_PROGRESS: Record<ServerStage, number> = {
  extracting_claims: 12,
  extracting_features: 25,
  generating_representations: 38,
  searching_corpus: 50,
  calculating_similarity: 64,
  analyzing_citations: 74,
  calculating_coverage: 88,
  generating_results: 100,
};

export const LEGAL_DISCLAIMER =
  "This platform is intended for research and decision-support purposes only. It does not provide legal advice or determine patent validity. Automated similarity, coverage and temporal indicators require review by a qualified patent professional.";
