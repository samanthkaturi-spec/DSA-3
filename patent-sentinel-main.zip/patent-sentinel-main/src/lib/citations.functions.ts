import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { computeGraphMetrics } from "@/lib/algorithms/graph";

export const getCitationGraph = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: unknown) =>
    z
      .object({
        focusPatentId: z.string().uuid().optional(),
        hops: z.number().int().min(1).max(4).default(2),
      })
      .parse(input ?? {}),
  )
  .handler(async ({ data, context }) => {
    const { supabase } = context;
    let pq = supabase
      .from("patents")
      .select("id, patent_number, title, assignee, publication_date, priority_date, filing_date, cpc_codes, ipc_codes")
      .limit(600);
    const { data: patents, error } = await pq;
    if (error) throw new Error("Unable to retrieve patent data. Please try again.");
    const ids = new Set((patents ?? []).map((p) => p.id));
    const { data: cites, error: cErr } = await supabase
      .from("patent_citations")
      .select("id, citing_patent_id, cited_patent_id, citation_type")
      .limit(5000);
    if (cErr) throw new Error("Unable to retrieve citation data. Please try again.");
    let edges = (cites ?? []).filter((c) => ids.has(c.citing_patent_id) && ids.has(c.cited_patent_id));

    let nodes = patents ?? [];
    if (data.focusPatentId && ids.has(data.focusPatentId)) {
      const adj = new Map<string, Set<string>>();
      for (const e of edges) {
        (adj.get(e.citing_patent_id) ?? adj.set(e.citing_patent_id, new Set()).get(e.citing_patent_id)!).add(e.cited_patent_id);
        (adj.get(e.cited_patent_id) ?? adj.set(e.cited_patent_id, new Set()).get(e.cited_patent_id)!).add(e.citing_patent_id);
      }
      const keep = new Set<string>([data.focusPatentId]);
      let frontier = [data.focusPatentId];
      for (let h = 0; h < data.hops; h++) {
        const next: string[] = [];
        for (const id of frontier) for (const n of adj.get(id) ?? []) if (!keep.has(n)) (keep.add(n), next.push(n));
        frontier = next;
      }
      nodes = nodes.filter((n) => keep.has(n.id));
      edges = edges.filter((e) => keep.has(e.citing_patent_id) && keep.has(e.cited_patent_id));
    }

    const metrics = computeGraphMetrics(
      nodes.map((n) => n.id),
      edges.map((e) => ({ source: e.citing_patent_id, target: e.cited_patent_id })),
    );
    return {
      nodes: nodes.map((n) => ({ ...n, ...metrics.get(n.id)! })),
      edges: edges.map((e) => ({ id: e.id, source: e.citing_patent_id, target: e.cited_patent_id, type: e.citation_type })),
      focusPatentId: data.focusPatentId ?? null,
    };
  });

export type CitationGraph = Awaited<ReturnType<typeof getCitationGraph>>;
