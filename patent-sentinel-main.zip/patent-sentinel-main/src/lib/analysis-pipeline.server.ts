// Server-only implementation of the prior-art analysis pipeline.
import type { SupabaseClient } from "@supabase/supabase-js";
import type { Database, Json } from "@/integrations/supabase/types";
import { TfIdf, cosineDense, cosineSparse, sharedTerms, tokenize, clamp01 } from "@/lib/nlp/text";
import { splitClaims } from "@/lib/nlp/claims";
import { extractFeatures } from "@/lib/nlp/features";
import { classificationSimilarity, subclassOf, classOf } from "@/lib/nlp/classification";
import { featureCoverage, type CoverageStatus } from "@/lib/nlp/coverage";
import { greedySetCover, type SetCoverCandidate } from "@/lib/algorithms/setCover";
import { embedTexts, EmbeddingUnavailableError, parseVectorLiteral, toVectorLiteral } from "@/lib/embeddings.server";
import { STAGE_PROGRESS, type ServerStage } from "@/lib/analysis-stages";
import { DEFAULT_SETTINGS, type UserSettings } from "@/lib/settings.functions";

type DB = SupabaseClient<Database>;
type Analysis = Database["public"]["Tables"]["analyses"]["Row"];
type Claim = Database["public"]["Tables"]["patent_claims"]["Row"];

export class PipelineError extends Error {}

function settingsOf(analysis: Analysis): UserSettings {
  const snap = (analysis.settings_snapshot ?? {}) as Partial<UserSettings>;
  return { ...DEFAULT_SETTINGS, ...snap };
}

async function loadAnalysis(db: DB, id: string): Promise<Analysis> {
  const { data, error } = await db.from("analyses").select("*").eq("id", id).maybeSingle();
  if (error) throw new PipelineError("Unable to retrieve analysis data. Please try again.");
  if (!data) throw new PipelineError("Analysis not found.");
  return data;
}

async function setStage(db: DB, id: string, stage: ServerStage, patch: Partial<Analysis> = {}) {
  await db
    .from("analyses")
    .update({ stage, progress: STAGE_PROGRESS[stage], status: "running", ...patch })
    .eq("id", id);
}

async function mergeSummary(db: DB, analysis: Analysis, extra: Record<string, unknown>) {
  const summary = { ...((analysis.summary as Record<string, unknown>) ?? {}), ...extra };
  await db.from("analyses").update({ summary: summary as Json }).eq("id", analysis.id);
  analysis.summary = summary as Json;
  return summary;
}

async function targetClaims(db: DB, analysisId: string): Promise<Claim[]> {
  const { data: links } = await db.from("analysis_claims").select("claim_id").eq("analysis_id", analysisId);
  const ids = (links ?? []).map((l) => l.claim_id);
  if (!ids.length) return [];
  const { data } = await db.from("patent_claims").select("*").in("id", ids).order("claim_number");
  return data ?? [];
}

async function inChunks<T>(ids: string[], size: number, fn: (chunk: string[]) => Promise<T[]>): Promise<T[]> {
  const out: T[] = [];
  for (let i = 0; i < ids.length; i += size) out.push(...(await fn(ids.slice(i, i + size))));
  return out;
}

// ---------------------------------------------------------------------------
// Stage runner
// ---------------------------------------------------------------------------
export async function runStage(db: DB, userId: string, analysisId: string, stage: ServerStage) {
  const analysis = await loadAnalysis(db, analysisId);
  if (analysis.user_id !== userId) throw new PipelineError("Analysis not found.");
  try {
    let info: Json = {};
    switch (stage) {
      case "extracting_claims":
        info = (await stageExtractClaims(db, analysis)) as unknown as Json;
        break;
      case "extracting_features":
        info = (await stageExtractFeatures(db, analysis, userId)) as unknown as Json;
        break;
      case "generating_representations":
        info = (await stageRepresentations(db, analysis)) as unknown as Json;
        break;
      case "searching_corpus":
        info = (await stageSearchCorpus(db, analysis)) as unknown as Json;
        break;
      case "calculating_similarity":
        info = (await stageSimilarity(db, analysis, userId)) as unknown as Json;
        break;
      case "analyzing_citations":
        info = (await stageCitations(db, analysis)) as unknown as Json;
        break;
      case "calculating_coverage":
        info = (await stageCoverage(db, analysis, userId)) as unknown as Json;
        break;
      case "generating_results":
        info = (await stageResults(db, analysis, userId)) as unknown as Json;
        break;
    }
    await setStage(db, analysisId, stage, stage === "generating_results" ? { status: "completed", completed_at: new Date().toISOString() } : {});
    return { stage, progress: STAGE_PROGRESS[stage], info };
  } catch (e) {
    const message = e instanceof PipelineError ? e.message : "The analysis step could not be completed. Please try again.";
    if (!(e instanceof PipelineError)) console.error(`[pipeline:${stage}]`, e);
    await db.from("analyses").update({ status: "failed", error_message: message }).eq("id", analysisId);
    throw new PipelineError(message);
  }
}

// ---------------------------------------------------------------------------
// 1. Claims
// ---------------------------------------------------------------------------
async function stageExtractClaims(db: DB, analysis: Analysis) {
  const { data: patent } = await db.from("patents").select("*").eq("id", analysis.patent_id).maybeSingle();
  if (!patent) throw new PipelineError("Patent not found in the available corpus.");
  let { data: claims } = await db.from("patent_claims").select("*").eq("patent_id", patent.id).order("claim_number");
  if ((!claims || claims.length === 0) && patent.claims) {
    const parsed = splitClaims(patent.claims);
    if (parsed.length) {
      await db.from("patent_claims").insert(
        parsed.map((c) => ({
          patent_id: patent.id,
          claim_number: c.claim_number,
          claim_text: c.claim_text,
          claim_type: c.claim_type,
          is_independent: c.is_independent,
          depends_on: c.depends_on,
          owner_id: patent.owner_id,
          is_demo: patent.is_demo,
        })),
      );
      claims = (await db.from("patent_claims").select("*").eq("patent_id", patent.id).order("claim_number")).data;
    }
  }
  if (!claims || claims.length === 0) throw new PipelineError("No claims could be extracted for this patent.");
  const independent = claims.filter((c) => c.is_independent);
  const targets = independent.length ? independent : claims;
  await db.from("analysis_claims").delete().eq("analysis_id", analysis.id);
  await db.from("analysis_claims").insert(targets.map((c) => ({ analysis_id: analysis.id, claim_id: c.id, user_id: analysis.user_id })));
  await mergeSummary(db, analysis, {
    claim_count: claims.length,
    independent_count: independent.length,
    dependent_count: claims.length - independent.length,
    target_claim_count: targets.length,
  });
  return { claims: claims.length, targets: targets.length };
}

// ---------------------------------------------------------------------------
// 2. Features
// ---------------------------------------------------------------------------
async function stageExtractFeatures(db: DB, analysis: Analysis, userId: string) {
  const targets = await targetClaims(db, analysis.id);
  if (!targets.length) throw new PipelineError("No target claims were selected for this analysis.");
  await db.from("claim_features").delete().eq("analysis_id", analysis.id).eq("source", "auto");
  const rows: Database["public"]["Tables"]["claim_features"]["Insert"][] = [];
  for (const claim of targets) {
    extractFeatures(claim.claim_text).forEach((f, i) =>
      rows.push({
        analysis_id: analysis.id,
        claim_id: claim.id,
        feature_order: i,
        feature_text: f.text,
        keywords: f.keywords,
        source: "auto",
        user_id: userId,
      }),
    );
  }
  if (rows.length) {
    const { error } = await db.from("claim_features").insert(rows);
    if (error) throw new PipelineError("Unable to store extracted claim features.");
  }
  await mergeSummary(db, analysis, { feature_count: rows.length });
  return { features: rows.length };
}

// ---------------------------------------------------------------------------
// 3. Representations (keywords always; embeddings when available)
// ---------------------------------------------------------------------------
async function stageRepresentations(db: DB, analysis: Analysis) {
  const settings = settingsOf(analysis);
  const targets = await targetClaims(db, analysis.id);
  const cfg = {
    provider: settings.embedding_provider,
    model: settings.embedding_model,
    customBaseUrl: settings.custom_embedding_base_url,
    customModel: settings.custom_embedding_model,
  } as const;
  const modelTag = cfg.provider === "custom" ? `custom:${cfg.customModel || cfg.model}` : cfg.model;

  if (cfg.provider === "none" || settings.search_mode === "keyword") {
    await db.from("analyses").update({
      scoring_mode: "keyword",
      scoring_notice: cfg.provider === "none"
        ? "Semantic embeddings are disabled in Settings. Keyword-based analysis is being used."
        : "Search mode is set to keyword-only in Settings. Keyword-based analysis is being used.",
    }).eq("id", analysis.id);
    return { mode: "keyword", embedded: 0 };
  }

  try {
    let embedded = 0;
    // targets
    const needTargets = targets.filter((t) => !t.embedding || t.embedding_model !== modelTag);
    if (needTargets.length) {
      const vecs = await embedTexts(needTargets.map((t) => t.claim_text), cfg);
      await Promise.all(
        needTargets.map((t, i) =>
          db.from("patent_claims").update({ embedding: toVectorLiteral(vecs[i]!) as unknown as string, embedding_model: modelTag }).eq("id", t.id),
        ),
      );
      embedded += needTargets.length;
    }
    // corpus (cap per run to bound cost)
    let q = db
      .from("patent_claims")
      .select("id, claim_text")
      .neq("patent_id", analysis.patent_id)
      .or(`embedding.is.null,embedding_model.neq.${modelTag}`)
      .limit(200);
    const { data: corpus } = await q;
    if (corpus && corpus.length) {
      const vecs = await embedTexts(corpus.map((c) => c.claim_text), cfg);
      for (let i = 0; i < corpus.length; i += 25) {
        await Promise.all(
          corpus.slice(i, i + 25).map((c, j) =>
            db.from("patent_claims").update({ embedding: toVectorLiteral(vecs[i + j]!) as unknown as string, embedding_model: modelTag }).eq("id", c.id),
          ),
        );
      }
      embedded += corpus.length;
    }
    await db.from("analyses").update({ scoring_mode: "semantic", scoring_notice: null }).eq("id", analysis.id);
    await mergeSummary(db, analysis, { embedding_model: modelTag, embedded_this_run: embedded });
    return { mode: "semantic", embedded };
  } catch (e) {
    const detail = e instanceof EmbeddingUnavailableError ? e.message : "Embedding service error.";
    console.error("[representations]", e);
    await db.from("analyses").update({
      scoring_mode: "keyword",
      scoring_notice: `Semantic search is currently unavailable (${detail}) Keyword-based analysis is being used.`,
    }).eq("id", analysis.id);
    return { mode: "keyword", embedded: 0, fallbackReason: detail };
  }
}

// ---------------------------------------------------------------------------
// 4. Corpus search – candidate retrieval
// ---------------------------------------------------------------------------
async function stageSearchCorpus(db: DB, analysis: Analysis) {
  const targets = await targetClaims(db, analysis.id);
  const { scoring_mode } = (await loadAnalysis(db, analysis.id));
  let countQ = db.from("patent_claims").select("id", { count: "exact", head: true }).neq("patent_id", analysis.patent_id);
  const { count } = await countQ;
  const corpusSize = count ?? 0;
  if (corpusSize === 0) throw new PipelineError("No other patents are available to compare against. Import additional patents first.");

  const candidateIds = new Set<string>();
  let method = "exhaustive";
  if (corpusSize <= 600) {
    let q = db.from("patent_claims").select("id").neq("patent_id", analysis.patent_id).limit(600);
    ((await q).data ?? []).forEach((r) => candidateIds.add(r.id));
  } else {
    method = scoring_mode === "semantic" ? "fulltext+vector" : "fulltext";
    for (const t of targets) {
      const kws = [...new Set(tokenize(t.claim_text, { stem: false }))].slice(0, 15);
      if (kws.length) {
        let q = db
          .from("patent_claims")
          .select("id")
          .neq("patent_id", analysis.patent_id)
          .textSearch("search_vector", kws.join(" | "))
          .limit(150);
        ((await q).data ?? []).forEach((r) => candidateIds.add(r.id));
      }
      if (scoring_mode === "semantic" && t.embedding) {
        const { data: matches } = await db.rpc("match_claims", {
          query_embedding: t.embedding as unknown as string,
          match_count: 100,
          exclude_patent: analysis.patent_id,
          dataset: "all",
        });
        (matches ?? []).forEach((m) => candidateIds.add(m.claim_id));
      }
    }
  }
  if (candidateIds.size === 0) throw new PipelineError("No sufficiently similar references were identified in the corpus.");
  await mergeSummary(db, analysis, {
    corpus_size: corpusSize,
    candidate_claim_ids: [...candidateIds],
    candidate_count: candidateIds.size,
    retrieval_method: method,
  });
  return { corpusSize, candidates: candidateIds.size, method };
}

// ---------------------------------------------------------------------------
// 5. Similarity scoring
// ---------------------------------------------------------------------------
async function stageSimilarity(db: DB, analysis: Analysis, userId: string) {
  const fresh = await loadAnalysis(db, analysis.id);
  const settings = settingsOf(fresh);
  const summary = (fresh.summary as Record<string, unknown>) ?? {};
  const candidateIds = (summary["candidate_claim_ids"] as string[] | undefined) ?? [];
  if (!candidateIds.length) throw new PipelineError("Candidate retrieval must run before similarity scoring.");
  const semantic = fresh.scoring_mode === "semantic";

  const targets = await targetClaims(db, analysis.id);
  const candidates = await inChunks(candidateIds, 200, async (chunk) =>
    (await db.from("patent_claims").select("id, patent_id, claim_text").in("id", chunk)).data ?? [],
  );
  const patentIds = [...new Set([...candidates.map((c) => c.patent_id), analysis.patent_id])];
  const patents = await inChunks(patentIds, 200, async (chunk) =>
    (await db.from("patents").select("id, cpc_codes, ipc_codes").in("id", chunk)).data ?? [],
  );
  const patentById = new Map(patents.map((p) => [p.id, p]));
  const target = patentById.get(analysis.patent_id);
  const targetCodes = [...(target?.cpc_codes ?? []), ...(target?.ipc_codes ?? [])];

  // TF-IDF over the whole working corpus
  const candTokens = candidates.map((c) => tokenize(c.claim_text));
  const targetTokens = targets.map((t) => tokenize(t.claim_text));
  const tfidf = new TfIdf([...candTokens, ...targetTokens]);
  const candVecs = candTokens.map((t) => tfidf.vector(t));

  // classification per patent (cached)
  const classCache = new Map<string, number>();
  const classScore = (pid: string) => {
    let v = classCache.get(pid);
    if (v === undefined) {
      const p = patentById.get(pid);
      v = classificationSimilarity(targetCodes, [...(p?.cpc_codes ?? []), ...(p?.ipc_codes ?? [])]);
      classCache.set(pid, v);
    }
    return v;
  };

  // semantic via pgvector when available
  const semanticMaps = new Map<string, Map<string, number>>();
  let semanticCoverage = 0;
  if (semantic) {
    for (const t of targets) {
      if (!t.embedding) continue;
      const { data: matches, error } = await db.rpc("match_claims", {
        query_embedding: t.embedding as unknown as string,
        match_count: Math.min(candidateIds.length + 50, 2000),
        exclude_patent: analysis.patent_id,
        dataset: "all",
      });
      if (error) console.error("[match_claims]", error);
      const m = new Map<string, number>();
      (matches ?? []).forEach((r) => m.set(r.claim_id, clamp01(r.similarity)));
      semanticMaps.set(t.id, m);
      semanticCoverage += m.size;
    }
  }

  const wS = settings.semantic_weight, wK = settings.keyword_weight, wC = settings.classification_weight;
  const fK = settings.fallback_keyword_weight, fC = settings.fallback_classification_weight;
  const normFull = wS + wK + wC || 1;
  const normFallback = fK + fC || 1;
  const keepPerTarget = Math.max(settings.max_results * 3, 30);

  const rows: Database["public"]["Tables"]["similarity_results"]["Insert"][] = [];
  targets.forEach((t, ti) => {
    const tv = tfidf.vector(targetTokens[ti]!);
    const semMap = semanticMaps.get(t.id);
    const scored = candidates.map((c, ci) => {
      const keyword = clamp01(cosineSparse(tv, candVecs[ci]!));
      const cls = classScore(c.patent_id);
      const sem = semMap ? (semMap.get(c.id) ?? null) : null;
      // use fallback formula when no semantic value exists for this pair
      const combined = sem !== null
        ? (wS * sem + wK * keyword + wC * cls) / normFull
        : (fK * keyword + fC * cls) / normFallback;
      return { c, keyword, cls, sem, combined, terms: sharedTerms(tv, candVecs[ci]!, 10) };
    });
    scored
      .sort((a, b) => b.combined - a.combined)
      .slice(0, keepPerTarget)
      .filter((s) => s.combined > 0.02)
      .forEach((s) =>
        rows.push({
          analysis_id: analysis.id,
          target_claim_id: t.id,
          candidate_claim_id: s.c.id,
          candidate_patent_id: s.c.patent_id,
          semantic_score: s.sem,
          keyword_score: Number(s.keyword.toFixed(4)),
          classification_score: Number(s.cls.toFixed(4)),
          combined_score: Number(s.combined.toFixed(4)),
          matched_terms: s.terms,
          user_id: userId,
        }),
      );
  });

  await db.from("similarity_results").delete().eq("analysis_id", analysis.id);
  if (rows.length) {
    for (let i = 0; i < rows.length; i += 300) {
      const { error } = await db.from("similarity_results").insert(rows.slice(i, i + 300));
      if (error) throw new PipelineError("Unable to store similarity results.");
    }
  }
  const semanticPairs = rows.filter((r) => r.semantic_score !== null).length;
  await mergeSummary(db, analysis, {
    similarity_pairs: rows.length,
    semantic_pairs: semanticPairs,
    scoring_formula: semantic
      ? `combined = ${wS}×semantic + ${wK}×keyword + ${wC}×classification`
      : `combined = ${fK}×keyword + ${fC}×classification`,
    candidate_claim_ids: undefined,
  });
  return { pairs: rows.length, semanticPairs, semanticCoverage };
}

// ---------------------------------------------------------------------------
// 6. Citations
// ---------------------------------------------------------------------------
async function stageCitations(db: DB, analysis: Analysis) {
  const [{ data: cites }, { data: citedBy }, { data: sims }] = await Promise.all([
    db.from("patent_citations").select("cited_patent_id").eq("citing_patent_id", analysis.patent_id),
    db.from("patent_citations").select("citing_patent_id").eq("cited_patent_id", analysis.patent_id),
    db.from("similarity_results").select("candidate_patent_id").eq("analysis_id", analysis.id),
  ]);
  const candidatePatents = new Set((sims ?? []).map((s) => s.candidate_patent_id));
  const citedIds = new Set((cites ?? []).map((c) => c.cited_patent_id));
  const citingIds = new Set((citedBy ?? []).map((c) => c.citing_patent_id));
  const linked = [...candidatePatents].filter((id) => citedIds.has(id) || citingIds.has(id));
  const summary = await mergeSummary(db, analysis, {
    citations: {
      cited_by_target: citedIds.size,
      citing_target: citingIds.size,
      candidates_linked: linked,
      candidate_patents: candidatePatents.size,
    },
  });
  return summary["citations"] as Record<string, unknown>;
}

// ---------------------------------------------------------------------------
// 7. Coverage + Greedy Set Cover (also used for re-computation after feature edits)
// ---------------------------------------------------------------------------
export async function stageCoverage(db: DB, analysis: Analysis, userId: string) {
  const fresh = await loadAnalysis(db, analysis.id);
  const settings = settingsOf(fresh);
  const [{ data: features }, { data: sims }, { data: target }] = await Promise.all([
    db.from("claim_features").select("id, feature_text, keywords, claim_id, feature_order").eq("analysis_id", analysis.id).order("feature_order"),
    db.from("similarity_results").select("candidate_patent_id, combined_score, semantic_score, keyword_score, classification_score").eq("analysis_id", analysis.id),
    db.from("patents").select("priority_date, filing_date, publication_date").eq("id", analysis.patent_id).maybeSingle(),
  ]);
  if (!sims || sims.length === 0) throw new PipelineError("No sufficiently similar references were identified.");

  // aggregate to patent level
  const agg = new Map<string, { best: number; sum: number; n: number; sem: number | null; kw: number; cls: number }>();
  for (const s of sims) {
    const a = agg.get(s.candidate_patent_id) ?? { best: 0, sum: 0, n: 0, sem: null, kw: 0, cls: 0 };
    const combined = Number(s.combined_score);
    a.best = Math.max(a.best, combined);
    a.sum += combined;
    a.n++;
    if (s.semantic_score !== null) a.sem = Math.max(a.sem ?? 0, Number(s.semantic_score));
    a.kw = Math.max(a.kw, Number(s.keyword_score));
    a.cls = Math.max(a.cls, Number(s.classification_score));
    agg.set(s.candidate_patent_id, a);
  }
  const ranked = [...agg.entries()].sort((a, b) => b[1].best - a[1].best).slice(0, settings.max_results);
  const patentIds = ranked.map(([id]) => id);
  const [{ data: claimRows }, { data: patentRows }] = await Promise.all([
    db.from("patent_claims").select("patent_id, claim_text").in("patent_id", patentIds),
    db.from("patents").select("id, priority_date, filing_date, publication_date").in("id", patentIds),
  ]);
  const textByPatent = new Map<string, Set<string>>();
  for (const c of claimRows ?? []) {
    const set = textByPatent.get(c.patent_id) ?? new Set<string>();
    tokenize(c.claim_text).forEach((t) => set.add(t));
    textByPatent.set(c.patent_id, set);
  }
  const patentById = new Map((patentRows ?? []).map((p) => [p.id, p]));
  const relevantDate = target?.priority_date ?? target?.filing_date ?? target?.publication_date ?? null;

  const priorArtRows: Database["public"]["Tables"]["prior_art_results"]["Insert"][] = [];
  const setCoverCandidates: SetCoverCandidate[] = [];
  ranked.forEach(([pid, a], i) => {
    const tokens = textByPatent.get(pid) ?? new Set<string>();
    const coverage: Record<string, { status: CoverageStatus; score: number; matched: string[]; missing: string[] }> = {};
    const covers = new Set<string>();
    const partial = new Set<string>();
    for (const f of features ?? []) {
      const r = featureCoverage(f.keywords, tokens);
      coverage[f.id] = { status: r.status, score: Number(r.score.toFixed(3)), matched: r.matched, missing: r.missing };
      if (r.status === "covered") covers.add(f.id);
      else if (r.status === "partial") partial.add(f.id);
    }
    const p = patentById.get(pid);
    const candDate = p?.publication_date ?? p?.filing_date ?? p?.priority_date ?? null;
    priorArtRows.push({
      analysis_id: analysis.id,
      patent_id: pid,
      rank: i + 1,
      best_combined_score: Number(a.best.toFixed(4)),
      avg_combined_score: Number((a.sum / a.n).toFixed(4)),
      best_semantic_score: a.sem,
      best_keyword_score: Number(a.kw.toFixed(4)),
      best_classification_score: Number(a.cls.toFixed(4)),
      coverage: coverage as unknown as Json,
      covered_count: covers.size,
      partial_count: partial.size,
      predates_target: relevantDate && candDate ? candDate < relevantDate : null,
      user_id: userId,
    });
    setCoverCandidates.push({ id: pid, covers, partial, weight: a.best });
  });

  await db.from("prior_art_results").delete().eq("analysis_id", analysis.id);
  if (priorArtRows.length) {
    const { error } = await db.from("prior_art_results").insert(priorArtRows);
    if (error) throw new PipelineError("Unable to store prior-art results.");
  }

  const universe = (features ?? []).map((f) => f.id);
  const cover = greedySetCover(universe, setCoverCandidates);
  await db.from("analysis_references").delete().eq("analysis_id", analysis.id);
  if (cover.selected.length) {
    await db.from("analysis_references").insert(
      cover.selected.map((s) => ({
        analysis_id: analysis.id,
        patent_id: s.id,
        selection_order: s.order,
        newly_covered_features: s.newlyCovered,
        reason: s.reason,
        user_id: userId,
      })),
    );
  }
  await mergeSummary(db, fresh, {
    feature_count: universe.length,
    references_found: priorArtRows.length,
    set_size: cover.selected.length,
    set_coverage_pct: Number(cover.coveragePct.toFixed(4)),
    uncovered_features: cover.uncoveredFeatures,
    relevant_date: relevantDate,
    predating_references: priorArtRows.filter((r) => r.predates_target).length,
  });
  return { references: priorArtRows.length, setSize: cover.selected.length, coverage: cover.coveragePct };
}

// ---------------------------------------------------------------------------
// 8. Results: examiner recommendation + summary
// ---------------------------------------------------------------------------
async function stageResults(db: DB, analysis: Analysis, userId: string) {
  const fresh = await loadAnalysis(db, analysis.id);
  const settings = settingsOf(fresh);
  const [{ data: patent }, { data: examiners }, { data: priorArt }] = await Promise.all([
    db.from("patents").select("cpc_codes, ipc_codes").eq("id", analysis.patent_id).maybeSingle(),
    db.from("examiners").select("*"),
    db.from("prior_art_results").select("best_combined_score").eq("analysis_id", analysis.id),
  ]);
  const codes = [...(patent?.cpc_codes ?? []), ...(patent?.ipc_codes ?? [])];
  const subclasses = [...new Set(codes.map(subclassOf))];
  const classes = [...new Set(codes.map(classOf))];

  const recs = (examiners ?? []).map((ex) => {
    const exp = [...ex.cpc_expertise, ...ex.ipc_expertise].map((c) => c.toUpperCase());
    const expSub = new Set(exp.map((c) => c.slice(0, 4)));
    const expCls = new Set(exp.map((c) => c.slice(0, 3)));
    const domain = subclasses.length ? subclasses.filter((s) => expSub.has(s)).length / subclasses.length : 0;
    const expertise = classes.length
      ? classes.reduce((acc, c) => acc + (expCls.has(c) ? 1 : [...expCls].some((e) => e[0] === c[0]) ? 0.3 : 0), 0) / classes.length
      : 0;
    const workload = clamp01(1 - ex.current_workload / Math.max(ex.max_workload, 1));
    const experience = clamp01(ex.experience_years / 15);
    const overall = 0.35 * domain + 0.3 * expertise + 0.25 * workload + 0.1 * experience;
    return { ex, domain, expertise, workload, experience, overall };
  });
  recs.sort((a, b) => b.overall - a.overall);
  await db.from("examiner_recommendations").delete().eq("analysis_id", analysis.id);
  if (recs.length) {
    await db.from("examiner_recommendations").insert(
      recs.slice(0, 5).map((r, i) => ({
        analysis_id: analysis.id,
        examiner_id: r.ex.id,
        domain_match: Number(r.domain.toFixed(4)),
        expertise_score: Number(r.expertise.toFixed(4)),
        workload_score: Number(r.workload.toFixed(4)),
        experience_score: Number(r.experience.toFixed(4)),
        overall_score: Number(r.overall.toFixed(4)),
        rank: i + 1,
        user_id: userId,
      })),
    );
  }
  const scores = (priorArt ?? []).map((p) => Number(p.best_combined_score));
  const top = scores.length ? Math.max(...scores) : 0;
  const avg = scores.length ? scores.reduce((a, b) => a + b, 0) / scores.length : 0;
  await mergeSummary(db, fresh, {
    top_similarity: Number(top.toFixed(4)),
    avg_similarity: Number(avg.toFixed(4)),
    above_threshold: scores.filter((s) => s >= settings.similarity_threshold).length,
    threshold: settings.similarity_threshold,
    examiner_recommendations: Math.min(recs.length, 5),
  });
  return { top, avg, examiners: recs.length };
}

// ---------------------------------------------------------------------------
// Full bundle loader used by the analysis pages and report generator
// ---------------------------------------------------------------------------
export async function loadAnalysisBundle(db: DB, userId: string, analysisId: string) {
  const analysis = await loadAnalysis(db, analysisId);
  if (analysis.user_id !== userId) throw new PipelineError("Analysis not found.");
  const [{ data: patent }, targets, { data: features }, { data: priorArt }, { data: sims }, { data: refs }, { data: recs }] =
    await Promise.all([
      db.from("patents").select("*").eq("id", analysis.patent_id).maybeSingle(),
      targetClaims(db, analysisId),
      db.from("claim_features").select("*").eq("analysis_id", analysisId).order("feature_order"),
      db.from("prior_art_results").select("*").eq("analysis_id", analysisId).order("rank"),
      db.from("similarity_results").select("*").eq("analysis_id", analysisId).order("combined_score", { ascending: false }),
      db.from("analysis_references").select("*").eq("analysis_id", analysisId).order("selection_order"),
      db.from("examiner_recommendations").select("*").eq("analysis_id", analysisId).order("rank"),
    ]);
  if (!patent) throw new PipelineError("Patent not found in the available corpus.");

  const patentIds = [...new Set([...(priorArt ?? []).map((p) => p.patent_id), ...(sims ?? []).map((s) => s.candidate_patent_id)])];
  const claimIds = [...new Set((sims ?? []).map((s) => s.candidate_claim_id))];
  const examinerIds = (recs ?? []).map((r) => r.examiner_id);
  const [patents, claims, { data: examiners }, citationCounts, { data: targetCites }, { data: targetCitedBy }] = await Promise.all([
    inChunks(patentIds, 200, async (chunk) =>
      (await db.from("patents").select("id, patent_number, title, assignee, publication_date, filing_date, priority_date, cpc_codes, ipc_codes, abstract, inventors").in("id", chunk)).data ?? [],
    ),
    inChunks(claimIds, 200, async (chunk) =>
      (await db.from("patent_claims").select("id, patent_id, claim_number, claim_text, is_independent, claim_type").in("id", chunk)).data ?? [],
    ),
    examinerIds.length ? db.from("examiners").select("*").in("id", examinerIds) : Promise.resolve({ data: [] as Database["public"]["Tables"]["examiners"]["Row"][] }),
    inChunks(patentIds, 200, async (chunk) =>
      (await db.from("patent_citations").select("cited_patent_id").in("cited_patent_id", chunk)).data ?? [],
    ),
    db.from("patent_citations").select("cited_patent_id, citation_type").eq("citing_patent_id", analysis.patent_id),
    db.from("patent_citations").select("citing_patent_id, citation_type").eq("cited_patent_id", analysis.patent_id),
  ]);
  const citedCount = new Map<string, number>();
  for (const c of citationCounts) citedCount.set(c.cited_patent_id, (citedCount.get(c.cited_patent_id) ?? 0) + 1);
  const patentById = new Map(patents.map((p) => [p.id, p]));
  const claimById = new Map(claims.map((c) => [c.id, c]));
  const examinerById = new Map((examiners ?? []).map((e) => [e.id, e]));

  const { search_vector: _sv, ...patentDto } = patent;
  void _sv;
  return {
    analysis,
    patent: patentDto,
    targetClaims: targets.map(({ embedding: _e, search_vector: _s, ...t }) => (void _e, void _s, t)),
    features: features ?? [],
    priorArt: (priorArt ?? []).map((p) => ({
      ...p,
      patent: patentById.get(p.patent_id) ?? null,
      citation_count: citedCount.get(p.patent_id) ?? 0,
      cited_by_target: (targetCites ?? []).some((c) => c.cited_patent_id === p.patent_id),
      cites_target: (targetCitedBy ?? []).some((c) => c.citing_patent_id === p.patent_id),
    })),
    similarity: (sims ?? []).map((s) => ({
      ...s,
      candidate_claim: claimById.get(s.candidate_claim_id) ?? null,
      candidate_patent: patentById.get(s.candidate_patent_id) ?? null,
    })),
    references: (refs ?? []).map((r) => ({ ...r, patent: patentById.get(r.patent_id) ?? null })),
    examinerRecommendations: (recs ?? []).map((r) => ({ ...r, examiner: examinerById.get(r.examiner_id) ?? null })),
    targetCitations: { cites: targetCites ?? [], citedBy: targetCitedBy ?? [] },
  };
}

export type AnalysisBundle = Awaited<ReturnType<typeof loadAnalysisBundle>>;

// ---------------------------------------------------------------------------
// Claim comparison (computed on demand)
// ---------------------------------------------------------------------------
export async function compareClaims(db: DB, userId: string, analysisId: string, targetClaimId: string, candidateClaimId: string) {
  const analysis = await loadAnalysis(db, analysisId);
  if (analysis.user_id !== userId) throw new PipelineError("Analysis not found.");
  const [{ data: target }, { data: candidate }, { data: features }, { data: sim }] = await Promise.all([
    db.from("patent_claims").select("id, patent_id, claim_number, claim_text").eq("id", targetClaimId).maybeSingle(),
    db.from("patent_claims").select("id, patent_id, claim_number, claim_text").eq("id", candidateClaimId).maybeSingle(),
    db.from("claim_features").select("id, feature_text, keywords, feature_order, source").eq("analysis_id", analysisId).eq("claim_id", targetClaimId).order("feature_order"),
    db
      .from("similarity_results")
      .select("semantic_score, keyword_score, classification_score, combined_score, matched_terms")
      .eq("analysis_id", analysisId)
      .eq("target_claim_id", targetClaimId)
      .eq("candidate_claim_id", candidateClaimId)
      .maybeSingle(),
  ]);
  if (!target || !candidate) throw new PipelineError("Claim not found.");
  const tTok = tokenize(target.claim_text);
  const cTok = tokenize(candidate.claim_text);
  const tfidf = new TfIdf([tTok, cTok]);
  const tv = tfidf.vector(tTok);
  const cv = tfidf.vector(cTok);
  const tSet = new Set(tTok);
  const cSet = new Set(cTok);
  const matching = [...tSet].filter((t) => cSet.has(t));
  const onlyTarget = [...tSet].filter((t) => !cSet.has(t));
  const onlyCandidate = [...cSet].filter((t) => !tSet.has(t));
  const bigrams = (tok: string[]) => new Set(tok.slice(1).map((t, i) => `${tok[i]} ${t}`));
  const tb = bigrams(tTok);
  const similarPhrases = [...bigrams(cTok)].filter((b) => tb.has(b)).slice(0, 15);
  const featureRows = (features ?? []).map((f) => {
    const r = featureCoverage(f.keywords, cSet);
    return { ...f, ...r };
  });
  const keyword = clamp01(cosineSparse(tv, cv));
  const covered = featureRows.filter((f) => f.status === "covered").length;
  const partial = featureRows.filter((f) => f.status === "partial").length;
  const confidence = clamp01(0.5 * keyword + 0.5 * (featureRows.length ? (covered + 0.5 * partial) / featureRows.length : 0));
  return {
    target,
    candidate,
    matchingConcepts: matching,
    similarPhrases,
    targetOnlyConcepts: onlyTarget.slice(0, 30),
    candidateOnlyConcepts: onlyCandidate.slice(0, 30),
    features: featureRows,
    scores: sim ? { ...sim, semantic_score: sim.semantic_score === null ? null : Number(sim.semantic_score) } : null,
    keywordSimilarity: keyword,
    confidence,
    confidenceLabel: confidence >= 0.7 ? "high" : confidence >= 0.4 ? "medium" : "low",
  };
}

// dense cosine exported for potential re-use by server routes
export { cosineDense, parseVectorLiteral };
