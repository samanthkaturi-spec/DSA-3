import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { ArrowLeft, Download, Printer } from "lucide-react";
import { getReport } from "@/lib/reports.functions";
import { getAnalysis } from "@/lib/analysis.functions";
import { ReportView } from "@/components/analysis/ReportView";
import { LoadingState, ErrorState, errorMessage } from "@/components/common";
import { Button } from "@/components/ui/button";
import { downloadCsv, downloadText } from "@/lib/csv";

export const Route = createFileRoute("/_authenticated/reports/$id")({
  head: () => ({
    meta: [
      { title: "Report – Patent Prior-Art Analytics Engine" },
      { name: "description", content: "Printable prior-art analysis report with similarity scores, feature matrix, reference set, timeline and disclaimer." },
      { property: "og:title", content: "Prior-art analysis report" },
      { property: "og:description", content: "Printable analysis report." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: ReportPage,
});

function ReportPage() {
  const { id } = Route.useParams();
  const getFn = useServerFn(getReport);
  const analysisFn = useServerFn(getAnalysis);
  const q = useQuery({ queryKey: ["report", id], queryFn: () => getFn({ data: { id } }) });

  async function exportCsv() {
    if (!q.data) return;
    const b = await analysisFn({ data: { id: q.data.analysis_id } });
    const targetById = new Map(b.targetClaims.map((t) => [t.id, t.claim_number]));
    downloadCsv(`similarity-${q.data.content.target_patent.patent_number}.csv`, b.similarity.map((s) => ({
      target_claim: targetById.get(s.target_claim_id) ?? "",
      candidate_patent: s.candidate_patent?.patent_number ?? "",
      candidate_claim: s.candidate_claim?.claim_number ?? "",
      semantic_score: s.semantic_score ?? "",
      keyword_score: s.keyword_score,
      classification_score: s.classification_score,
      combined_score: s.combined_score,
      matched_terms: s.matched_terms.join(" "),
    })));
  }

  if (q.isLoading) return <LoadingState label="Loading report…" />;
  if (q.isError || !q.data) return <ErrorState message={errorMessage(q.error, "Unable to load the report.")} onRetry={() => q.refetch()} />;

  return (
    <div>
      <div className="no-print mb-4 flex flex-wrap items-center justify-between gap-2">
        <Button asChild variant="ghost" size="sm"><Link to="/reports"><ArrowLeft className="h-4 w-4" /> All reports</Link></Button>
        <div className="flex flex-wrap gap-2">
          <Button variant="outline" size="sm" onClick={exportCsv}><Download className="h-4 w-4" /> Similarity CSV</Button>
          <Button variant="outline" size="sm" onClick={() => downloadText(`report-${q.data!.content.target_patent.patent_number}.json`, JSON.stringify(q.data!.content, null, 2), "application/json")}><Download className="h-4 w-4" /> JSON</Button>
          <Button size="sm" onClick={() => window.print()}><Printer className="h-4 w-4" /> Print / Save as PDF</Button>
        </div>
      </div>
      <ReportView title={q.data.title} content={q.data.content} createdAt={q.data.created_at} />
    </div>
  );
}
