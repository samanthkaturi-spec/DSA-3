import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { z } from "zod";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { getCitationGraph } from "@/lib/citations.functions";
import { listPatents } from "@/lib/patents.functions";
import { CitationGraphView } from "@/components/analysis/CitationGraphView";
import { PageHeader, LoadingState, ErrorState, StatCard, errorMessage, EmptyState } from "@/components/common";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

const searchSchema = z.object({ patent: z.string().uuid().optional() });

export const Route = createFileRoute("/_authenticated/citations")({
  validateSearch: (s) => searchSchema.parse(s),
  head: () => ({
    meta: [
      { title: "Citation Network – Patent Prior-Art Analytics Engine" },
      { name: "description", content: "Interactive patent citation graph with in-degree, out-degree, degree centrality and PageRank." },
      { property: "og:title", content: "Citation Network" },
      { property: "og:description", content: "Interactive citation graph with centrality metrics." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: CitationsPage,
});

function CitationsPage() {
  const search = Route.useSearch();
  const dataset = "all" as const;
  const [focus, setFocus] = useState<string | null>(search.patent ?? null);
  const [hops, setHops] = useState(2);
  const graphFn = useServerFn(getCitationGraph);
  const listFn = useServerFn(listPatents);
  const patents = useQuery({ queryKey: ["patents", dataset], queryFn: () => listFn({ data: { dataset } }) });
  const graph = useQuery({
    queryKey: ["citations", dataset, focus, hops],
    queryFn: () => graphFn({ data: { ...(focus ? { focusPatentId: focus, hops } : {}) } }),
  });

  const top = graph.data ? [...graph.data.nodes].sort((a, b) => b.pagerank - a.pagerank).slice(0, 3) : [];

  return (
    <div>
      <PageHeader eyebrow="Graph" title="Citation Network" description="Nodes are patents, edges are citations (citing → cited). Node size reflects citation count and PageRank." />
      <div className="mb-4 flex flex-wrap items-center gap-2">
        <Select value={focus ?? "all"} onValueChange={(v) => setFocus(v === "all" ? null : v)}>
          <SelectTrigger className="w-full sm:w-96" aria-label="Focus patent"><SelectValue placeholder="Whole network" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Whole network</SelectItem>
            {(patents.data ?? []).map((p) => <SelectItem key={p.id} value={p.id}><span className="font-mono text-xs">{p.patent_number}</span> · {p.title.slice(0, 50)}</SelectItem>)}
          </SelectContent>
        </Select>
        {focus && (
          <Select value={String(hops)} onValueChange={(v) => setHops(Number(v))}>
            <SelectTrigger className="w-32" aria-label="Hops"><SelectValue /></SelectTrigger>
            <SelectContent>{[1, 2, 3].map((h) => <SelectItem key={h} value={String(h)}>{h} hop{h > 1 ? "s" : ""}</SelectItem>)}</SelectContent>
          </Select>
        )}
      </div>
      {graph.isLoading && <LoadingState label="Computing centrality…" />}
      {graph.isError && <ErrorState message={errorMessage(graph.error)} onRetry={() => graph.refetch()} />}
      {graph.data && graph.data.nodes.length === 0 && <EmptyState title="No patents in your collection" description="Import patent records with citations to explore citation relationships." />}
      {graph.data && graph.data.nodes.length > 0 && (
        <div className="space-y-4">
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            <StatCard label="Nodes" value={graph.data.nodes.length} />
            <StatCard label="Edges" value={graph.data.edges.length} />
            <StatCard label="Most cited" value={<span className="font-mono text-lg">{[...graph.data.nodes].sort((a, b) => b.inDegree - a.inDegree)[0]?.patent_number}</span>} hint={`${[...graph.data.nodes].sort((a, b) => b.inDegree - a.inDegree)[0]?.inDegree} citations`} />
            <StatCard label="Top PageRank" value={<span className="font-mono text-lg">{top[0]?.patent_number}</span>} hint={top[0] ? top[0].pagerank.toFixed(4) : ""} tone="accent" />
          </div>
          <CitationGraphView graph={graph.data} focusId={focus} onExpand={(id) => { setFocus(id); setHops(2); }} onReset={() => setFocus(search.patent ?? null)} />
        </div>
      )}
    </div>
  );
}
