import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { z } from "zod";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { FileText, Loader2, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { useAnalysisBundle, AnalysisHeaderMeta } from "@/components/analysis/useAnalysis";
import { PriorArtPanel } from "@/components/analysis/PriorArtPanel";
import { ComparisonPanel } from "@/components/analysis/ComparisonPanel";
import { OptimizerPanel } from "@/components/analysis/OptimizerPanel";
import { TimelinePanel } from "@/components/analysis/TimelinePanel";
import { ExaminerPanel } from "@/components/analysis/ExaminerPanel";
import { CitationGraphView } from "@/components/analysis/CitationGraphView";
import { getCitationGraph } from "@/lib/citations.functions";
import { generateReport } from "@/lib/reports.functions";
import { deleteAnalysis } from "@/lib/analysis.functions";
import { PageHeader, LoadingState, ErrorState, StatCard, ScoringModeBadge, LegalNotice, pct, errorMessage } from "@/components/common";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const searchSchema = z.object({ tab: z.string().optional(), target: z.string().optional(), candidate: z.string().optional() });

export const Route = createFileRoute("/_authenticated/analyses/$id")({
  validateSearch: (s) => searchSchema.parse(s),
  head: () => ({
    meta: [
      { title: "Analysis detail – Patent Prior-Art Analytics Engine" },
      { name: "description", content: "Ranked prior art, claim comparison, citation network, reference-set optimisation, timeline and examiner recommendation for one analysis." },
      { property: "og:title", content: "Prior-art analysis detail" },
      { property: "og:description", content: "Full results for one prior-art analysis." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: AnalysisDetail,
});

function AnalysisDetail() {
  const { id } = Route.useParams();
  const { tab = "prior-art", target, candidate } = Route.useSearch();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const q = useAnalysisBundle(id);
  const graphFn = useServerFn(getCitationGraph);
  const genReport = useServerFn(generateReport);
  const delFn = useServerFn(deleteAnalysis);
  const [focus, setFocus] = useState<string | null>(null);

  const graph = useQuery({
    queryKey: ["citations", "analysis", id, q.data?.patent.id, focus],
    queryFn: () => graphFn({ data: { focusPatentId: focus ?? q.data!.patent.id, hops: 2 } }),
    enabled: Boolean(q.data) && tab === "citations",
  });
  const report = useMutation({
    mutationFn: () => genReport({ data: { analysisId: id } }),
    onSuccess: (r) => { qc.invalidateQueries({ queryKey: ["reports"] }); toast.success("Report generated"); navigate({ to: "/reports/$id", params: { id: r.id } }); },
    onError: (e) => toast.error(errorMessage(e)),
  });
  const del = useMutation({
    mutationFn: () => delFn({ data: { id } }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["analyses"] }); toast.success("Analysis deleted"); navigate({ to: "/dashboard" }); },
    onError: (e) => toast.error(errorMessage(e)),
  });

  if (q.isLoading) return <LoadingState label="Loading analysis…" />;
  if (q.isError || !q.data) return <ErrorState message={errorMessage(q.error, "Unable to retrieve analysis data. Please try again.")} onRetry={() => q.refetch()} />;
  const b = q.data;
  const s = (b.analysis.summary ?? {}) as Record<string, number>;
  const setTab = (t: string) => navigate({ to: "/analyses/$id", params: { id }, search: (prev) => ({ ...prev, tab: t }), replace: true });

  return (
    <div>
      <PageHeader
        eyebrow="Analysis"
        title={b.patent.title}
        description={undefined}
        actions={
          <>
            <Button variant="outline" size="sm" onClick={() => { if (confirm("Delete this analysis and its results?")) del.mutate(); }} disabled={del.isPending}><Trash2 className="h-4 w-4" /> Delete</Button>
            <Button onClick={() => report.mutate()} disabled={report.isPending || b.analysis.status !== "completed"}>{report.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <FileText className="h-4 w-4" />} Generate report</Button>
          </>
        }
      />
      <div className="-mt-4 mb-4"><AnalysisHeaderMeta b={b} /></div>

      {b.analysis.status !== "completed" && (
        <div className="mb-4 rounded-md border border-warning/40 bg-warning/10 p-3 text-sm">
          This analysis {b.analysis.status === "failed" ? `failed: ${b.analysis.error_message ?? "unknown error"}` : `is ${b.analysis.status} (stage: ${b.analysis.stage})`}. <Link to="/analyzer" search={{ patent: b.patent.id }} className="underline">Re-run in the Analyzer</Link>.
        </div>
      )}

      <div className="mb-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
        <StatCard label="Target claims" value={b.targetClaims.length} hint={`${s["claim_count"] ?? "—"} total claims`} />
        <StatCard label="Features" value={b.features.length} />
        <StatCard label="References" value={b.priorArt.length} hint={`${s["above_threshold"] ?? 0} above ${pct(s["threshold"])}`} tone="accent" />
        <StatCard label="Top similarity" value={pct(s["top_similarity"])} hint={`avg ${pct(s["avg_similarity"])}`} />
        <StatCard label="Set coverage" value={pct(s["set_coverage_pct"])} hint={`${b.references.length} reference(s)`} />
      </div>
      <div className="mb-4"><ScoringModeBadge mode={b.analysis.scoring_mode} notice={b.analysis.scoring_notice} /></div>

      <Tabs value={tab} onValueChange={setTab}>
        <TabsList className="flex h-auto flex-wrap justify-start">
          <TabsTrigger value="prior-art">Prior Art</TabsTrigger>
          <TabsTrigger value="compare">Claim Comparison</TabsTrigger>
          <TabsTrigger value="optimizer">Optimizer</TabsTrigger>
          <TabsTrigger value="citations">Citation Network</TabsTrigger>
          <TabsTrigger value="timeline">Timeline</TabsTrigger>
          <TabsTrigger value="examiner">Examiner</TabsTrigger>
        </TabsList>
        <TabsContent value="prior-art" className="mt-4"><PriorArtPanel b={b} /></TabsContent>
        <TabsContent value="compare" className="mt-4">
          <ComparisonPanel b={b} targetClaimId={target} candidateClaimId={candidate} onChange={(v) => navigate({ to: "/analyses/$id", params: { id }, search: (prev) => ({ ...prev, ...(v.target ? { target: v.target, candidate: undefined } : {}), ...(v.candidate ? { candidate: v.candidate } : {}) }), replace: true })} />
        </TabsContent>
        <TabsContent value="optimizer" className="mt-4"><OptimizerPanel b={b} /></TabsContent>
        <TabsContent value="citations" className="mt-4">
          {graph.isLoading && <LoadingState label="Building citation graph…" />}
          {graph.isError && <ErrorState message={errorMessage(graph.error)} onRetry={() => graph.refetch()} />}
          {graph.data && <CitationGraphView graph={graph.data} focusId={focus ?? b.patent.id} onExpand={(nid) => setFocus(nid)} onReset={() => setFocus(null)} />}
        </TabsContent>
        <TabsContent value="timeline" className="mt-4 card-elevated p-4"><TimelinePanel b={b} /></TabsContent>
        <TabsContent value="examiner" className="mt-4"><ExaminerPanel b={b} /></TabsContent>
      </Tabs>
      <div className="mt-8"><LegalNotice compact /></div>
    </div>
  );
}
