import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { FileText, Layers, Network, ScanSearch, Sigma, Sparkles } from "lucide-react";
import { Bar, BarChart, CartesianGrid, Cell, Line, LineChart, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { getDashboardData } from "@/lib/dashboard.functions";
import { PageHeader, StatCard, LoadingState, ErrorState, EmptyState, DatasetBadge, pct, fmtDate, errorMessage } from "@/components/common";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

export const Route = createFileRoute("/_authenticated/dashboard")({
  head: () => ({
    meta: [
      { title: "Dashboard – Patent Prior-Art Analytics Engine" },
      { name: "description", content: "Corpus statistics, similarity distributions, classification and citation activity, and your recent analyses." },
      { property: "og:title", content: "Analytics Dashboard" },
      { property: "og:description", content: "Corpus statistics and recent prior-art analyses." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Dashboard,
});

const COLORS = ["var(--chart-1)", "var(--chart-2)", "var(--chart-3)", "var(--chart-4)", "var(--chart-5)", "oklch(0.45 0.08 262)", "oklch(0.75 0.08 218)", "oklch(0.5 0.05 255)"];

function ChartCard({ title, children, subtitle }: { title: string; subtitle?: string; children: React.ReactNode }) {
  return (
    <div className="card-elevated p-4">
      <h3 className="text-sm font-semibold">{title}</h3>
      {subtitle && <p className="text-xs text-muted-foreground">{subtitle}</p>}
      <div className="mt-3 h-52">{children}</div>
    </div>
  );
}

function StatusBadge({ status }: { status: string }) {
  if (status === "completed") return <Badge className="bg-success text-success-foreground hover:bg-success">Completed</Badge>;
  if (status === "failed") return <Badge variant="destructive">Failed</Badge>;
  return <Badge variant="secondary">{status === "running" ? "In progress" : status}</Badge>;
}

function Dashboard() {
  const fn = useServerFn(getDashboardData);
  const q = useQuery({ queryKey: ["dashboard"], queryFn: () => fn() });

  if (q.isLoading) return <LoadingState label="Loading dashboard…" />;
  if (q.isError || !q.data) return <ErrorState message={errorMessage(q.error, "Unable to retrieve patent data. Please try again.")} onRetry={() => q.refetch()} />;
  const d = q.data;
  const tooltipStyle = { fontSize: 12, borderRadius: 6, border: "1px solid var(--border)" };

  return (
    <div>
      <PageHeader
        eyebrow="Overview"
        title="Dashboard"
        description="Corpus statistics and your analysis activity. Demo patents are fictional and clearly labelled."
        actions={
          <Button asChild>
            <Link to="/analyzer"><ScanSearch className="h-4 w-4" /> New analysis</Link>
          </Button>
        }
      />

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6">
        <StatCard label="Total Patents" value={d.stats.total_patents} hint={`${d.stats.demo_patents} demo · ${d.stats.imported_patents} imported`} icon={<FileText className="h-4 w-4" />} />
        <StatCard label="Total Claims" value={d.stats.total_claims} icon={<Layers className="h-4 w-4" />} />
        <StatCard label="Total Analyses" value={d.stats.total_analyses} hint="Your account" icon={<ScanSearch className="h-4 w-4" />} />
        <StatCard label="Prior-Art References" value={d.stats.references_found} hint="Found across analyses" icon={<Sparkles className="h-4 w-4" />} tone="accent" />
        <StatCard label="Avg Similarity" value={pct(d.stats.avg_similarity)} hint="Best score per reference" icon={<Sigma className="h-4 w-4" />} />
        <StatCard label="Citation Relationships" value={d.stats.citation_count} icon={<Network className="h-4 w-4" />} />
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-2">
        <ChartCard title="Patent analysis activity" subtitle="Analyses started per month (last 6 months)">
          <ResponsiveContainer>
            <LineChart data={d.activity} margin={{ left: -20, right: 8, top: 8 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
              <XAxis dataKey="month" tick={{ fontSize: 11 }} />
              <YAxis allowDecimals={false} tick={{ fontSize: 11 }} />
              <Tooltip contentStyle={tooltipStyle} />
              <Line type="monotone" dataKey="analyses" stroke="var(--chart-2)" strokeWidth={2} dot={{ r: 3 }} />
            </LineChart>
          </ResponsiveContainer>
        </ChartCard>
        <ChartCard title="Similarity score distribution" subtitle="Best combined score per prior-art reference">
          {d.distribution.every((b) => b.count === 0) ? (
            <div className="flex h-full items-center justify-center text-sm text-muted-foreground">No analyses yet.</div>
          ) : (
            <ResponsiveContainer>
              <BarChart data={d.distribution} margin={{ left: -20, right: 8, top: 8 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                <XAxis dataKey="range" tick={{ fontSize: 11 }} />
                <YAxis allowDecimals={false} tick={{ fontSize: 11 }} />
                <Tooltip contentStyle={tooltipStyle} />
                <Bar dataKey="count" fill="var(--chart-1)" radius={[3, 3, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          )}
        </ChartCard>
        <ChartCard title="Patent classification distribution" subtitle="Patents per CPC subclass (top 8)">
          <ResponsiveContainer>
            <PieChart>
              <Pie data={d.classification} dataKey="count" nameKey="code" innerRadius={45} outerRadius={80} paddingAngle={2}>
                {d.classification.map((_, i) => (
                  <Cell key={i} fill={COLORS[i % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip contentStyle={tooltipStyle} />
            </PieChart>
          </ResponsiveContainer>
        </ChartCard>
        <ChartCard title="Citation activity" subtitle="Citations made by patents published each year">
          <ResponsiveContainer>
            <BarChart data={d.citationActivity} margin={{ left: -20, right: 8, top: 8 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
              <XAxis dataKey="year" tick={{ fontSize: 11 }} />
              <YAxis allowDecimals={false} tick={{ fontSize: 11 }} />
              <Tooltip contentStyle={tooltipStyle} />
              <Bar dataKey="citations" fill="var(--chart-4)" radius={[3, 3, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      <div className="card-elevated mt-6 overflow-hidden">
        <div className="flex items-center justify-between border-b border-border px-4 py-3">
          <h3 className="text-sm font-semibold">Recent analyses</h3>
          <Button asChild variant="ghost" size="sm"><Link to="/prior-art">View all</Link></Button>
        </div>
        {d.recent.length === 0 ? (
          <div className="p-4">
            <EmptyState title="No analyses yet" description="Run your first prior-art analysis on a demo or imported patent." action={<Button asChild><Link to="/analyzer">Open Patent Analyzer</Link></Button>} />
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Patent</TableHead>
                <TableHead>Analysis Date</TableHead>
                <TableHead className="text-right">References Found</TableHead>
                <TableHead className="text-right">Top Similarity</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Action</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {d.recent.map((a) => {
                const s = (a.summary ?? {}) as Record<string, number>;
                return (
                  <TableRow key={a.id}>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-xs">{a.patent?.patent_number ?? "—"}</span>
                        {a.patent && <DatasetBadge isDemo={a.patent.is_demo} />}
                      </div>
                      <p className="max-w-xs truncate text-xs text-muted-foreground">{a.patent?.title}</p>
                    </TableCell>
                    <TableCell className="text-sm">{fmtDate(a.created_at)}</TableCell>
                    <TableCell className="text-right font-mono text-sm">{s["references_found"] ?? "—"}</TableCell>
                    <TableCell className="text-right font-mono text-sm">{pct(s["top_similarity"])}</TableCell>
                    <TableCell><StatusBadge status={a.status} /></TableCell>
                    <TableCell className="text-right">
                      <Button asChild size="sm" variant="outline">
                        <Link to="/analyses/$id" params={{ id: a.id }}>Open</Link>
                      </Button>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        )}
      </div>
    </div>
  );
}
