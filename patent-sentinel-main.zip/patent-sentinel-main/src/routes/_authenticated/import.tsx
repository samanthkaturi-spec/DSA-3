import { createFileRoute, Link } from "@tanstack/react-router";
import { useRef, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import Papa from "papaparse";
import { Download, FileUp, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { importPatents, listImportJobs } from "@/lib/patents.functions";
import { PageHeader, StatCard, errorMessage, fmtDate } from "@/components/common";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { downloadText } from "@/lib/csv";

export const Route = createFileRoute("/_authenticated/import")({
  head: () => ({
    meta: [
      { title: "Import Patents – Patent Prior-Art Analytics Engine" },
      { name: "description", content: "Import patents from CSV or JSON with validation, duplicate detection and per-row error reporting." },
      { property: "og:title", content: "Import Patents" },
      { property: "og:description", content: "CSV / JSON patent import with validation." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: ImportPage,
});

const FIELDS = ["patent_number", "title", "abstract", "claims", "inventors", "assignee", "filing_date", "publication_date", "priority_date", "cpc_codes", "ipc_codes"];
const TEMPLATE = `patent_number,title,abstract,claims,inventors,assignee,filing_date,publication_date,priority_date,cpc_codes,ipc_codes
SAMPLE-001,Example Sensor Hub,"An example abstract.","1. A sensor hub comprising: a camera; a processor; and a radio. 2. The sensor hub of claim 1, wherein the radio is cellular.","A. Inventor; B. Inventor",Example Corp,2021-01-15,2022-07-21,2021-01-15,"G06V10/82; H04W4/38",G06V10/82`;

type ImportResult = Awaited<ReturnType<typeof importPatents>>;
type ImportFile = { fileName: string; rows: Record<string, unknown>[] };

function ImportPage() {
  const qc = useQueryClient();
  const importFn = useServerFn(importPatents);
  const jobsFn = useServerFn(listImportJobs);
  const jobs = useQuery({ queryKey: ["import-jobs"], queryFn: () => jobsFn() });
  const [preview, setPreview] = useState<{ files: ImportFile[]; totalRows: number; missing: string[] } | null>(null);
  const [result, setResult] = useState<ImportResult | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const mut = useMutation({
    mutationFn: () => importFn({ data: { files: preview?.files ?? [] } }),
    onSuccess: (r) => {
      setResult(r);
      qc.invalidateQueries({ queryKey: ["import-jobs"] });
      qc.invalidateQueries({ queryKey: ["dashboard"] });
      qc.invalidateQueries({ queryKey: ["patents"] });
      toast.success(`${r.imported_rows} patent(s) imported`);
    },
    onError: (e) => toast.error(errorMessage(e, "Unable to import this file.")),
  });

  async function parseFile(file: File): Promise<ImportFile> {
    if (!/\.(csv|json)$/i.test(file.name)) throw new Error(`${file.name}: choose a CSV or JSON file.`);
    const text = await file.text();
    let rows: Record<string, unknown>[] = [];
    if (file.name.toLowerCase().endsWith(".json")) {
      const parsed = JSON.parse(text) as unknown;
      const arr = Array.isArray(parsed) ? parsed : (parsed as { patents?: unknown[] })?.patents;
      if (!Array.isArray(arr)) throw new Error(`${file.name}: JSON must be an array of patent objects (or { patents: [...] }).`);
      rows = arr as Record<string, unknown>[];
    } else {
      const res = Papa.parse<Record<string, unknown>>(text, { header: true, skipEmptyLines: true, transformHeader: (h) => h.trim().toLowerCase() });
      if (res.errors.length && res.data.length === 0) throw new Error(`${file.name}: unable to parse this CSV file.`);
      rows = res.data;
    }
    if (rows.length === 0) throw new Error(`${file.name}: the file contains no rows.`);
    if (rows.length > 2000) throw new Error(`${file.name}: import at most 2,000 rows per file.`);
    return { fileName: file.name, rows };
  }

  async function handleFiles(fileList: FileList | File[]) {
    setResult(null);
    setPreview(null);
    try {
      const selected = Array.from(fileList);
      if (selected.length === 0) return;
      if (selected.length > 10) throw new Error("Choose no more than 10 files at once.");
      const files: ImportFile[] = [];
      const parseErrors: string[] = [];
      for (const file of selected) {
        try { files.push(await parseFile(file)); }
        catch (e) { parseErrors.push(errorMessage(e, "Unable to process this document.")); }
      }
      if (files.length === 0) throw new Error(parseErrors.join(" ") || "No valid files selected.");
      const rows = files.flatMap((file) => file.rows);
      const keys = new Set(Object.keys(rows[0] ?? {}).map((k) => k.toLowerCase()));
      const missing = ["patent_number", "title", "claims"].filter((k) => !keys.has(k));
      setPreview({ files, totalRows: rows.length, missing });
      if (parseErrors.length) toast.error(parseErrors.join(" "));
    } catch (e) {
      toast.error(errorMessage(e, "Unable to process this document. Please verify the file format."));
    } finally {
      if (fileRef.current) fileRef.current.value = "";
    }
  }

  return (
    <div>
      <PageHeader eyebrow="Data" title="Import Patents" description="Choose up to 10 CSV or JSON files together. Each file can contain up to 2,000 rows; duplicates are skipped across your existing patents and this batch." actions={<Button variant="outline" onClick={() => downloadText("patent-import-template.csv", TEMPLATE, "text/csv")}><Download className="h-4 w-4" /> CSV template</Button>} />

      <div className="grid gap-4 lg:grid-cols-[1fr_320px]">
        <div className="space-y-4">
          <div
            className="flex flex-col items-center justify-center rounded-lg border-2 border-dashed border-border bg-surface-2 px-6 py-10 text-center"
            onDragOver={(e) => e.preventDefault()}
            onDrop={(e) => { e.preventDefault(); if (e.dataTransfer.files.length) void handleFiles(e.dataTransfer.files); }}
          >
            <FileUp className="mb-2 h-6 w-6 text-muted-foreground" />
            <p className="text-sm font-medium">Drop CSV or JSON files here</p>
            <p className="mt-1 text-xs text-muted-foreground">Required columns: patent_number, title, claims · dates as YYYY-MM-DD · lists separated by ; | or ,</p>
            <input ref={fileRef} type="file" multiple accept=".csv,.json,text/csv,application/json" className="hidden" onChange={(e) => { if (e.target.files?.length) void handleFiles(e.target.files); }} />
            <Button className="mt-4" variant="outline" onClick={() => fileRef.current?.click()}>Choose files</Button>
          </div>

          {preview && (
            <div className="card-elevated p-4">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <h3 className="font-semibold">{preview.files.length} file{preview.files.length === 1 ? "" : "s"} selected</h3>
                  <p className="text-xs text-muted-foreground">{preview.totalRows} rows · {preview.files.map((f) => f.fileName).join(", ")}</p>
                  {preview.missing.length > 0 && <p className="mt-1 text-xs text-destructive">Missing required columns: {preview.missing.join(", ")}</p>}
                </div>
                <Button onClick={() => mut.mutate()} disabled={mut.isPending || preview.missing.length > 0}>{mut.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <FileUp className="h-4 w-4" />} Validate &amp; import</Button>
              </div>
              <div className="mt-3 overflow-x-auto">
                <Table>
                  <TableHeader><TableRow><TableHead>Source file</TableHead>{FIELDS.filter((f) => f in (preview.files[0]?.rows[0] ?? {})).map((f) => <TableHead key={f} className="text-xs">{f}</TableHead>)}</TableRow></TableHeader>
                  <TableBody>
                    {preview.files.flatMap((f) => f.rows.slice(0, 5).map((row, i) => ({ file: f.fileName, row, key: `${f.fileName}-${i}` }))).slice(0, 10).map(({ file, row, key }) => (
                      <TableRow key={key}><TableCell className="max-w-40 truncate text-xs">{file}</TableCell>{FIELDS.filter((f) => f in (preview.files[0]?.rows[0] ?? {})).map((f) => <TableCell key={f} className="max-w-48 truncate text-xs">{String(row[f] ?? "")}</TableCell>)}</TableRow>
                    ))}
                  </TableBody>
                </Table>
                {preview.totalRows > 10 && <p className="mt-1 text-xs text-muted-foreground">Showing up to 5 rows from each file (10 rows maximum).</p>}
              </div>
            </div>
          )}

          {result && (
            <div className="space-y-3">
              <div className="grid gap-3 sm:grid-cols-5">
                <StatCard label="Total Rows" value={result.total_rows} />
                <StatCard label="Valid Rows" value={result.valid_rows} />
                <StatCard label="Invalid Rows" value={result.invalid_rows} />
                <StatCard label="Duplicates" value={result.duplicate_rows} />
                <StatCard label="Imported Rows" value={result.imported_rows} tone="accent" />
              </div>
              {result.errors.length > 0 && (
                <div className="card-elevated overflow-x-auto">
                  <Table>
                    <TableHeader><TableRow><TableHead>File</TableHead><TableHead>Row</TableHead><TableHead>Patent number</TableHead><TableHead>Problem</TableHead></TableRow></TableHeader>
                    <TableBody>{result.errors.map((e, i) => <TableRow key={i}><TableCell className="text-xs">{e.file_name}</TableCell><TableCell className="font-mono text-xs">{e.row}</TableCell><TableCell className="font-mono text-xs">{e.patent_number || "—"}</TableCell><TableCell className="text-xs">{e.message}</TableCell></TableRow>)}</TableBody>
                  </Table>
                </div>
              )}
              {result.imported_rows > 0 && <p className="text-sm">Imported patents are available under the <Link to="/search" className="text-accent hover:underline">Imported dataset</Link>.</p>}
              {result.files.length > 1 && <div className="flex flex-wrap gap-2">{result.files.map((file) => <span key={file.file_name} className="rounded border border-border px-2 py-1 text-xs text-muted-foreground">{file.file_name}: {file.imported_rows} imported · {file.errors} errors</span>)}</div>}
            </div>
          )}
        </div>

        <div className="card-elevated p-4">
          <h3 className="text-sm font-semibold">Import history</h3>
          <ul className="mt-2 space-y-2 text-xs">
            {(jobs.data ?? []).map((j) => (
              <li key={j.id} className="rounded border border-border p-2">
                <p className="font-medium">{j.file_name ?? "import"}</p>
                <p className="text-muted-foreground">{fmtDate(j.created_at)} · {j.imported_rows}/{j.total_rows} imported · {j.invalid_rows} invalid · {j.duplicate_rows} dup</p>
              </li>
            ))}
            {jobs.data && jobs.data.length === 0 && <li className="text-muted-foreground">No imports yet.</li>}
          </ul>
        </div>
      </div>
    </div>
  );
}
