import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Loader2, RotateCcw, Save } from "lucide-react";
import { toast } from "sonner";
import { resetSettings, saveSettings, DEFAULT_SETTINGS, type UserSettings } from "@/lib/settings.functions";
import { useSettingsQuery } from "@/components/layout/AppShell";
import { PageHeader, LoadingState, ErrorState, errorMessage } from "@/components/common";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export const Route = createFileRoute("/_authenticated/settings")({
  head: () => ({
    meta: [
      { title: "Settings – Patent Prior-Art Analytics Engine" },
      { name: "description", content: "Configure similarity weights, thresholds, result counts, embedding provider and search settings." },
      { property: "og:title", content: "Analysis Settings" },
      { property: "og:description", content: "Configure similarity weights and the embedding provider." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: SettingsPage,
});

function Card({ title, description, children }: { title: string; description?: string; children: React.ReactNode }) {
  return (
    <section className="card-elevated p-5">
      <h2 className="font-semibold">{title}</h2>
      {description && <p className="mb-4 text-sm text-muted-foreground">{description}</p>}
      <div className="space-y-4">{children}</div>
    </section>
  );
}

function WeightSlider({ label, value, onChange }: { label: string; value: number; onChange: (v: number) => void }) {
  return (
    <div>
      <div className="flex justify-between text-sm"><Label>{label}</Label><span className="font-mono text-xs">{value.toFixed(2)}</span></div>
      <Slider value={[value]} min={0} max={1} step={0.05} onValueChange={([v]) => onChange(v ?? 0)} className="mt-2" />
    </div>
  );
}

function SettingsPage() {
  const qc = useQueryClient();
  const q = useSettingsQuery();
  const save = useServerFn(saveSettings);
  const reset = useServerFn(resetSettings);
  const [form, setForm] = useState<UserSettings>(DEFAULT_SETTINGS);
  useEffect(() => { if (q.data) setForm(q.data); }, [q.data]);

  const saveMut = useMutation({
    mutationFn: () => save({ data: form }),
    onSuccess: (d) => { qc.setQueryData(["settings"], d); toast.success("Settings saved"); },
    onError: (e) => toast.error(errorMessage(e)),
  });
  const resetMut = useMutation({
    mutationFn: () => reset(),
    onSuccess: (d) => { qc.setQueryData(["settings"], d); setForm(d); toast.success("Settings reset to defaults"); },
    onError: (e) => toast.error(errorMessage(e)),
  });

  if (q.isLoading) return <LoadingState label="Loading settings…" />;
  if (q.isError) return <ErrorState message={errorMessage(q.error)} onRetry={() => q.refetch()} />;

  const fullSum = form.semantic_weight + form.keyword_weight + form.classification_weight;
  const fbSum = form.fallback_keyword_weight + form.fallback_classification_weight;
  const set = <K extends keyof UserSettings>(k: K, v: UserSettings[K]) => setForm((f) => ({ ...f, [k]: v }));

  return (
    <div>
      <PageHeader
        eyebrow="Configuration"
        title="Settings"
        description="These settings are snapshotted into each analysis so results stay reproducible."
        actions={
          <>
            <Button variant="outline" onClick={() => resetMut.mutate()} disabled={resetMut.isPending}><RotateCcw className="h-4 w-4" /> Reset Settings</Button>
            <Button onClick={() => saveMut.mutate()} disabled={saveMut.isPending}>{saveMut.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />} Save Settings</Button>
          </>
        }
      />
      <div className="grid gap-4 lg:grid-cols-2">
        <Card title="Similarity weights (semantic mode)" description="Combined = semantic × keyword × classification weights, normalised to their sum.">
          <WeightSlider label="Semantic similarity" value={form.semantic_weight} onChange={(v) => set("semantic_weight", v)} />
          <WeightSlider label="Keyword similarity (TF-IDF)" value={form.keyword_weight} onChange={(v) => set("keyword_weight", v)} />
          <WeightSlider label="Classification similarity (CPC/IPC)" value={form.classification_weight} onChange={(v) => set("classification_weight", v)} />
          <p className={`font-mono text-xs ${Math.abs(fullSum - 1) > 0.01 ? "text-warning-foreground" : "text-muted-foreground"}`}>sum = {fullSum.toFixed(2)}{Math.abs(fullSum - 1) > 0.01 && " (will be normalised)"}</p>
        </Card>
        <Card title="Fallback weights (keyword mode)" description="Used when semantic embeddings are unavailable or disabled.">
          <WeightSlider label="Keyword similarity" value={form.fallback_keyword_weight} onChange={(v) => set("fallback_keyword_weight", v)} />
          <WeightSlider label="Classification similarity" value={form.fallback_classification_weight} onChange={(v) => set("fallback_classification_weight", v)} />
          <p className={`font-mono text-xs ${Math.abs(fbSum - 1) > 0.01 ? "text-warning-foreground" : "text-muted-foreground"}`}>sum = {fbSum.toFixed(2)}</p>
        </Card>
        <Card title="Results" description="Threshold used for the “Potentially Relevant Prior Art” label and the number of ranked references kept per analysis.">
          <WeightSlider label="Similarity threshold" value={form.similarity_threshold} onChange={(v) => set("similarity_threshold", v)} />
          <div>
            <Label>Number of prior-art results</Label>
            <Input type="number" min={3} max={50} value={form.max_results} onChange={(e) => set("max_results", Math.max(3, Math.min(50, Number(e.target.value) || 3)))} className="mt-1 w-32" />
          </div>
        </Card>
        <Card title="Embedding provider & API configuration" description="Semantic similarity requires an embedding provider. Keys are never stored in the browser.">
          <div>
            <Label>Provider</Label>
            <Select value={form.embedding_provider} onValueChange={(v) => set("embedding_provider", v as UserSettings["embedding_provider"])}>
              <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="lovable">Lovable AI (built-in, no key required)</SelectItem>
                <SelectItem value="custom">Custom OpenAI-compatible endpoint</SelectItem>
                <SelectItem value="none">None – keyword/TF-IDF only</SelectItem>
              </SelectContent>
            </Select>
          </div>
          {form.embedding_provider === "lovable" && (
            <div>
              <Label>Model</Label>
              <Input value={form.embedding_model} onChange={(e) => set("embedding_model", e.target.value)} className="mt-1 font-mono text-xs" />
              <p className="mt-1 text-xs text-muted-foreground">Default: google/gemini-embedding-2 (3072 dimensions, stored with pgvector).</p>
            </div>
          )}
          {form.embedding_provider === "custom" && (
            <>
              <div>
                <Label>Base URL</Label>
                <Input placeholder="https://api.example.com/v1" value={form.custom_embedding_base_url ?? ""} onChange={(e) => set("custom_embedding_base_url", e.target.value || null)} className="mt-1 font-mono text-xs" />
              </div>
              <div>
                <Label>Model</Label>
                <Input placeholder="text-embedding-3-large" value={form.custom_embedding_model ?? ""} onChange={(e) => set("custom_embedding_model", e.target.value || null)} className="mt-1 font-mono text-xs" />
              </div>
              <p className="rounded-md border border-border bg-surface-2 p-2 text-xs text-muted-foreground">The API key must be stored as the backend secret <span className="font-mono">CUSTOM_EMBEDDING_API_KEY</span>; it is read only on the server. The endpoint must return 3072-dimensional vectors to be stored alongside the default model.</p>
            </>
          )}
        </Card>
        <Card title="Search settings" description="Controls candidate retrieval across your uploaded patent collection.">
          <div>
            <Label>Search mode</Label>
            <Select value={form.search_mode} onValueChange={(v) => set("search_mode", v as UserSettings["search_mode"])}>
              <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="hybrid">Hybrid – full-text + vector (recommended)</SelectItem>
                <SelectItem value="semantic">Semantic preferred</SelectItem>
                <SelectItem value="keyword">Keyword only (skip embeddings)</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </Card>
      </div>
    </div>
  );
}
