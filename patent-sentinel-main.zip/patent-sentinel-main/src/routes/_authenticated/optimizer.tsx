import { createFileRoute } from "@tanstack/react-router";
import { z } from "zod";
import { useAnalysisBundle, AnalysisPicker, AnalysisHeaderMeta } from "@/components/analysis/useAnalysis";
import { OptimizerPanel } from "@/components/analysis/OptimizerPanel";
import { PageHeader, LoadingState, ErrorState, NoAnalysisPrompt, LegalNotice, errorMessage } from "@/components/common";

const searchSchema = z.object({ analysis: z.string().uuid().optional() });

export const Route = createFileRoute("/_authenticated/optimizer")({
  validateSearch: (s) => searchSchema.parse(s),
  head: () => ({
    meta: [
      { title: "Prior-Art Optimizer – Patent Prior-Art Analytics Engine" },
      { name: "description", content: "Greedy Set Cover over the claim-feature coverage matrix to identify a minimum / small prior-art reference set." },
      { property: "og:title", content: "Prior-Art Optimizer" },
      { property: "og:description", content: "Greedy set-cover reference selection with explanations." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: OptimizerPage,
});

function OptimizerPage() {
  const { analysis } = Route.useSearch();
  const q = useAnalysisBundle(analysis);
  return (
    <div>
      <PageHeader eyebrow="Optimisation" title="Prior-Art Optimizer" description="Identifies a minimum / small prior-art reference set that jointly covers the most target claim features." />
      <div className="mb-4"><AnalysisPicker value={analysis} to="/optimizer" /></div>
      {!analysis && <NoAnalysisPrompt />}
      {analysis && q.isLoading && <LoadingState label="Loading coverage…" />}
      {analysis && q.isError && <ErrorState message={errorMessage(q.error)} onRetry={() => q.refetch()} />}
      {q.data && (
        <div className="space-y-4">
          <AnalysisHeaderMeta b={q.data} />
          <OptimizerPanel b={q.data} />
        </div>
      )}
      <div className="mt-8"><LegalNotice compact /></div>
    </div>
  );
}
