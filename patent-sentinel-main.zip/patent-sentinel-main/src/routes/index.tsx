import { createFileRoute, Link } from "@tanstack/react-router";
import {
  ArrowRight,
  BrainCircuit,
  FileSearch,
  GitBranch,
  LayoutDashboard,
  Network,
  Scale,
  Target,
  Upload,
  Layers,
  Columns2,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";
import { LEGAL_DISCLAIMER } from "@/lib/analysis-stages";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Patent Prior-Art & Litigation Analytics Engine" },
      {
        name: "description",
        content:
          "AI-powered patent search, claim similarity, citation analytics and prior-art optimization for research and decision support.",
      },
      { property: "og:title", content: "Patent Prior-Art & Litigation Analytics Engine" },
      {
        property: "og:description",
        content: "AI-powered patent search, claim similarity, citation analytics and prior-art optimization.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Landing,
});

const STEPS = [
  { icon: Upload, title: "Ingest", text: "Enter a patent number, upload a PDF/DOCX/TXT or paste claims. Title, abstract and numbered claims are extracted and normalised." },
  { icon: BrainCircuit, title: "Represent", text: "Each claim becomes a TF-IDF keyword vector and, when an embedding provider is configured, a semantic embedding." },
  { icon: FileSearch, title: "Search & score", text: "Full-text and vector search retrieve candidates; combined scores blend semantic, keyword and classification similarity." },
  { icon: Target, title: "Optimise & report", text: "Claim features are matched per reference, a greedy set cover selects a small reference set, and a report is generated." },
];

const CAPABILITIES = [
  { icon: FileSearch, title: "Patent Search", text: "Search by number, title, abstract, claims, inventor, assignee, CPC or IPC with date and classification filters." },
  { icon: Layers, title: "Prior-Art Ranking", text: "Ranked, threshold-filterable references with per-component similarity bars and scoring-mode transparency." },
  { icon: Columns2, title: "Claim Comparison", text: "Side-by-side claims, highlighted shared concepts and an editable claim-feature coverage matrix." },
  { icon: Network, title: "Citation Intelligence", text: "Interactive citation graph with in/out degree, degree centrality and PageRank, plus a citation table." },
  { icon: Target, title: "Prior-Art Optimization", text: "Greedy Set Cover identifies a minimum / small prior-art reference set covering the most claim features." },
  { icon: LayoutDashboard, title: "Analytics Dashboard", text: "Activity, similarity distribution, classification and citation charts with a recent-analyses table." },
];

function NetworkIllustration() {
  const nodes = [
    { x: 160, y: 120, r: 22, main: true },
    { x: 60, y: 60, r: 10 },
    { x: 260, y: 50, r: 12 },
    { x: 290, y: 150, r: 9 },
    { x: 220, y: 220, r: 14 },
    { x: 90, y: 210, r: 11 },
    { x: 30, y: 140, r: 8 },
    { x: 330, y: 230, r: 7 },
  ];
  const edges = [
    [0, 1], [0, 2], [0, 3], [0, 4], [0, 5], [0, 6], [1, 6], [2, 3], [4, 7], [4, 5], [3, 7],
  ];
  return (
    <svg viewBox="0 0 360 270" className="h-auto w-full max-w-md" role="img" aria-label="Citation network illustration">
      {edges.map(([a, b], i) => (
        <line key={i} x1={nodes[a!]!.x} y1={nodes[a!]!.y} x2={nodes[b!]!.x} y2={nodes[b!]!.y} stroke="oklch(0.6 0.12 218 / 0.5)" strokeWidth={1.2} />
      ))}
      {nodes.map((n, i) => (
        <g key={i}>
          <circle cx={n.x} cy={n.y} r={n.r + 6} fill="oklch(0.6 0.12 218 / 0.12)" />
          <circle cx={n.x} cy={n.y} r={n.r} fill={n.main ? "oklch(0.6 0.12 218)" : "oklch(0.95 0.008 250)"} stroke="oklch(0.6 0.12 218)" strokeWidth={1.5} />
        </g>
      ))}
      <text x={160} y={125} textAnchor="middle" fontSize="11" fontFamily="IBM Plex Mono, monospace" fill="white">TARGET</text>
    </svg>
  );
}

function Landing() {
  const { isAuthenticated } = useAuth();
  const startTo = isAuthenticated ? "/analyzer" : "/auth";
  const demoTo = isAuthenticated ? "/dashboard" : "/auth";

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-30 border-b border-border bg-background/80 backdrop-blur">
        <div className="mx-auto flex h-14 max-w-6xl items-center justify-between px-4">
          <Link to="/" className="flex items-center gap-2">
            <span className="flex h-8 w-8 items-center justify-center rounded-md bg-primary text-primary-foreground">
              <Scale className="h-4 w-4" />
            </span>
            <span className="font-display text-sm font-semibold">PriorArt Engine</span>
          </Link>
          <nav className="hidden items-center gap-6 text-sm text-muted-foreground md:flex">
            <a href="#how" className="hover:text-foreground">How it works</a>
            <a href="#capabilities" className="hover:text-foreground">Capabilities</a>
            <a href="#ai" className="hover:text-foreground">AI & NLP</a>
          </nav>
          <div className="flex items-center gap-2">
            {isAuthenticated ? (
              <Button asChild size="sm"><Link to="/dashboard">Open workspace</Link></Button>
            ) : (
              <>
                <Button asChild variant="ghost" size="sm"><Link to="/auth">Sign in</Link></Button>
                <Button asChild size="sm"><Link to="/auth" search={{ mode: "register" }}>Register</Link></Button>
              </>
            )}
          </div>
        </div>
      </header>

      <section className="bg-grid-navy text-navy-foreground">
        <div className="mx-auto grid max-w-6xl items-center gap-10 px-4 py-20 md:grid-cols-[1.2fr_1fr] md:py-28">
          <div>
            <p className="mb-3 inline-flex items-center gap-2 rounded-full border border-navy-foreground/20 px-3 py-1 font-mono text-[11px] uppercase tracking-wider text-navy-foreground/80">
              <BrainCircuit className="h-3.5 w-3.5 text-accent" /> Research & decision-support platform
            </p>
            <h1 className="font-display text-4xl font-semibold leading-[1.1] md:text-5xl">
              Patent Prior-Art & Litigation Analytics Engine
            </h1>
            <p className="mt-5 max-w-xl text-lg text-navy-foreground/80">
              AI-powered patent search, claim similarity, citation analytics and prior-art optimization.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Button asChild size="lg" variant="accent">
                <Link to={startTo}>Start Analysis <ArrowRight className="h-4 w-4" /></Link>
              </Button>
              <Button asChild size="lg" variant="heroOutline">
                <Link to={demoTo}>Explore Demo</Link>
              </Button>
            </div>
            <p className="mt-4 font-mono text-xs text-navy-foreground/55">
              Ships with a clearly labelled fictional DEMO DATA corpus · Import your own CSV/JSON any time
            </p>
          </div>
          <div className="flex justify-center">
            <NetworkIllustration />
          </div>
        </div>
      </section>

      <section id="how" className="mx-auto max-w-6xl px-4 py-16">
        <h2 className="text-2xl font-semibold">How it works</h2>
        <p className="mt-1 text-sm text-muted-foreground">A transparent pipeline – every score is computed from the data, never simulated.</p>
        <div className="mt-8 grid gap-4 md:grid-cols-4">
          {STEPS.map((s, i) => (
            <div key={s.title} className="card-elevated p-5">
              <div className="flex items-center justify-between">
                <span className="flex h-9 w-9 items-center justify-center rounded-md bg-secondary text-primary"><s.icon className="h-4 w-4" /></span>
                <span className="font-mono text-xs text-muted-foreground">0{i + 1}</span>
              </div>
              <h3 className="mt-4 font-semibold">{s.title}</h3>
              <p className="mt-1 text-sm text-muted-foreground">{s.text}</p>
            </div>
          ))}
        </div>
      </section>

      <section id="capabilities" className="border-y border-border bg-surface-2">
        <div className="mx-auto max-w-6xl px-4 py-16">
          <h2 className="text-2xl font-semibold">Key capabilities</h2>
          <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {CAPABILITIES.map((c) => (
              <div key={c.title} className="card-elevated p-5">
                <c.icon className="h-5 w-5 text-accent" />
                <h3 className="mt-3 font-semibold">{c.title}</h3>
                <p className="mt-1 text-sm text-muted-foreground">{c.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="ai" className="mx-auto grid max-w-6xl gap-10 px-4 py-16 md:grid-cols-2">
        <div>
          <h2 className="text-2xl font-semibold">AI & NLP</h2>
          <p className="mt-2 text-sm text-muted-foreground">
            Claims are normalised, tokenised and stemmed. Keyword similarity uses TF-IDF cosine similarity; semantic
            similarity uses embeddings from a configurable provider with pgvector cosine search. If the embedding service
            is unavailable the engine falls back to keyword + classification scoring and says so.
          </p>
          <div className="mt-4 rounded-md border border-border bg-card p-4 font-mono text-xs leading-relaxed">
            <p>combined = 0.60·semantic + 0.25·keyword + 0.15·classification</p>
            <p className="text-muted-foreground">fallback = 0.70·keyword + 0.30·classification</p>
            <p className="mt-2 text-muted-foreground">weights configurable in Settings</p>
          </div>
        </div>
        <div>
          <h2 className="text-2xl font-semibold">Citation intelligence & optimisation</h2>
          <p className="mt-2 text-sm text-muted-foreground">
            The citation graph computes in-degree, out-degree, degree centrality and PageRank. The optimiser runs a
            Greedy Set Cover over the claim-feature coverage matrix to propose a minimum / small prior-art reference set
            and explains why each reference was selected.
          </p>
          <ul className="mt-4 space-y-2 text-sm">
            <li className="flex items-center gap-2"><GitBranch className="h-4 w-4 text-accent" /> Node size by citation count / centrality</li>
            <li className="flex items-center gap-2"><Target className="h-4 w-4 text-accent" /> Coverage matrix: ✓ covered · ~ partial · ✕ not identified</li>
            <li className="flex items-center gap-2"><LayoutDashboard className="h-4 w-4 text-accent" /> Timeline, examiner recommendation prototype and PDF/CSV export</li>
          </ul>
        </div>
      </section>

      <footer className="border-t border-border">
        <div className="mx-auto max-w-6xl px-4 py-10">
          <div className="flex items-start gap-3 rounded-md border border-border bg-surface-2 p-4 text-sm text-muted-foreground">
            <Scale className="mt-0.5 h-4 w-4 shrink-0" />
            <p>{LEGAL_DISCLAIMER}</p>
          </div>
          <p className="mt-6 text-xs text-muted-foreground">
            Patent Prior-Art & Litigation Analytics Engine · B.Tech AI & Data Science project demonstration · Demo patents are fictional.
          </p>
        </div>
      </footer>
    </div>
  );
}
