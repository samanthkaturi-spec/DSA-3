import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Check, Minus, Pencil, Plus, RefreshCw, Trash2, X, Loader2 } from "lucide-react";
import { toast } from "sonner";
import type { AnalysisBundle } from "./useAnalysis";
import { addFeature, deleteFeature, recomputeCoverage, updateFeature } from "@/lib/analysis.functions";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { errorMessage } from "@/components/common";
import { cn } from "@/lib/utils";

export type Coverage = Record<string, { status: "covered" | "partial" | "none"; score: number; matched: string[]; missing: string[] }>;

export function CoverageMark({ status, score, matched, missing }: { status: "covered" | "partial" | "none"; score?: number; matched?: string[]; missing?: string[] }) {
  const icon =
    status === "covered" ? <Check className="h-3.5 w-3.5" /> : status === "partial" ? <Minus className="h-3.5 w-3.5" /> : <X className="h-3.5 w-3.5" />;
  const label = status === "covered" ? "✓ Covered" : status === "partial" ? "~ Partially matched" : "✕ Not identified";
  return (
    <TooltipProvider delayDuration={150}>
      <Tooltip>
        <TooltipTrigger asChild>
          <span
            className={cn(
              "inline-flex h-6 w-6 items-center justify-center rounded",
              status === "covered" && "bg-success/15 text-success",
              status === "partial" && "bg-warning/20 text-warning-foreground",
              status === "none" && "bg-muted text-muted-foreground",
            )}
            aria-label={label}
          >
            {icon}
          </span>
        </TooltipTrigger>
        <TooltipContent className="max-w-xs text-xs">
          <p className="font-medium">{label}{score !== undefined ? ` · ${Math.round(score * 100)}% of terms` : ""}</p>
          {matched && matched.length > 0 && <p className="mt-1"><span className="text-muted-foreground">matched:</span> {matched.join(", ")}</p>}
          {missing && missing.length > 0 && <p><span className="text-muted-foreground">missing:</span> {missing.join(", ")}</p>}
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}

/** Editable list of claim features (per target claim) + recompute action. */
export function FeatureEditor({ b, claimId }: { b: AnalysisBundle; claimId?: string | undefined }) {
  const qc = useQueryClient();
  const add = useServerFn(addFeature);
  const upd = useServerFn(updateFeature);
  const del = useServerFn(deleteFeature);
  const recompute = useServerFn(recomputeCoverage);
  const [newText, setNewText] = useState("");
  const [editing, setEditing] = useState<{ id: string; text: string } | null>(null);
  const [dirty, setDirty] = useState(false);

  const refresh = () => qc.invalidateQueries({ queryKey: ["analysis", b.analysis.id] });
  const onErr = (e: unknown) => toast.error(errorMessage(e));

  const addMut = useMutation({ mutationFn: (text: string) => add({ data: { analysisId: b.analysis.id, claimId: claimId ?? b.targetClaims[0]!.id, text } }), onSuccess: () => { setNewText(""); setDirty(true); refresh(); }, onError: onErr });
  const updMut = useMutation({ mutationFn: (v: { id: string; text: string }) => upd({ data: v }), onSuccess: () => { setEditing(null); setDirty(true); refresh(); }, onError: onErr });
  const delMut = useMutation({ mutationFn: (id: string) => del({ data: { id } }), onSuccess: () => { setDirty(true); refresh(); }, onError: onErr });
  const recMut = useMutation({
    mutationFn: () => recompute({ data: { analysisId: b.analysis.id } }),
    onSuccess: () => { setDirty(false); refresh(); toast.success("Coverage matrix and reference set recomputed"); },
    onError: onErr,
  });

  const features = b.features.filter((f) => !claimId || f.claim_id === claimId);

  return (
    <div className="space-y-3">
      <ul className="space-y-1.5">
        {features.map((f, i) => (
          <li key={f.id} className="flex items-start gap-2 rounded-md border border-border bg-card px-3 py-2 text-sm">
            <span className="mt-0.5 w-6 shrink-0 font-mono text-xs text-muted-foreground">F{i + 1}</span>
            {editing?.id === f.id ? (
              <form className="flex flex-1 gap-2" onSubmit={(e) => { e.preventDefault(); updMut.mutate(editing); }}>
                <Input autoFocus value={editing.text} onChange={(e) => setEditing({ id: f.id, text: e.target.value })} className="h-8 text-sm" />
                <Button type="submit" size="sm" className="h-8" disabled={updMut.isPending}>Save</Button>
                <Button type="button" size="sm" variant="ghost" className="h-8" onClick={() => setEditing(null)}>Cancel</Button>
              </form>
            ) : (
              <>
                <span className="flex-1">{f.feature_text}</span>
                {f.source === "manual" && <Badge variant="outline" className="text-[10px]">edited</Badge>}
                <Button size="icon" variant="ghost" className="h-7 w-7" aria-label="Edit feature" onClick={() => setEditing({ id: f.id, text: f.feature_text })}><Pencil className="h-3.5 w-3.5" /></Button>
                <Button size="icon" variant="ghost" className="h-7 w-7 text-destructive" aria-label="Remove feature" onClick={() => delMut.mutate(f.id)} disabled={delMut.isPending}><Trash2 className="h-3.5 w-3.5" /></Button>
              </>
            )}
          </li>
        ))}
        {features.length === 0 && <li className="text-sm text-muted-foreground">No features yet – add one below.</li>}
      </ul>
      <form className="flex gap-2" onSubmit={(e) => { e.preventDefault(); if (newText.trim().length >= 2) addMut.mutate(newText.trim()); }}>
        <Input placeholder="Add a technical feature, e.g. “thermal imaging sensor”" value={newText} onChange={(e) => setNewText(e.target.value)} className="h-9" />
        <Button type="submit" variant="outline" disabled={addMut.isPending || newText.trim().length < 2}><Plus className="h-4 w-4" /> Add</Button>
      </form>
      <div className="flex flex-wrap items-center justify-between gap-2 rounded-md border border-border bg-surface-2 px-3 py-2 text-xs text-muted-foreground">
        <span>{dirty ? "Features changed – recompute to update the coverage matrix and reference set." : "Automated extraction can be corrected here; matching is heuristic, not a legal determination."}</span>
        <Button size="sm" variant={dirty ? "accent" : "outline"} onClick={() => recMut.mutate()} disabled={recMut.isPending}>
          {recMut.isPending ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <RefreshCw className="h-3.5 w-3.5" />} Recompute coverage
        </Button>
      </div>
    </div>
  );
}

/** Feature × reference coverage matrix. */
export function FeatureMatrix({ b, referenceIds, maxRefs = 6, claimId }: { b: AnalysisBundle; referenceIds?: string[] | undefined; maxRefs?: number | undefined; claimId?: string | undefined }) {
  const refs = (referenceIds ? b.priorArt.filter((p) => referenceIds.includes(p.patent_id)) : b.priorArt).slice(0, maxRefs);
  const features = b.features.filter((f) => !claimId || f.claim_id === claimId);
  if (features.length === 0) return <p className="text-sm text-muted-foreground">No features extracted.</p>;
  if (refs.length === 0) return <p className="text-sm text-muted-foreground">No references to compare.</p>;
  const targetById = new Map(b.targetClaims.map((t) => [t.id, t]));
  return (
    <div className="overflow-x-auto rounded-md border border-border">
      <table className="w-full text-sm">
        <thead className="bg-surface-2 text-xs">
          <tr>
            <th className="sticky left-0 z-10 bg-surface-2 px-3 py-2 text-left font-medium">Feature</th>
            <th className="px-2 py-2 text-center font-medium">Target</th>
            {refs.map((r) => (
              <th key={r.patent_id} className="px-2 py-2 text-center font-mono font-medium" title={r.patent?.title ?? ""}>
                {r.patent?.patent_number}
                <span className="block text-[10px] font-normal text-muted-foreground">{Math.round(Number(r.best_combined_score) * 100)}%</span>
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {features.map((f, i) => (
            <tr key={f.id} className="border-t border-border">
              <td className="sticky left-0 z-10 max-w-xs bg-card px-3 py-1.5">
                <span className="mr-2 font-mono text-[10px] text-muted-foreground">F{i + 1}{b.targetClaims.length > 1 ? `·c${targetById.get(f.claim_id)?.claim_number}` : ""}</span>
                {f.feature_text}
              </td>
              <td className="px-2 py-1.5 text-center"><CoverageMark status="covered" /></td>
              {refs.map((r) => {
                const cov = ((r.coverage as Coverage) ?? {})[f.id];
                return (
                  <td key={r.patent_id} className="px-2 py-1.5 text-center">
                    {cov ? <CoverageMark status={cov.status} score={cov.score} matched={cov.matched} missing={cov.missing} /> : <CoverageMark status="none" />}
                  </td>
                );
              })}
            </tr>
          ))}
          <tr className="border-t border-border bg-surface-2 text-xs">
            <td className="sticky left-0 bg-surface-2 px-3 py-1.5 font-medium">Confidence (covered + ½ partial)</td>
            <td className="px-2 py-1.5 text-center font-mono">100%</td>
            {refs.map((r) => {
              const n = features.length || 1;
              const cov = (r.coverage as Coverage) ?? {};
              const c = features.filter((f) => cov[f.id]?.status === "covered").length;
              const p = features.filter((f) => cov[f.id]?.status === "partial").length;
              const conf = (c + 0.5 * p) / n;
              return (
                <td key={r.patent_id} className={cn("px-2 py-1.5 text-center font-mono", conf >= 0.7 ? "text-success" : conf >= 0.4 ? "text-warning-foreground" : "text-muted-foreground")}>{Math.round(conf * 100)}%</td>
              );
            })}
          </tr>
        </tbody>
      </table>
    </div>
  );
}
