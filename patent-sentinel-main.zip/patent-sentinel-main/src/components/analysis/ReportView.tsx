import type { ReportContent } from "@/lib/reports.functions";
import { fmtDate, pct, DemoBadge } from "@/components/common";

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="mb-6 break-inside-avoid">
      <h2 className="mb-2 border-b border-border pb-1 text-base font-semibold">{title}</h2>
      {children}
    </section>
  );
}

export function ReportView({ title, content: c, createdAt }: { title: string; content: ReportContent; createdAt: string }) {
  const featureIndex = new Map(c.features.map((f, i) => [f.id, i + 1]));
  const mark = (s?: string) => (s === "covered" ? "✓" : s === "partial" ? "~" : "✕");
  return (
    <article className="print-page card-elevated mx-auto max-w-4xl p-8 text-sm">
      <header className="mb-6">
        <p className="font-mono text-xs uppercase tracking-wider text-muted-foreground">Patent Prior-Art & Litigation Analytics Engine · Analysis report</p>
        <h1 className="mt-1 text-2xl font-semibold">{title}</h1>
        <p className="text-xs text-muted-foreground">Generated {new Date(createdAt).toLocaleString()} · Scoring mode: {c.scoring_mode} · Dataset: {c.dataset_mode} {c.target_patent.is_demo && <DemoBadge className="ml-1" />}</p>
        {c.scoring_notice && <p className="mt-1 text-xs text-warning-foreground">{c.scoring_notice}</p>}
      </header>

      <Section title="1. Executive summary"><p className="leading-relaxed">{c.executive_summary}</p>{c.scoring_formula && <p className="mt-2 font-mono text-xs text-muted-foreground">{c.scoring_formula}</p>}</Section>

      <Section title="2. Target patent">
        <dl className="grid grid-cols-[140px_1fr] gap-y-1">
          <dt className="text-muted-foreground">Number</dt><dd className="font-mono">{c.target_patent.patent_number}</dd>
          <dt className="text-muted-foreground">Title</dt><dd>{c.target_patent.title}</dd>
          <dt className="text-muted-foreground">Assignee</dt><dd>{c.target_patent.assignee ?? "—"}</dd>
          <dt className="text-muted-foreground">Inventors</dt><dd>{c.target_patent.inventors.join(", ") || "—"}</dd>
          <dt className="text-muted-foreground">Dates</dt><dd>Priority {fmtDate(c.target_patent.priority_date)} · Filing {fmtDate(c.target_patent.filing_date)} · Publication {fmtDate(c.target_patent.publication_date)}</dd>
          <dt className="text-muted-foreground">CPC / IPC</dt><dd className="font-mono text-xs">{c.target_patent.cpc_codes.join(", ") || "—"} / {c.target_patent.ipc_codes.join(", ") || "—"}</dd>
        </dl>
        {c.target_patent.abstract && <p className="mt-2 text-muted-foreground">{c.target_patent.abstract}</p>}
      </Section>

      <Section title="3. Claims analysed">
        {c.claims_analyzed.map((cl) => (<p key={cl.id} className="mb-2"><span className="font-mono text-xs font-semibold">Claim {cl.claim_number} ({cl.claim_type})</span> — {cl.claim_text}</p>))}
        <p className="mt-2 text-xs font-medium">Extracted features</p>
        <ol className="list-inside list-decimal text-xs">{c.features.map((f) => <li key={f.id}>{f.text}{f.source === "manual" && " (edited)"}</li>)}</ol>
      </Section>

      <Section title="4. Top prior-art references & similarity scores">
        <table className="w-full text-xs">
          <thead><tr className="border-b border-border text-left"><th className="py-1">#</th><th>Reference</th><th>Semantic</th><th>Keyword</th><th>Class.</th><th>Combined</th><th>Published</th><th>Coverage</th></tr></thead>
          <tbody>
            {c.prior_art.map((p) => (
              <tr key={p.patent_id} className="border-b border-border/60 align-top">
                <td className="py-1">{p.rank}</td>
                <td><span className="font-mono">{p.patent_number}</span> {p.is_demo && <DemoBadge />}<br /><span className="text-muted-foreground">{p.title}</span></td>
                <td>{p.semantic === null ? "n/a" : pct(p.semantic)}</td><td>{pct(p.keyword)}</td><td>{pct(p.classification)}</td><td className="font-semibold">{pct(p.combined)}</td>
                <td>{fmtDate(p.publication_date)}{p.predates_target && " (predates)"}</td>
                <td>{p.covered}✓ {p.partial}~</td>
              </tr>
            ))}
          </tbody>
        </table>
        <p className="mt-1 text-[11px] text-muted-foreground">References at or above {Math.round(c.threshold * 100)}% are labelled “Potentially Relevant Prior Art”; ≥80% “High Similarity Reference”. All require legal review.</p>
      </Section>

      <Section title="5. Claim feature matrix">
        <table className="w-full text-xs">
          <thead><tr className="border-b border-border text-left"><th className="py-1">Feature</th>{c.prior_art.slice(0, 6).map((p) => <th key={p.patent_id} className="px-1 font-mono">{p.patent_number}</th>)}</tr></thead>
          <tbody>
            {c.features.map((f) => (
              <tr key={f.id} className="border-b border-border/60"><td className="py-1">F{featureIndex.get(f.id)} {f.text}</td>{c.prior_art.slice(0, 6).map((p) => <td key={p.patent_id} className="px-1 text-center font-mono">{mark(p.coverage[f.id])}</td>)}</tr>
            ))}
          </tbody>
        </table>
        <p className="mt-1 text-[11px] text-muted-foreground">✓ covered · ~ partially matched · ✕ not identified (heuristic keyword coverage).</p>
      </Section>

      <Section title="6. Citation network summary">
        <p>The target cites {c.citation_summary.cited_by_target} patent(s) and is cited by {c.citation_summary.citing_target}; {c.citation_summary.linked_candidates} ranked reference(s) share a direct citation link with the target.</p>
      </Section>

      <Section title="7. Minimum / small prior-art reference set (Greedy Set Cover)">
        {c.reference_set.length === 0 ? <p>No reference fully covers any extracted feature.</p> : (
          <ol className="list-inside list-decimal space-y-1">{c.reference_set.map((r) => <li key={r.order}><span className="font-mono">{r.patent_number}</span> — {r.title}. <span className="text-muted-foreground">{r.reason}</span></li>)}</ol>
        )}
        <p className="mt-1 text-xs">Combined coverage: {pct(c.set_coverage_pct)} of {c.features.length} features.</p>
      </Section>

      <Section title="8. Timeline">
        <ul className="text-xs">{c.timeline.map((t, i) => <li key={i} className="flex gap-2"><span className="w-24 font-mono">{fmtDate(t.date)}</span><span>{t.label}{t.predates ? " — predates target date" : ""}</span></li>)}</ul>
        <p className="mt-1 text-[11px] text-muted-foreground">Temporal relevance requires legal review.</p>
      </Section>

      <Section title="9. Prototype examiner assignment recommendation">
        <table className="w-full text-xs">
          <thead><tr className="border-b border-border text-left"><th className="py-1">#</th><th>Examiner</th><th>Domain</th><th>Expertise</th><th>Workload</th><th>Experience</th><th>Overall</th></tr></thead>
          <tbody>{c.examiner_recommendation.map((e) => <tr key={e.rank} className="border-b border-border/60"><td className="py-1">{e.rank}</td><td>{e.name} <span className="font-mono text-muted-foreground">{e.code}</span></td><td>{pct(e.domain_match)}</td><td>{pct(e.expertise)}</td><td>{pct(e.workload)}</td><td>{pct(e.experience)}</td><td className="font-semibold">{pct(e.overall)}</td></tr>)}</tbody>
        </table>
        <p className="mt-1 text-[11px] text-muted-foreground">Illustrative scoring only; no actual examiner is assigned.</p>
      </Section>

      <Section title="10. Limitations & legal disclaimer">
        <ul className="list-inside list-disc text-xs">{c.limitations.map((l, i) => <li key={i}>{l}</li>)}</ul>
        <p className="mt-3 rounded-md border border-border bg-surface-2 p-3 text-xs">{c.disclaimer}</p>
      </Section>
    </article>
  );
}
