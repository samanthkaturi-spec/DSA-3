import type { AnalysisBundle } from "./useAnalysis";
import { fmtDate } from "@/components/common";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

export function TimelinePanel({ b }: { b: AnalysisBundle }) {
  const p = b.patent;
  const relevant = p.priority_date ?? p.filing_date ?? p.publication_date ?? null;
  const events: Array<{ date: string; label: string; kind: "target" | "prior"; predates: boolean | null; sub?: string }> = [];
  if (p.priority_date) events.push({ date: p.priority_date, label: "Priority date (target)", kind: "target", predates: null });
  if (p.filing_date) events.push({ date: p.filing_date, label: "Filing date (target)", kind: "target", predates: null });
  if (p.publication_date) events.push({ date: p.publication_date, label: "Publication date (target)", kind: "target", predates: null });
  for (const r of b.priorArt) {
    const d = r.patent?.publication_date ?? r.patent?.filing_date;
    if (d) events.push({ date: d, label: `${r.patent?.patent_number} published`, kind: "prior", predates: relevant ? d < relevant : null, sub: `${r.patent?.title} · ${Math.round(Number(r.best_combined_score) * 100)}%` });
  }
  events.sort((a, c) => a.date.localeCompare(c.date));
  const predating = events.filter((e) => e.predates).length;

  if (events.length === 0) return <p className="text-sm text-muted-foreground">No dates are recorded for this patent or its references.</p>;

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
        <span>Relevant target date: <span className="font-mono text-foreground">{fmtDate(relevant)}</span> ({p.priority_date ? "priority" : p.filing_date ? "filing" : "publication"})</span>
        <span>·</span>
        <span>{predating} of {b.priorArt.length} references predate it</span>
        <Badge variant="outline" className="text-[10px]">Temporal relevance requires legal review.</Badge>
      </div>
      <ol className="relative ml-3 border-l border-border">
        {events.map((e, i) => (
          <li key={i} className="mb-4 ml-5">
            <span className={cn("absolute -left-1.5 mt-1.5 h-3 w-3 rounded-full border-2 border-background", e.kind === "target" ? "bg-primary" : e.predates ? "bg-accent" : "bg-muted-foreground/40")} />
            <p className="font-mono text-xs text-muted-foreground">{fmtDate(e.date)}</p>
            <div className={cn("flex flex-wrap items-center gap-2 text-sm", e.kind === "target" && "font-semibold")}>
              <span>{e.label}</span>
              {e.predates && <Badge className="bg-accent/15 text-foreground hover:bg-accent/15">predates target date</Badge>}
              {e.kind === "prior" && e.predates === false && <Badge variant="outline" className="text-[10px]">after target date</Badge>}
            </div>
            {e.sub && <p className="text-xs text-muted-foreground">{e.sub}</p>}
          </li>
        ))}
      </ol>
    </div>
  );
}
