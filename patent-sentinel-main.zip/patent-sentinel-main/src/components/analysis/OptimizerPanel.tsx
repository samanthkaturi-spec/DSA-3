import { Link } from "@tanstack/react-router";
import { CheckCircle2, Info, Target } from "lucide-react";
import type { AnalysisBundle } from "./useAnalysis";
import { StatCard, pct } from "@/components/common";
import { FeatureEditor, FeatureMatrix, type Coverage } from "./FeatureMatrix";
import { Badge } from "@/components/ui/badge";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

export function OptimizerPanel({ b }: { b: AnalysisBundle }) {
  const s = (b.analysis.summary ?? {}) as Record<string, unknown>;
  const featureById = new Map(b.features.map((f) => [f.id, f]));
  const selectedIds = b.references.map((r) => r.patent_id);
  const uncovered = (s["uncovered_features"] as string[] | undefined) ?? [];
  const coveredCount = b.features.length - uncovered.filter((id) => featureById.has(id)).length;

  return (
    <div className="space-y-4">
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Target features" value={b.features.length} hint={`${b.targetClaims.length} independent claim(s)`} icon={<Target className="h-4 w-4" />} />
        <StatCard label="Selected references" value={b.references.length} hint="Minimum / small prior-art reference set" icon={<CheckCircle2 className="h-4 w-4" />} tone="accent" />
        <StatCard label="Coverage" value={pct(Number(s["set_coverage_pct"] ?? 0))} hint={`${coveredCount} of ${b.features.length} features covered`} />
        <StatCard label="Candidates considered" value={b.priorArt.length} hint="Ranked prior-art results" />
      </div>

      <div className="rounded-md border border-border bg-surface-2 p-3 text-xs text-muted-foreground">
        <span className="font-medium text-foreground">Greedy Set Cover.</span> At each step the reference covering the most still-uncovered features is selected (ties broken by partial matches, then similarity). The result is a small covering set – not necessarily the absolute minimum, and not an "invalidating set": every reference requires legal review.
      </div>

      <div className="grid gap-4 lg:grid-cols-[1fr_1.4fr]">
        <div className="card-elevated p-4">
          <h3 className="text-sm font-semibold">Selected references &amp; why</h3>
          {b.references.length === 0 ? (
            <p className="mt-2 text-sm text-muted-foreground">No reference fully covers any extracted feature. Try editing the features (below) and recomputing.</p>
          ) : (
            <Accordion type="multiple" defaultValue={b.references.map((r) => r.id)} className="mt-2">
              {b.references.map((r) => (
                <AccordionItem key={r.id} value={r.id}>
                  <AccordionTrigger className="py-2 text-left text-sm hover:no-underline">
                    <span className="flex items-center gap-2">
                      <span className="flex h-5 w-5 items-center justify-center rounded-full bg-primary font-mono text-[10px] text-primary-foreground">{r.selection_order}</span>
                      <span className="font-mono text-xs">{r.patent?.patent_number}</span>
                      <span className="line-clamp-1 text-muted-foreground">{r.patent?.title}</span>
                    </span>
                  </AccordionTrigger>
                  <AccordionContent className="text-sm">
                    <p className="flex items-start gap-1.5 text-muted-foreground"><Info className="mt-0.5 h-3.5 w-3.5 shrink-0" />{r.reason}</p>
                    <p className="mt-2 text-xs font-medium">Newly covered features</p>
                    <ul className="mt-1 space-y-0.5">
                      {r.newly_covered_features.map((fid) => featureById.get(fid)).filter(Boolean).map((f) => (
                        <li key={f!.id} className="flex items-center gap-1.5 text-xs"><CheckCircle2 className="h-3 w-3 text-success" /> {f!.feature_text}</li>
                      ))}
                    </ul>
                    <Link to="/patents/$id" params={{ id: r.patent_id }} className="mt-2 inline-block text-xs text-accent hover:underline">View patent →</Link>
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          )}
          {uncovered.length > 0 && (
            <div className="mt-3 rounded-md border border-warning/40 bg-warning/10 p-3 text-xs">
              <p className="font-medium">Features not covered by any reference</p>
              <ul className="mt-1 list-inside list-disc">{uncovered.map((id) => featureById.get(id)).filter(Boolean).map((f) => <li key={f!.id}>{f!.feature_text}</li>)}</ul>
            </div>
          )}
        </div>
        <div className="card-elevated p-4">
          <div className="mb-2 flex items-center justify-between">
            <h3 className="text-sm font-semibold">Coverage matrix</h3>
            <div className="flex gap-1">{selectedIds.map((id) => <Badge key={id} className="font-mono text-[10px]">{b.priorArt.find((p) => p.patent_id === id)?.patent?.patent_number}</Badge>)}</div>
          </div>
          <FeatureMatrix b={b} referenceIds={[...selectedIds, ...b.priorArt.map((p) => p.patent_id).filter((id) => !selectedIds.includes(id))]} maxRefs={8} />
          <p className="mt-2 text-[11px] text-muted-foreground">Selected set shown first; per-reference coverage counts: {b.priorArt.slice(0, 8).map((p) => `${p.patent?.patent_number}: ${Object.values((p.coverage as Coverage) ?? {}).filter((c) => c.status === "covered").length}✓`).join(" · ")}</p>
        </div>
      </div>

      <div className="card-elevated p-4">
        <h3 className="text-sm font-semibold">Target features (editable)</h3>
        <p className="mb-3 text-xs text-muted-foreground">Correct the automated extraction, then recompute to update the coverage matrix and reference set.</p>
        <FeatureEditor b={b} />
      </div>
    </div>
  );
}
