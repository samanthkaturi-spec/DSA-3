import { useCallback, useRef, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { AlertTriangle, Check, Circle, Loader2, Play } from "lucide-react";
import { createAnalysis, runAnalysisStage } from "@/lib/analysis.functions";
import { SERVER_STAGES, STAGE_PROGRESS, type ServerStage } from "@/lib/analysis-stages";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { errorMessage } from "@/components/common";
import { cn } from "@/lib/utils";

export type StageStatus = "pending" | "running" | "done" | "failed" | "skipped";
export interface StageState {
  key: string;
  label: string;
  status: StageStatus;
  detail?: string;
}

export function StageList({ stages }: { stages: StageState[] }) {
  return (
    <ol className="space-y-1.5">
      {stages.map((s) => (
        <li key={s.key} className="flex items-start gap-2 text-sm">
          <span className="mt-0.5">
            {s.status === "done" && <Check className="h-4 w-4 text-success" />}
            {s.status === "running" && <Loader2 className="h-4 w-4 animate-spin text-accent" />}
            {s.status === "failed" && <AlertTriangle className="h-4 w-4 text-destructive" />}
            {s.status === "pending" && <Circle className="h-4 w-4 text-muted-foreground/40" />}
            {s.status === "skipped" && <Circle className="h-4 w-4 text-muted-foreground/40" />}
          </span>
          <div className="min-w-0">
            <span className={cn(s.status === "pending" && "text-muted-foreground", s.status === "failed" && "text-destructive")}>{s.label}</span>
            {s.detail && <p className="text-xs text-muted-foreground">{s.detail}</p>}
          </div>
        </li>
      ))}
    </ol>
  );
}

function describe(stage: ServerStage, info: Record<string, unknown>): string | undefined {
  switch (stage) {
    case "extracting_claims":
      return `${info["claims"]} claims found · ${info["targets"]} independent target claim(s)`;
    case "extracting_features":
      return `${info["features"]} technical features extracted`;
    case "generating_representations":
      return info["mode"] === "semantic"
        ? `Semantic embeddings ready (${info["embedded"]} newly embedded)`
        : `Keyword mode${info["fallbackReason"] ? ` – ${info["fallbackReason"]}` : ""}`;
    case "searching_corpus":
      return `${info["candidates"]} candidate claims from ${info["corpusSize"]} corpus claims (${info["method"]})`;
    case "calculating_similarity":
      return `${info["pairs"]} claim pairs scored${Number(info["semanticPairs"]) > 0 ? ` · ${info["semanticPairs"]} with semantic score` : ""}`;
    case "analyzing_citations":
      return `${info["cited_by_target"]} cited by target · ${info["citing_target"]} citing target · ${(info["candidates_linked"] as unknown[] | undefined)?.length ?? 0} linked candidates`;
    case "calculating_coverage":
      return `${info["references"]} references · set of ${info["setSize"]} covers ${Math.round(Number(info["coverage"]) * 100)}% of features`;
    case "generating_results":
      return `Top similarity ${Math.round(Number(info["top"]) * 100)}% · ${info["examiners"]} examiners scored`;
  }
}

export function useAnalysisRunner() {
  const navigate = useNavigate();
  const qc = useQueryClient();
  const create = useServerFn(createAnalysis);
  const run = useServerFn(runAnalysisStage);
  const [stages, setStages] = useState<StageState[]>([]);
  const [progress, setProgress] = useState(0);
  const [running, setRunning] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [analysisId, setAnalysisId] = useState<string | null>(null);
  const cancelled = useRef(false);

  const start = useCallback(
    async (patentId: string, preStages: StageState[] = [], opts?: { navigateOnComplete?: boolean }) => {
      cancelled.current = false;
      setError(null);
      setRunning(true);
      const serverStages: StageState[] = SERVER_STAGES.map((s) => ({ key: s.key, label: s.label, status: "pending" }));
      setStages([...preStages, ...serverStages]);
      setProgress(preStages.length ? 5 : 0);
      const update = (key: string, patch: Partial<StageState>) =>
        setStages((prev) => prev.map((s) => (s.key === key ? { ...s, ...patch } : s)));
      try {
        const { analysisId: id } = await create({ data: { patentId } });
        setAnalysisId(id);
        for (const s of SERVER_STAGES) {
          if (cancelled.current) break;
          update(s.key, { status: "running" });
          const res = await run({ data: { analysisId: id, stage: s.key } });
          update(s.key, { status: "done", detail: describe(s.key, (res?.info as Record<string, unknown>) ?? {}) ?? "" });
          setProgress(STAGE_PROGRESS[s.key]);
        }
        qc.invalidateQueries({ queryKey: ["analyses"] });
        qc.invalidateQueries({ queryKey: ["dashboard"] });
        setRunning(false);
        if (opts?.navigateOnComplete !== false) navigate({ to: "/analyses/$id", params: { id } });
        return id;
      } catch (e) {
        const msg = errorMessage(e, "The analysis could not be completed. Please try again.");
        setError(msg);
        setStages((prev) => prev.map((s) => (s.status === "running" ? { ...s, status: "failed", detail: msg } : s)));
        setRunning(false);
        return null;
      }
    },
    [create, run, navigate, qc],
  );

  return { start, stages, progress, running, error, analysisId, setStages };
}

export function AnalysisProgressPanel({ stages, progress, error, running }: { stages: StageState[]; progress: number; error: string | null; running: boolean }) {
  if (stages.length === 0) return null;
  return (
    <div className="card-elevated p-4">
      <div className="mb-3 flex items-center justify-between">
        <h3 className="text-sm font-semibold">{running ? "Running prior-art analysis…" : error ? "Analysis stopped" : "Analysis complete"}</h3>
        <span className="font-mono text-xs text-muted-foreground">{progress}%</span>
      </div>
      <Progress value={progress} className="mb-4 h-2" />
      <StageList stages={stages} />
      {error && (
        <p className="mt-3 flex items-start gap-2 rounded-md border border-destructive/30 bg-destructive/5 p-3 text-sm text-destructive">
          <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" /> {error}
        </p>
      )}
    </div>
  );
}

export function RunAnalysisButton({ onClick, disabled, running }: { onClick: () => void; disabled?: boolean; running?: boolean }) {
  return (
    <Button size="lg" variant="accent" onClick={onClick} disabled={disabled || running}>
      {running ? <Loader2 className="h-4 w-4 animate-spin" /> : <Play className="h-4 w-4" />} Run Prior-Art Analysis
    </Button>
  );
}
