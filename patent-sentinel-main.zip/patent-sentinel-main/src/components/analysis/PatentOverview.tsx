import { Link } from "@tanstack/react-router";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { fmtDate } from "@/components/common";
import type { getPatent } from "@/lib/patents.functions";

export type PatentDetail = Awaited<ReturnType<typeof getPatent>>;

export function InfoRow({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div className="grid grid-cols-[130px_1fr] gap-2 py-1.5 text-sm">
      <span className="text-xs font-medium uppercase tracking-wider text-muted-foreground">{label}</span>
      <span className="min-w-0 break-words">{value ?? "—"}</span>
    </div>
  );
}

export function ClaimCard({ c }: { c: PatentDetail["claims"][number] }) {
  return (
    <div className="rounded-md border border-border bg-card p-3">
      <div className="mb-1 flex flex-wrap items-center gap-2">
        <span className="font-mono text-xs font-semibold">Claim {c.claim_number}</span>
        <Badge variant={c.is_independent ? "default" : "outline"} className="text-[10px]">{c.is_independent ? "Independent" : `Dependent on ${c.depends_on ?? "?"}`}</Badge>
        <Badge variant="secondary" className="font-mono text-[10px] uppercase">{c.claim_type}</Badge>
      </div>
      <p className="text-sm leading-relaxed">{c.claim_text}</p>
    </div>
  );
}

export function PatentOverview({ detail }: { detail: PatentDetail }) {
  const { patent, claims, cites, citedBy } = detail;
  const independent = claims.filter((c) => c.is_independent);
  const dependent = claims.filter((c) => !c.is_independent);
  return (
    <div className="grid gap-4 lg:grid-cols-[1fr_1.2fr]">
      <div className="card-elevated p-4">
        <div className="flex flex-wrap items-center gap-2">
          <span className="font-mono text-sm font-semibold text-primary">{patent.patent_number}</span>
          <Badge variant="outline" className="text-[10px] uppercase">{patent.source}</Badge>
        </div>
        <h2 className="mt-2 text-lg font-semibold leading-snug">{patent.title}</h2>
        {patent.abstract && <p className="mt-2 text-sm text-muted-foreground">{patent.abstract}</p>}
        <div className="mt-4 divide-y divide-border">
          <InfoRow label="Assignee" value={patent.assignee} />
          <InfoRow label="Inventors" value={patent.inventors.length ? patent.inventors.join(", ") : "—"} />
          <InfoRow label="Priority date" value={fmtDate(patent.priority_date)} />
          <InfoRow label="Filing date" value={fmtDate(patent.filing_date)} />
          <InfoRow label="Publication" value={fmtDate(patent.publication_date)} />
          <InfoRow label="CPC" value={patent.cpc_codes.length ? <span className="flex flex-wrap gap-1">{patent.cpc_codes.map((c) => <Badge key={c} variant="secondary" className="font-mono text-[10px]">{c}</Badge>)}</span> : "Not classified"} />
          <InfoRow label="IPC" value={patent.ipc_codes.length ? <span className="flex flex-wrap gap-1">{patent.ipc_codes.map((c) => <Badge key={c} variant="outline" className="font-mono text-[10px]">{c}</Badge>)}</span> : "Not classified"} />
          <InfoRow label="Claims" value={`${claims.length} total · ${independent.length} independent · ${dependent.length} dependent`} />
        </div>
        <div className="mt-4">
          <h3 className="text-xs font-medium uppercase tracking-wider text-muted-foreground">Citations</h3>
          <div className="mt-2 grid grid-cols-2 gap-2 text-sm">
            <div className="rounded-md border border-border p-2">
              <p className="text-xs text-muted-foreground">Cites (backward)</p>
              <p className="stat-number text-xl font-semibold">{cites.length}</p>
            </div>
            <div className="rounded-md border border-border p-2">
              <p className="text-xs text-muted-foreground">Cited by (forward)</p>
              <p className="stat-number text-xl font-semibold">{citedBy.length}</p>
            </div>
          </div>
          {(cites.length > 0 || citedBy.length > 0) && (
            <ul className="mt-2 max-h-40 space-y-1 overflow-y-auto text-xs">
              {cites.map((c) => (
                <li key={c.id} className="flex items-center gap-2">
                  <Badge variant="outline" className="text-[9px] uppercase">cites</Badge>
                  {c.patent ? <Link to="/patents/$id" params={{ id: c.patent.id }} className="truncate hover:underline"><span className="font-mono">{c.patent.patent_number}</span> · {c.patent.title}</Link> : "—"}
                </li>
              ))}
              {citedBy.map((c) => (
                <li key={c.id} className="flex items-center gap-2">
                  <Badge variant="secondary" className="text-[9px] uppercase">cited by</Badge>
                  {c.patent ? <Link to="/patents/$id" params={{ id: c.patent.id }} className="truncate hover:underline"><span className="font-mono">{c.patent.patent_number}</span> · {c.patent.title}</Link> : "—"}
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
      <div className="card-elevated p-4">
        <Tabs defaultValue="independent">
          <TabsList>
            <TabsTrigger value="independent">Independent ({independent.length})</TabsTrigger>
            <TabsTrigger value="dependent">Dependent ({dependent.length})</TabsTrigger>
            <TabsTrigger value="all">All ({claims.length})</TabsTrigger>
          </TabsList>
          <TabsContent value="independent" className="mt-3 space-y-2">{independent.map((c) => <ClaimCard key={c.id} c={c} />)}{independent.length === 0 && <p className="text-sm text-muted-foreground">No independent claims identified.</p>}</TabsContent>
          <TabsContent value="dependent" className="mt-3 space-y-2">{dependent.map((c) => <ClaimCard key={c.id} c={c} />)}{dependent.length === 0 && <p className="text-sm text-muted-foreground">No dependent claims identified.</p>}</TabsContent>
          <TabsContent value="all" className="mt-3 space-y-2">{claims.map((c) => <ClaimCard key={c.id} c={c} />)}</TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
