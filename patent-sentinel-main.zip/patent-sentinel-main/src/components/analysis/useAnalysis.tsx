import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Link, useNavigate } from "@tanstack/react-router";
import { getAnalysis, listAnalyses } from "@/lib/analysis.functions";
import type { AnalysisBundle } from "@/lib/analysis-pipeline.server";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { fmtDate, pct } from "@/components/common";
import { ExternalLink } from "lucide-react";

export type { AnalysisBundle };

export function useAnalysisBundle(id: string | null | undefined) {
  const fn = useServerFn(getAnalysis);
  return useQuery({
    queryKey: ["analysis", id],
    queryFn: () => fn({ data: { id: id! } }),
    enabled: Boolean(id),
  });
}

export function useAnalysesList() {
  const fn = useServerFn(listAnalyses);
  return useQuery({ queryKey: ["analyses"], queryFn: () => fn({ data: { limit: 100 } }) });
}

/** Dropdown to pick a completed analysis; writes the id into the `analysis` search param of the given route. */
export function AnalysisPicker({ value, to }: { value: string | undefined; to: "/prior-art" | "/compare" | "/citations" | "/optimizer" }) {
  const list = useAnalysesList();
  const navigate = useNavigate();
  const completed = (list.data ?? []).filter((a) => a.status === "completed");
  return (
    <div className="flex flex-wrap items-center gap-2">
      <Select value={value ?? ""} onValueChange={(v) => navigate({ to, search: (prev: Record<string, unknown>) => ({ ...prev, analysis: v }) })}>
        <SelectTrigger className="w-full sm:w-[420px]" aria-label="Select analysis">
          <SelectValue placeholder={list.isLoading ? "Loading analyses…" : completed.length ? "Select a completed analysis" : "No completed analyses yet"} />
        </SelectTrigger>
        <SelectContent>
          {completed.map((a) => {
            const s = (a.summary ?? {}) as Record<string, number>;
            return (
              <SelectItem key={a.id} value={a.id}>
                <span className="font-mono text-xs">{a.patent?.patent_number}</span> · {a.patent?.title?.slice(0, 48)} · {fmtDate(a.created_at)} · top {pct(s["top_similarity"])}
              </SelectItem>
            );
          })}
        </SelectContent>
      </Select>
      {value && (
        <Button asChild variant="outline" size="sm">
          <Link to="/analyses/$id" params={{ id: value }}><ExternalLink className="h-3.5 w-3.5" /> Full analysis</Link>
        </Button>
      )}
    </div>
  );
}

export function AnalysisHeaderMeta({ b }: { b: AnalysisBundle }) {
  return (
    <div className="flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
      <span className="font-mono font-semibold text-primary">{b.patent.patent_number}</span>
      <span>·</span>
      <span>{b.patent.title}</span>
      <span>·</span>
      <span>Analysed {fmtDate(b.analysis.created_at)}</span>
      <span>·</span>
    </div>
  );
}
